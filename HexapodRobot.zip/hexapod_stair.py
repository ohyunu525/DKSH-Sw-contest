"""
계단 모드 — 한 발씩 옮기며(항상 발 5개로 받침) 발로 더듬어 계단 오르기

hexapod_joy_walk.py 안에서 씀: 멈춰 있을 때 C를 1초 길게 누르면 들어가고, 다시 길게 누르면 나옴.
조작 (계단 모드)
  조이스틱 앞/옆    : 그 방향으로 한 발씩 (누르고 있는 동안 계속, 놓으면 지금 옮기는 발까지만 놓고 멈춤)
                     ★ 뒤로는 안 감 (계단 내려가기는 아직 지원 안 함 — 평평한 곳에서 C 길게로 나가서 걷기 모드로)
  Left / Right     : 제자리 회전 (계단 위에선 조금만)
  노랑 / 파랑       : 몸 바닥 여유 +10 / −10mm (배가 계단 모서리에 가까우면 올릴 것)
  조이스틱 누름     : 앞발이 대비하는 계단 높이(RISE_MAX)를 60 → 80 → 100 → 120 → 140 순서로 바꿈
  빨강(접기 버튼)    : ■ 얼음 — 누르고 있으면 한 발 옮기는 도중이라도 그 자세 그대로 멈춤 (서보 힘 유지 → 주저앉지 않음)
                     다시 가려면 빨강을 놓고 C 짧게 (공중에 있던 발은 원래 자리로 되돌린 뒤 발 6개 다시 접지)
  C 짧게          : 발 6개 다시 접지 + 하중 확인 (몸은  그대로)
  C 길게(1초)       : 계단 모드 끝내기 (발이 거의 평평할 때만)
  ★ Ctrl+C는 서보 힘을 빼서 계단 위에서 주저앉음 → 계단 위에선 빨강(얼음)을 쓸 것

한 발 옮기는 순서
  1) 다음 다리 고르기: 가야 할 자리에서 제일 많이 뒤처진 다리 (같으면 진행 방향 앞쪽 다리부터 → 앞발이 먼저 더듬음)
  2) 몸 옮기기 (발 6개는 바닥에 그대로):
       - 진행 방향으로 STRIDE/6
       - 들 다리를 뺀 5발 다각형 안쪽으로 무게중심이 COM_MARGIN 이상 들어가게
       - 발 6개가 이루는 평면(=계단 경사)에 맞춰 몸 기울기, 몸 바닥이 지도상 계단보다 BODY_CLEAR 위가 되게 높이
       → 이 조건을 다 만족하는 자세를 찾고(다리가 닿는지 역기구학으로 확인), 못 찾으면 덜 가거나 덜 기울임
  3) 그 다리: 수직으로 들기 → 수평으로 옮기기(IMU로 걸림 감시) → 내리면서 IMU로 닿는 순간 찾기
  4) 계단을 처음 밟았으면(뒤쪽 기록보다 높으면) 모서리 확인:
       EDGE_MARGIN만큼 뒤를 살짝 더듬어서 거기도 같은 높이면 OK, 아니면 디딘 곳이 모서리 바로 앞 → 앞으로 옮김
  5) 정말 받치는지 확인 (2칸 들어봐서 기울기 변화)
  6) 디딘 곳 높이를 지도에 기록 → 뒤따르는 다리는 지도의 '확실한 자리'를 골라 디딤

★ 카메라가 없어서 계단은 발로만 앎: 앞발은 매번 '지금 높이 + RISE_MAX'까지 들고 나가서 천천히 내림 (느린 이유).
★ 계단이 로봇 x축(앞)과 직각이라고 가정함. 비스듬하면 계단 앞에서 회전으로 맞춘 다음 올라갈 것.
★ 지도·몸 위치는 '발이 안 미끄러진다'고 보고 계산함. 미끄러지면 어긋남 → 멈추고 C 짧게로 다시 접지.
★ 내려가기는 아직 안 함: 앞(진행 방향) 바닥이 DESCEND_STOP(30mm)보다 많이 낮으면 그 다리를 되돌리고 멈춤.
  (오르기용 '모서리 확인'은 올라선 발만 지켜줌. 내려갈 때는 위 칸 모서리 끝에 선 발을 지켜줄 확인이 따로 필요)
"""

import bisect
import math
import time
from collections import deque

import hexapod_body as hb
import hexapod_joy_walk as jw
from hexapod_sdk import JOINT_LIMITS, NUM_JOINTS, NUM_LEGS

LEG_NAME = ["왼뒤", "왼앞", "맨앞", "오른앞", "오른뒤", "맨뒤"]   # 다리 1~6 (hexapod_body 배치)

# ═══════════════════════════ 하이퍼파라미터 ═══════════════════════════
# ── 1. 걸음 ──
STRIDE = 80.0
#   한 바퀴(다리 6개가 한 번씩 옮김)에 몸이 가는 거리 [mm]. 다리 하나 옮길 때마다 몸은 STRIDE/6씩.
#   키우면: 빨라짐. 대신 발 자리를 계단 모서리 피해서 고르기 어려워지고 다리가 앞뒤 끝까지 감.
TURN_PER_CYCLE = 12.0
#   제자리 회전: 한 바퀴에 도는 각도 [도].
BODY_SPEED = 40.0         # 몸 옮기는 속도 [mm/s]
BODY_Z_SPEED = 40.0       # 몸 높이 바꾸는 속도 [mm/s]
BODY_ROT_SPEED = 12.0     # 몸 기울기·방향 바꾸는 속도 [도/s]
FOOT_SPEED = 90.0         # 공중 발 들기·옮기기 속도 [mm/s]
SPEED_SCALE_MIN = 0.5     # 볼륨 0일 때 위 속도들의 배율 (최대일 때 1.0)

# ── 2. 계단 찾기 ──
RISE_MAX = 100.0
#   앞발이 기록이 없는 곳(앞쪽)으로 나갈 때 '이만큼 높은 계단이 있을 수 있다'고 보고 드는 높이 [mm].
#   계단보다 작으면 발이 계단 앞면에 부딪힘. 크면 매번 높이 드느라 느림. 조이스틱 누름으로 바꿀 수 있음.
RISE_CHOICES = [60.0, 80.0, 100.0, 120.0, 140.0]
RISE_TOL = 20.0
#   계단을 한 번 재본 뒤에는 '다음 계단도 잰 높이 + 이만큼[mm] 이하'로 보고 다리 링크가 걸리는지 판단
#   (앞발 드는 높이는 그대로 RISE_MAX). 계단 높이가 칸마다 많이 다르면 키울 것.
SWING_CLEAR = 20.0
#   공중 발이 지도상 가장 높은 곳보다 이만큼 위로 지나감 [mm].
FLAT_EPS = 12.0
#   이보다 작은 높이 차이는 같은 디딤판(울퉁불퉁)으로 봄 [mm]. 이보다 크면 그 사이에 계단 모서리가 있다고 봄.
UNEVEN_PAD = 4.0
#   지도에서 '이 근처 바닥은 기록보다 이만큼 높을 수도 있다'고 보는 여유 [mm] (디딤판 울퉁불퉁).
EDGE_MARGIN = 20.0
#   계단을 처음 밟은 발이 그 디딤판 앞 모서리에서 최소 이만큼 떨어져 있어야 함 [mm].
#   발끝이 둥글어서 모서리에 걸치면 미끄러짐. 키우면 안전, 대신 확인에서 '모서리 가까움'이 더 자주 나와 느려짐.
EDGE_LIFT = 8.0           # 모서리 확인할 때 발을 살짝 드는 높이 [mm]
EDGE_PROBE = 5.0          # 모서리 확인: 디딘 높이보다 이만큼만 더 내려봄 [mm] (더 내리면 모서리 너머에서 다리가 계단에 걸림)
EDGE_FWD = 30.0           # 모서리에 너무 가까우면 앞으로 옮기는 거리 [mm]
REPLACE_LIFT = 20.0       # 계단 모드 끝낼 때 발을 기본 자리로 옮기며 드는 높이 [mm]
KNOWN_R = 15.0            # 지도 기록에서 이 거리 안이면 '확실한 자리'로 봄 [mm]
RISER_SLOP = 10.0
#   '낮은 기록' 바로 앞에도 계단 모서리가 있을 수 있다고 보는 거리 [mm].
#   왜: 디딤판 앞 모서리에 디딘 발은 미끄러져 아래 칸 높이로 기록됨 → 그 '낮은 기록'은 사실 모서리 위일 수 있음.
#   그래서 지도상 계단 근처는 이만큼 넓혀서 높게 보고, 낮은 칸에 디딜 땐 그 기록보다 이만큼 뒤에 디딤.
MAP_MERGE_DX = 8.0        # 이 거리 안의 기록은 새 것으로 바꿈 [mm]
MAP_KEEP = 900.0          # 몸에서 이 거리보다 먼 기록은 지움 [mm]
PRESS_INIT, PRESS_MAX, PRESS_GAIN = 1.0, 3.0, 0.1
#   새로 디딘 발을 '막 닿은 높이'보다 더 눌러두는 양 [mm] (배우는 값: 시작 PRESS_INIT, 최대 PRESS_MAX).
#   받치던 발들은 무게 때문에 눌려 있어서, 새 발을 막 닿은 높이에 두면 그 발만 덜 받치고 명령 좌표가 밀림(아래 설명).
#   뒤따르는 다리가 '기록 있는 자리'(바로 그 자리)에 디딜 때 기록보다 높게 닿으면(= 좌표가 밀림) 그 차이 × PRESS_GAIN만큼 더 누름.
#   너무 세게 누르면 그 발 하나가 무게를 거의 다 받음 (시뮬레이션: 5mm면 발 하나에 1kg) → 최대 3mm.
DRIFT_GAIN = 0.7
DRIFT_MAX = 8.0
#   높이 기준 맞추기: 이미 기록이 있는 자리(뒤따르는 다리)에 디뎠는데 기록과 높이가 다르면, 그 차이(DRIFT_MAX 이하)는
#   지형이 아니라 '좌표가 밀린 것'으로 보고 지도 전체를 그 차이 × DRIFT_GAIN만큼 옮김.
#   왜: 새 발은 '막 닿은 높이 + 0.5mm'에 놓이는데, 받치던 발들은 무게 때문에 2~3mm 눌려 있음 → 발을 바꿀 때마다
#       명령 좌표가 조금씩 위로 밀림 (시뮬레이션: 한 바퀴에 약 4mm, 몸의 실제 높이는 그대로).
#       안 맞추면 평지에서도 '계단 올라감'으로 착각함.

# ── 3. 몸 ──
H_PREF = 100.0
#   계단 모드에서 몸 높이 기본값 = 발 평면에서 hip 축(몸 좌표 z=0)까지 [mm].
#   hexapod_body 치수 기준 100mm면 서기 폭(hip~발 141mm)에서 tibia가 거의 수직 → 무릎 토크 최소, 계단 앞면에 덜 걸림.
#   (평소 서기 자세는 약 22mm. 들어갈 때 천천히 올라감)
H_MIN, H_MAX = 40.0, 190.0
#   몸 높이 범위 [mm]. 위쪽은 다리가 거의 다 펴지는 높이(약 200) 바로 아래.
#   ★ femur가 수평보다 아래로 내려가는 각도(> 180)는 SDK 주석대로 아직 실측 안 함 → 처음엔 낮은 계단부터.
BODY_BOTTOM = 20.0
#   ★ 실측할 것: hip 축(femur 회전축) 높이에서 몸통 맨 아래(coxa 서보 바닥 포함)까지 [mm].
#     hexapod_body 치수로는 서기 자세에서 hip 축이 바닥 위 약 22mm라서, 이보다 크면 서 있을 때 배가 바닥에 닿아야 함
#     → 실제와 안 맞으면 hexapod_body 치수(다리 길이·서기 자세)부터 의심할 것.
BODY_RADIUS = 125.0
#   ★ 실측할 것: 몸 중심에서 몸통 바닥 가장자리(coxa 서보 포함)까지 [mm].
BODY_CLEAR = 25.0
#   몸 바닥과 (지도상) 계단 사이 최소 여유 [mm]. 노랑/파랑으로 ±10씩.
KNEE_PAD = 22.0
#   ★ 무릎 서보 몸체가 무릎 축보다 아래로 튀어나온 정도 [mm]. 다리가 계단 모서리에 걸리는지 볼 때 씀.
LINK_CLEAR = 6.0          # 다리 링크와 계단 사이 최소 여유 [mm]
PITCH_MAX = 30.0
#   몸 앞뒤 기울기 한계 [도]. 계단 경사(atan(높이/깊이): 140/300 → 25°)보다 커야 뒷다리가 아래 칸에 닿음.
#   160mm 넘는 계단에선 30°에 붙은 채 막힘 (시뮬레이션). 36°로 올려도 160~180mm는 여전히 막혔음.
#   ★ 무게중심이 hip 높이보다 아래에 있으면 몸을 기울일수록 무게중심이 뒤로 감 (COM의 z를 재서 넣으면 계산에 들어감)
ROLL_MAX = 12.0           # 몸 좌우 기울기 한계 [도]
TILT_STEP = 6.0           # 한 번(다리 하나)에 바꾸는 몸 기울기 최대 [도]
COM = (0.0, 0.0, 0.0)
#   ★ 무게중심 위치 (몸 좌표, mm). 배터리·라이다를 한쪽에 달면 바꿀 것.
COM_MARGIN = 35.0
#   다리 하나를 들었을 때, 남은 5발 다각형 변에서 무게중심까지 최소 거리 [mm].
#   키우면 덜 넘어짐, 대신 몸을 더 많이 옆으로 옮겨야 해서 느리고 다리가 더 벌어짐.
JOINT_MARGIN = 3.0        # 관절 각도를 가동범위 끝에서 이만큼[도] 떨어뜨려 씀
ROBOT_MASS = 2000.0
#   ★ 로봇 무게 [g] (프로젝트 추정 1.7~1.94kg → 넉넉히 2000). 저울로 재서 넣을 것.
TORQUE_MAX = 8.5
#   다리 하나를 들었을 때 남은 다리 femur 서보가 버텨야 하는 토크 상한 [kg·cm].
#   하중 = 발 5개가 같은 스프링이라고 보고 무게·모멘트가 맞게 나눈 값, 토크 = 하중 × femur 축~발 수평 거리.
#   근거: 프로젝트 실측 'MG996R이 10cm에서 약 1kg 버팀' ≈ 10kg·cm → 15% 여유.
#   이 자세밖에 없으면 그 다리는 안 들고 다른 다리부터 옮김 (막히면 '토크' 이유로 멈춤).
MIN_FOOT_GAP = 55.0       # 같은 쪽 이웃 발끝 사이 최소 거리 [mm]
RADIAL_TRY = (0.0, 15.0, 30.0, -15.0)
#   발 자리를 hip에서 바깥(+)/안쪽(−)으로 이만큼씩 옮겨서도 찾아봄 [mm]. 몸이 높을 때 기본 자리에 디디면
#   무릎이 발보다 바깥(앞발이면 앞)에 나와서, 아직 모르는 계단에 무릎이 먼저 부딪힐 수 있음 → 바깥에 디디면 피함.
#   대가: 바깥으로 갈수록 femur 토크↑ (모멘트 팔이 길어짐).
POSE_KEEP = 30            # 다리 하나 계획할 때 몸 자세 후보를 이만큼 찾으면 그만 찾음 (계산 시간)
DESCEND_STOP = 30.0
#   앞 바닥이 지금 발보다 이만큼[mm] 넘게 낮으면 '내려가는 계단'으로 보고 그 다리를 되돌리고 멈춤.
#   작으면 울퉁불퉁한 디딤판에서도 멈춤(시뮬레이션: 8mm 울퉁불퉁 + 140mm 계단에서 13mm 차이로 멈췄음).
#   크면 진짜 내려가는 턱을 늦게 알아챔 → 오르기 전용 안전장치라 30mm 정도.
MIN_MOVE = 6.0            # 다리를 이보다 조금 옮기는 계획은 안 씀 (같은 자리에 계속 다시 딛는 '제자리걸음' 방지) [mm]
STALL_STEPS = 12          # 다리를 이만큼 옮겼는데 몸이 STALL_MM도 못 갔으면 '더 못 감'으로 멈춤
STALL_MM = 5.0

# ── 4. 더듬기 (IMU로 닿음 찾기) ──
PROBE_FAST = 40.0         # 공중이 확실한 구간 / 어디서 닿을지 모르는 구간 내리는 속도 [mm/s]
PROBE_SLOW = 12.0         # 지도상 바닥 근처 내리는 속도 [mm/s]
PROBE_SLOW_BAND = 5.0     # 지도상 바닥 위아래 이만큼은 천천히 [mm]
PROBE_EXTRA = 25.0        # 지도상 바닥보다 이만큼 더 내려도 안 닿으면 '바닥 없음' (기록 있는 곳) [mm]
PROBE_MIN_BELOW = 15.0    # 디딜 자리는 다리가 예상 바닥보다 최소 이만큼 더 내려갈 수 있어야 함 [mm] (아니면 다른 자리)
SWING_HIT_DEG = 0.6
#   공중 발을 옆으로 옮기는 동안 몸 기울기가 이만큼[도] 변하면 '뭔가에 걸림' → 멈추고 더 높이 들어서 다시.
#   (발이 계단 앞면을 밀면 몸이 기욺. 다리 무게가 옮겨가서 생기는 변화보다는 커야 함)
LOAD_CHECK = True
#   디딜 때마다 '살짝 들어보기'로 정말 받치는지 확인 (다리마다 약 0.5초 더 걸림).
SAFE_DEV_DEG = 4.0
#   한 발 옮기는 사이에 몸 기울기가 '명령한 만큼'과 이만큼[도] 넘게 다르게 변하면 멈춤 (미끄러짐·넘어짐 감지).
FRAME_GAIN = 0.0
FRAME_MAX_STEP = 1.0
#   좌표 기울기 맞추기 (★ 기본 꺼짐 = 재기만 함): 발을 바꿀 때마다 '명령한 몸 기울기'와 'IMU로 본 실제 몸 기울기'가 조금씩
#   벌어짐 (받치는 발들이 무게로 눌린 정도가 발마다 달라서). 시뮬레이션: 계단 3칸에 pitch 약 4.7° → 앞뒤 발 높이가 27mm 어긋남,
#   꼭대기의 평평한 바닥이 지도에선 4~5° 내리막으로 보였음. 어긋남은 상태 줄 '마지막 어긋남'으로 항상 찍힘.
#   FRAME_GAIN > 0이면 다리 하나 옮긴 뒤마다 그 차이 × FRAME_GAIN만큼(한 번에 FRAME_MAX_STEP°까지) 지도·발·몸 좌표를
#   몸 중심으로 돌림 (관절 각도는 그대로 — 좌표만 실제에 맞춤). 기준 = 계단 모드 들어올 때의 IMU 값.
#   시뮬레이션 (0.5): 어긋남 4.7° → 0.3° 안, 앞뒤 발 높이 어긋남 27mm → 2mm. 그런데 28가지 계단 중 끝까지 간 게
#   23 → 20으로 줄었음 (120mm + 비스듬·울퉁불퉁에서 다리를 어디로도 못 옮기는 멈춤). 그래서 기본은 끔.
#   실물에서 '마지막 어긋남'이 계속 커지면(2~3° 넘게) 0.5로 켜서 비교해볼 것.
#   ★ 계단 모드를 끝낼 때(C 길게)는 FRAME_GAIN과 상관없이 한 번 다 맞춘 다음 '평평한가'를 봄
#     (안 그러면 꼭대기 평지가 6~7° 경사로 보여서 못 끝냈음).

# ═════════════════════════════════════════════════════════════════


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _steps(a, b, step=8.0):
    """a에서 b까지 step 간격 점들 (양 끝 포함)."""
    n = max(1, int(math.ceil(abs(b - a) / step)))
    return [a + (b - a) * k / n for k in range(n + 1)]


def leg_points(l, joints):
    """관절 각도 → 몸 기준 (femur 축, 무릎, 발) 위치."""
    hip, fem, tib = joints
    psi = math.radians((hip - hb.HIP_CENTER) * hb.HIP_SIGN[l])
    a = math.radians(180 - fem)
    b = math.radians(tib)
    ta = a - math.pi + b
    mx, my, th = hb.MOUNT[l]
    ang = math.radians(th) + psi
    c, s = math.cos(ang), math.sin(ang)
    r0 = hb.COXA_LEN
    r1 = r0 + hb.FEMUR_LEN * math.cos(a)
    z1 = hb.FEMUR_LEN * math.sin(a)
    r2 = r1 + hb.TIBIA_LEN * math.cos(ta)
    z2 = z1 + hb.TIBIA_LEN * math.sin(ta)
    return [mx + r0 * c, my + r0 * s, 0.0], [mx + r1 * c, my + r1 * s, z1], [mx + r2 * c, my + r2 * s, z2]


def _hull(pts):
    """볼록 껍질 (반시계)."""
    p = sorted(set((round(x, 3), round(y, 3)) for x, y in pts))
    if len(p) < 3:
        return p

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for q in p:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], q) <= 0:
            lo.pop()
        lo.append(q)
    for q in reversed(p):
        while len(up) >= 2 and cross(up[-2], up[-1], q) <= 0:
            up.pop()
        up.append(q)
    return lo[:-1] + up[:-1]


def support_margin(pts, c):
    """점 c에서 지지 다각형 변까지 최소 거리 [mm]. 밖이면 음수."""
    h = _hull(pts)
    if len(h) < 3:
        return -1e9
    m = float("inf")
    for (x1, y1), (x2, y2) in zip(h, h[1:] + h[:1]):
        L = math.hypot(x2 - x1, y2 - y1)
        if L < 1e-9:
            continue
        m = min(m, ((x2 - x1) * (c[1] - y1) - (y2 - y1) * (c[0] - x1)) / L)
    return m


class Profile:
    """한쪽(왼쪽/오른쪽) 바닥 높이 기록. 세계 x 방향 1차원: [x, z, 종류]
    종류 'foot'(디딘 곳) / 'low'(여긴 기록보다 더 낮음) /
         'nose'(디딤판의 가장 뒤쪽으로 확인된 곳: 앞 모서리가 바로 뒤에 있을 수 있음 → 여기서 EDGE_MARGIN 안쪽부터 디딤)"""

    def __init__(self):
        self.pts = []
        self.xs = []

    def add(self, x, z, kind="foot"):
        self.pts = [p for p in self.pts if abs(p[0] - x) >= MAP_MERGE_DX]
        self.pts.append([x, z, kind])
        self.pts.sort(key=lambda p: p[0])
        self.xs = [p[0] for p in self.pts]

    def prune(self, x_center):
        self.pts = [p for p in self.pts if abs(p[0] - x_center) < MAP_KEEP]
        self.xs = [p[0] for p in self.pts]

    def _around(self, x):
        """x 바로 앞뒤 기록 (없으면 None)."""
        i = bisect.bisect_right(self.xs, x)
        return (self.pts[i - 1] if i > 0 else None), (self.pts[i] if i < len(self.pts) else None)

    def _env_raw(self, x, ahead_extra, sgn):
        lo, hi = self._around(x)
        if lo is not None and hi is not None:
            return max(lo[1], hi[1]) + UNEVEN_PAD
        p = lo if hi is None else hi                     # 기록 범위 밖
        beyond_ahead = (hi is None and sgn > 0) or (lo is None and sgn < 0)
        return p[1] + (ahead_extra if beyond_ahead else 0.0) + UNEVEN_PAD

    def env(self, x, ahead_extra, sgn, dilate=True):
        """x의 바닥이 '가장 높아 봐야' 몇인가 (계단 모서리가 어디 있을지 모르면 높은 쪽으로, ±RISER_SLOP 넓혀서).
        dilate=False: 넓히지 않음 (기록 사이 구간만 높게) — 지금 서 있는 발 바로 위처럼 '여기는 낮은 칸'이 확실한 곳용"""
        if not self.pts:
            return None
        if not dilate:
            return self._env_raw(x, ahead_extra, sgn)
        return max(self._env_raw(x - RISER_SLOP, ahead_extra, sgn), self._env_raw(x, ahead_extra, sgn),
                   self._env_raw(x + RISER_SLOP, ahead_extra, sgn))

    def env_range(self, x0, x1, ahead_extra, sgn):
        a, b = min(x0, x1), max(x0, x1)
        xs = [a, b] + [p[0] for p in self.pts if a <= p[0] <= b]
        n = max(1, int((b - a) / 5.0))
        xs += [a + (b - a) * k / n for k in range(n + 1)]
        v = [self.env(x, ahead_extra, sgn) for x in xs]
        v = [e for e in v if e is not None]
        return max(v) if v else None

    def expect(self, x, sgn):
        """x에 디디면 바닥이 어디쯤일지. (종류, 높이, 정보)
        'known' 기록 근처 / 'flat' 같은 높이 기록 사이 / 'riser' 높이 다른 기록 사이(모서리가 사이 어딘가) /
        'explore' 진행 방향 기록 밖 / 'behind' 반대쪽 기록 밖"""
        if not self.pts:
            return "explore", None, None
        # 기록 맨 끝보다 진행 방향으로 조금이라도 더 나가면 '모르는 곳' (끝 기록 바로 앞에 계단이 있을 수 있음)
        front = max(self.pts, key=lambda q: q[0] * sgn)
        if (x - front[0]) * sgn > 2.0:
            return "explore", front[1], front
        near = [p for p in self.pts if abs(p[0] - x) <= KNOWN_R and p[2] not in ("low", "nose")]
        if near:
            p = min(near, key=lambda q: abs(q[0] - x))
            # 바로 옆 기록과 높이가 크게 다르면(사이에 계단 모서리) 그쪽으로 가까이 디디는 건 위험:
            #   p가 낮은 쪽이면 p 자체가 사실 모서리 위(미끄러져 낮게 기록)였을 수 있고,
            #   p가 높은 쪽이면 p보다 모서리 쪽으로 가면 모서리에 걸침 → '계단 사이'로 보고 확실한 자리로 바꿈
            for q in (self._next(p, 1.0), self._next(p, -1.0)):
                if q is not None and abs(q[1] - p[1]) > FLAT_EPS and \
                        (x - p[0]) * (1.0 if q[0] > p[0] else -1.0) > -RISER_SLOP * (p[1] < q[1]):
                    return "riser", None, ((p, q) if p[0] < q[0] else (q, p))
            return self._nose_guard(x, ("known", p[1], p))
        lo, hi = self._around(x)
        if lo is None or hi is None:
            p = lo or hi
            ahead = (hi is None and sgn > 0) or (lo is None and sgn < 0)
            return self._nose_guard(x, (("explore" if ahead else "behind"), p[1], p))
        if abs(hi[1] - lo[1]) <= FLAT_EPS:
            u = (x - lo[0]) / max(hi[0] - lo[0], 1e-9)
            return self._nose_guard(x, ("flat", lo[1] + (hi[1] - lo[1]) * u, (lo, hi)))
        return "riser", None, (lo, hi)

    def _lower_neighbor(self, n):
        """기록 n 바로 앞/뒤 기록 중 FLAT_EPS보다 낮은 것 (= 그쪽에 계단 모서리)."""
        for q in (self._next(n, -1.0), self._next(n, 1.0)):
            if q is not None and n[1] - q[1] > FLAT_EPS:
                return q
        return None

    def _nose_guard(self, x, res):
        """디딤판 뒤쪽 끝 기록('nose')에서 위 칸 안쪽으로 EDGE_MARGIN이 안 되는 자리면 '계단 사이'로 바꿈
        (모서리가 'nose' 바로 뒤일 수 있으니까. 예: 모서리 확인용으로 20mm 뒤를 더듬은 자리에 다른 다리가 디디면
         모서리에 걸침 → 다시 모서리 확인 → 앞으로 옮김 → 또 그 자리로… 제자리걸음이 됐었음)"""
        z = res[1]
        if z is None:
            return res
        for n in self.pts:
            if n[2] != "nose" or abs(n[1] - z) > FLAT_EPS:
                continue
            q = self._lower_neighbor(n)
            if q is None:
                continue
            inside = (x - n[0]) * (1.0 if n[0] > q[0] else -1.0)     # 모서리 반대쪽(위 칸 안쪽)으로 얼마나
            if -RISER_SLOP < inside < EDGE_MARGIN - 1e-6:
                return "riser", None, ((q, n) if q[0] < n[0] else (n, q))
        return res

    def _next(self, p, sgn):
        """기록 p 다음(sgn 방향) 기록."""
        c = [q for q in self.pts if (q[0] - p[0]) * sgn > 1e-6]
        return min(c, key=lambda q: (q[0] - p[0]) * sgn) if c else None

    def behind_point(self, x, sgn):
        """진행 방향 뒤쪽으로 가장 가까운 기록 (자기 자리 KNOWN_R 안은 뺌)."""
        c = [p for p in self.pts if (x - p[0]) * sgn > KNOWN_R]
        if not c:
            return None
        return max(c, key=lambda p: p[0] * sgn)


class Map:
    def __init__(self):
        self.side = [Profile(), Profile()]

    def side_of(self, y, body_y):
        return 0 if y >= body_y else 1

    def add(self, x, y, z, body_y, kind="foot"):
        self.side[self.side_of(y, body_y)].add(x, z, kind)


class Plan:
    pass


class Frozen(Exception):
    """빨강(얼음) 버튼: 지금 자세 그대로 멈춤 (서보 힘은 유지)."""


class _StopSender:
    """보내기 직전에 얼음 버튼 확인 → 눌렸으면 Frozen (마지막으로 보낸 자세 그대로 멈춤).
    계단 모드의 모든 명령(몸 옮기기·발 옮기기·더듬기)이 여기를 지나감."""

    def __init__(self, sender, climber):
        self._s, self._c = sender, climber

    def send(self, joints):
        f = self._c.stop_req
        if f is not None and f():
            raise Frozen()
        return self._s.send(joints)

    def __getattr__(self, name):
        return getattr(self._s, name)


class StairClimber:
    """계단 모드. hexapod_joy_walk의 Gait에서 넘겨받고, 끝나면 돌려줌.
    좌표: 들어올 때 몸 위치를 원점으로 하는 '세계' 좌표 (x 앞, y 왼쪽, z 위). 몸은 self.pose = [x, y, z, roll, pitch, yaw]."""

    def __init__(self, gait, grounder, leveler, link):
        self.gait, self.lev, self.link = gait, leveler, link
        self.body = gait.body
        self.sender = _StopSender(gait.sender, self)   # 얼음(빨강) 확인 후 보냄
        self.stop_req = None                           # 얼음(빨강) 버튼이 눌렸나 (hexapod_joy_walk가 넣어줌)
        self.frozen = False
        self.swing_ctx = None                          # (다리, 들기 전 자리): 지금 공중에 있는 발
        self.grounder = jw.Grounder(self, leveler)     # 같은 접지 코드를 계단 좌표로 씀
        self.feet = None
        self.last_joints = None
        self.ground = [0.0] * NUM_LEGS
        self.walking = False
        self.active = False
        self.map = Map()
        self.rise_max = RISE_MAX
        self.clear = BODY_CLEAR
        self.last_msg = ""
        self.steps_done = 0
        self.speed = 1.0
        self.last_leg = None
        self.rise_seen = None                          # 지금까지 잰 계단 높이 중 가장 높은 것 [mm]
        self.grounder.holes = []
        self.sgn = 1.0                                 # 지도에서 '앞' (+x 또는 −x)
        self.sgn_up = 1.0
        self.hole_streak = 0                           # 기록 있는 자리인데 '바닥 없음'이 연속으로 나온 횟수
        self.track = deque(maxlen=STALL_STEPS)         # 제자리걸음 감지: 다리 옮길 때마다 몸 위치
        self.imu_prev = None                           # 안전 확인용: 지난 발 다 옮긴 뒤 IMU 값과 그때 명령 기울기
        self.cmd_prev = None
        self.imu_ref = None                            # 좌표 기울기 기준: 계단 모드 들어올 때 (IMU 값, 명령 기울기)
        self.frame_fix = [0.0, 0.0]                    # 지금까지 돌린 양 (roll, pitch) [도]
        self.frame_err = None                          # 마지막으로 본 어긋남 (roll, pitch) [도]

    # Grounder가 부르는 것 (계단 모드에선 할 일 없음)
    def _recheck(self):
        pass

    # ── 들어가기 / 나가기 ──
    def enter(self):
        g, b = self.gait, self.body
        if g.walking:
            print("[계단] 멈춘 다음 들어갈 것")
            return False
        if not (self.link.imu_fresh() and not self.link.imu_err):
            print("[계단] IMU 값이 없음 — 계단 모드는 발로 더듬는 데 IMU가 꼭 필요함")
            return False
        self.feet = [list(f) for f in g.feet]
        p = b.pose
        self.pose = [0.0, 0.0, p[2], p[3], p[4], 0.0]
        b.pose = list(self.pose)
        b.feet = [list(f) for f in self.feet]
        self.last_joints = jw.solve(b, self.pose, self.feet)
        if self.last_joints is None:
            print("[계단] 지금 자세가 계산 안 됨 — " + jw.why_unsolvable(b, self.pose, self.feet))
            return False
        self.home_rel = [[h[0], h[1]] for h in g.home]      # 몸 기준 기본 발 자리 (지금 폭)
        self.h_entry = p[2] - sum(f[2] for f in self.feet) / NUM_LEGS   # 나갈 때 이 높이로 돌아감
        self.lev_was_on = self.lev.on
        self.lev.on = False                                 # 계단에선 몸을 일부러 기울이니까 수평 유지 끔
        self.map = Map()
        for f in self.feet:
            self.map.add(f[0], f[1], f[2], self.pose[1])
        self.drift = 0.0
        self.imu_ref, self.frame_fix, self.frame_err = None, [0.0, 0.0], None
        if not hasattr(self, "press"):
            self.press = PRESS_INIT
        self.active = True
        self.steps_done = 0
        self.last_leg = None
        print(f"[계단] 계단 모드 시작 — 앞발 대비 높이 {self.rise_max:.0f}mm, 몸 바닥 여유 {self.clear:.0f}mm. "
              "조이스틱으로 한 발씩, C 길게 = 끝내기")
        st = self.check_all(quiet=True)
        if st is None:
            if self.frozen:
                return True                                 # 얼음: 계단 모드 안에서 멈춤 (C 짧게로 이어서)
            print("[계단] 접지 확인 중 IMU 끊김 — 계단 모드 취소")
            self._leave()
            return False
        # 먼저 몸을 계단 모드 높이로 (발 6개는 그대로). 평소 서기 높이는 배가 바닥에 가까움
        target = list(self.pose)
        target[2] = self.pose[2] + (H_PREF - self.height())
        for _ in range(4):
            if self._ik(target, self.feet) is not None:
                break
            target[2] -= 0.25 * (target[2] - self.pose[2])
        try:
            if target[2] > self.pose[2] + 1.0 and self.move_body(target):
                print(f"[계단] 몸 높이 {self.height():.0f}mm로 올림")
        except Frozen:
            self._on_frozen()
            return True
        self._mark_imu()
        self._set_frame_ref()
        return True

    def _on_frozen(self):
        self.frozen = True
        lg = "" if self.swing_ctx is None else f" (다리{self.swing_ctx[0]}은 공중)"
        print(f"[계단] ■ 얼음 (빨강) — 지금 자세 그대로 멈춤, 서보 힘은 유지{lg}. "
              "다시 가려면 빨강을 놓고 C 짧게 (발 다시 접지)")
        return "abort"

    def height(self):
        """발 평면에서 몸 중심(hip 축)까지 높이 [mm]."""
        c, a, b_ = self._plane()
        return self.pose[2] - (c + a * self.pose[0] + b_ * self.pose[1])

    def flatness(self):
        """발 6개가 얼마나 평평한가: (평면 기울기°, 평면에서 가장 먼 발 mm)."""
        c, a, b_ = self._plane()
        slope = math.degrees(math.atan(math.hypot(a, b_)))
        res = max(abs(f[2] - (c + a * f[0] + b_ * f[1])) for f in self.feet)
        return slope, res

    def exit(self):
        """평평한 곳에서 걷기 모드로 돌아감. 성공하면 True (얼음이면 False, 계단 모드 유지)."""
        if self.frozen:
            print("[계단] 얼음 상태 — 먼저 C 짧게(발 다시 접지)")
            return False
        try:
            return self._exit()
        except Frozen:
            self._on_frozen()
            return False

    def _exit(self):
        """평평한 곳에서 걷기 모드로 돌아감. 성공하면 True.
        순서: 좌표 기울기를 IMU에 맞춤 → 몸 수평 → 발을 하나씩(5발 지지) 걷기 모드 기본 자리로 → 들어올 때 몸 높이로 → 걷기 모드에 넘김.
        (걷기 모드의 settle()은 발을 3개씩 들어서, 계단을 오른 뒤 흩어진 발 자리에선 무게중심이 밖으로 나갈 수 있음)
        좌표 기울기를 먼저 맞추는 이유: 계단을 오르는 동안 명령 기울기와 실제 기울기가 벌어져서(시뮬레이션: 3칸에 4~6°)
        꼭대기의 평평한 바닥이 좌표상 6~7° 경사로 보임 → '평평하지 않아서 못 끝냄'이 됐었음"""
        self._fix_frame(gain=1.0, max_step=15.0)
        self._mark_imu()                                    # 안전 확인 기준도 새 좌표로 (안 하면 '기울기가 예상과 다름'으로 멈춤)
        slope, res = self.flatness()
        if slope > 6.0 or res > 15.0:
            print(f"[계단] 발이 평평하지 않아서(경사 {slope:.0f}°, 튀는 발 {res:.0f}mm) 못 끝냄 — 평평한 곳까지 가서 다시")
            return False
        target = list(self.pose)
        target[3], target[4] = 0.0, 0.0
        if not self.move_body(target):
            print("[계단] 몸을 수평으로 못 돌림 — 못 끝냄")
            return False
        g = self.gait
        home = g._home_at(1.0)                              # g.reset()이 쓸 기본 자리 (폭 100%)
        if not self._place_home(home):
            print("[계단] 발을 기본 자리로 못 옮김 — 계단 모드 유지. " + self.last_msg)
            return False
        mean_z = sum(f[2] for f in self.feet) / NUM_LEGS
        target = list(self.pose)
        target[2] = mean_z + self.h_entry
        if not self.move_body(target):
            print("[계단] 들어올 때 높이로 못 돌아감 — 지금 높이로 걷기 모드")
        # 몸 기준 좌표로 되돌림 (x, y, yaw = 0)
        x, y, z, ro, pi, ya = self.pose
        cy, sy = math.cos(math.radians(-ya)), math.sin(math.radians(-ya))
        rel = [[cy * (f[0] - x) - sy * (f[1] - y), sy * (f[0] - x) + cy * (f[1] - y), f[2]] for f in self.feet]
        b = self.body
        b.pose = [0.0, 0.0, z, 0.0, 0.0, 0.0]
        b.feet = [list(f) for f in rel]
        self._leave()
        g.reset()
        ok = g.settle()
        print("[계단] 계단 모드 끝 — 걷기 모드" + ("" if ok else " (발 기본 자리로 못 옮김)"))
        return True

    def _place_home(self, home_rel):
        """발을 하나씩 몸 기준 home_rel 자리로 (평평한 곳 전제, 항상 5발 지지 + 무게중심 여유 확인)."""
        p0 = list(self.pose)
        c, s = math.cos(math.radians(p0[5])), math.sin(math.radians(p0[5]))
        targets = [(p0[0] + c * h[0] - s * h[1], p0[1] + s * h[0] + c * h[1]) for h in home_rel]
        # 기본 자리가 전부 '지금 발들과 같은 높이의 확실한 바닥'이어야 함 (계단 끝 모서리 너머면 안 됨)
        for l, (tx, ty) in enumerate(targets):
            prof = self.map.side[self.map.side_of(ty, p0[1])]
            for sg in (1.0, -1.0):
                kind, z, info = prof.expect(tx, sg)
                near_frontier = kind in ("explore", "behind") and info is not None and abs(info[0] - tx) <= 80.0
                if (kind not in ("known", "flat") and not near_frontier) or z is None or \
                        abs(z - self.feet[l][2]) > FLAT_EPS:
                    self.last_msg = (f"다리{l} 기본 자리(x {tx:+.0f})가 확인된 평평한 바닥이 아님 — "
                                     "계단 끝에서 한두 바퀴 더 앞으로 간 다음 다시")
                    return False
        for l in (0, 3, 2, 5, 1, 4):
            f = list(self.feet[l])
            tx, ty = targets[l]
            if math.hypot(f[0] - tx, f[1] - ty) < 2.0:
                continue
            pts5 = [(self.feet[i][0], self.feet[i][1]) for i in range(NUM_LEGS) if i != l]
            cx, cy_ = sum(q[0] for q in pts5) / 5, sum(q[1] for q in pts5) / 5
            for sh in (0.0, 0.3, 0.6, 1.0):                 # 무게중심이 5발 다각형 안쪽에 충분히 있게 몸을 옮김
                t = list(self.pose)
                t[0], t[1] = p0[0] + (cx - p0[0]) * sh, p0[1] + (cy_ - p0[1]) * sh
                if support_margin(pts5, self._com_world(t)[:2]) >= COM_MARGIN and self._ik(t, self.feet):
                    break
            else:
                self.last_msg = f"다리{l}을 들면 무게중심 여유 부족"
                return False
            if (abs(t[0] - self.pose[0]) > 0.5 or abs(t[1] - self.pose[1]) > 0.5) and not self.move_body(t):
                return False
            z = f[2]
            self.swing_ctx = (l, list(f))
            r = self._foot_path(l, [[f[0], f[1], z + REPLACE_LIFT], [tx, ty, z + REPLACE_LIFT]])
            if r != "ok":
                self.last_msg = f"다리{l} 옮기는 경로가 안 닿음"
                self._return_foot(l, f)
                return False
            st, _ = self._land(l, [z], z - PROBE_EXTRA)
            if st != "contact":
                self.last_msg = f"다리{l} 내렸는데 '{st}'"
                self._return_foot(l, f)                     # 공중에 둔 채로 끝내면 안 됨
                return False
            if self.press > 0.05:
                self.grounder._set_foot(l, self.feet[l][2] - self.press)
            self.swing_ctx = None
        return self.move_body(p0)                           # 몸을 원래 자리로 → 발이 전부 기본 자리

    def _leave(self):
        self.active = False
        self.lev.on = getattr(self, "lev_was_on", self.lev.on)

    # ── 기하 ──
    def _plane(self, feet=None):
        """발들에 평면 z = c + a·x + b·y 맞춤."""
        feet = feet or self.feet
        n = len(feet)
        sx = sum(f[0] for f in feet); sy = sum(f[1] for f in feet); sz = sum(f[2] for f in feet)
        sxx = sum(f[0] ** 2 for f in feet); syy = sum(f[1] ** 2 for f in feet); sxy = sum(f[0] * f[1] for f in feet)
        sxz = sum(f[0] * f[2] for f in feet); syz = sum(f[1] * f[2] for f in feet)
        A = [[n, sx, sy, sz], [sx, sxx, sxy, sxz], [sy, sxy, syy, syz]]
        for i in range(3):
            piv = max(range(i, 3), key=lambda r: abs(A[r][i]))
            if abs(A[piv][i]) < 1e-9:
                return sz / n, 0.0, 0.0
            A[i], A[piv] = A[piv], A[i]
            for r in range(3):
                if r != i:
                    f_ = A[r][i] / A[i][i]
                    A[r] = [A[r][c] - f_ * A[i][c] for c in range(4)]
        return A[0][3] / A[0][0], A[1][3] / A[1][1], A[2][3] / A[2][2]

    def _ik(self, pose, feet):
        """역기구학 + 관절 여유 확인. 안 되면 None."""
        joints, _ = self.body._solve(pose, feet)
        if joints is None:
            return None
        for l in range(NUM_LEGS):
            for j in range(NUM_JOINTS):
                lo, hi = JOINT_LIMITS[l][j]
                if not (lo + JOINT_MARGIN <= joints[l][j] <= hi - JOINT_MARGIN):
                    return None
        return joints

    def _to_world(self, pose, p):
        R = hb._rot(pose[3], pose[4], pose[5])
        w = hb._mul(R, p)
        return [w[0] + pose[0], w[1] + pose[1], w[2] + pose[2]]

    def _env(self, x, y, pose, ahead_extra=0.0, dilate=True):
        prof = self.map.side[self.map.side_of(y, pose[1])]
        e = prof.env(x, ahead_extra, self.sgn, dilate)
        return e if e is not None else -1e9

    def _clear_need(self, pose):
        """몸 바닥이 여유 조건보다 얼마나 낮은가 [mm] (0 이하면 OK)."""
        worst = -1e9
        for bx, by in self._body_pts():
            w = self._to_world(pose, [bx, by, -BODY_BOTTOM])
            need = self._env(w[0], w[1], pose) + self.clear - w[2]
            worst = max(worst, need)
        return worst

    @staticmethod
    def _body_pts():
        pts = [(0.0, 0.0)]
        for r in (BODY_RADIUS * 0.55, BODY_RADIUS):
            for k in range(12):
                a = k * math.pi / 6
                pts.append((r * math.cos(a), r * math.sin(a)))
        return pts

    def _frontier_rise(self):
        """발 바로 앞에 있을 수 있는 계단 높이 가정: 계단을 한 번 재봤으면 '잰 높이 + RISE_TOL'(계단은 보통 일정),
        아직이면 RISE_MAX(설정값)."""
        if self.rise_seen:
            return min(self.rise_max, self.rise_seen + RISE_TOL)
        return self.rise_max

    def _leg_clear(self, pose, l, jt, ahead_extra=0.0, foot_on_ground=True, lead_tol=5.0, ref=None, dilate=None):
        """다리 l의 링크(femur·무릎 서보·tibia)가 지도상 바닥보다 LINK_CLEAR 위인가.
        발이 바닥에 있는 자세면: 발보다 진행 방향 앞에 있고 지도 기록 밖(모르는 곳)인 링크는
        '발 바로 앞에서 rise_max 높이 계단이 시작될 수 있다'고 보고 확인
        (높은 계단 앞에서 발보다 앞에 나온 무릎이 먼저 계단에 부딪히는 것 방지).
        ref=(x, z): 그 '발 바로 앞 계단'의 기준 자리 (기본: 지금 발). 발을 들어 올리는 도중이면 들기 전 자리.
          이때는 지도 높이를 넓히지 않음(RISER_SLOP): 발이 서 있던 자리 바로 위는 낮은 칸이 확실하니까
          (넓히면 계단 바로 앞에 선 발은 자기 tibia가 '계단 속'으로 계산돼서 못 듦 — 시뮬레이션에서 뒷다리가 막혔음)"""
        fa, kn, ft = leg_points(l, jt)
        pts = [[fa[k] + (kn[k] - fa[k]) * 0.5 for k in range(3)], kn, [kn[0], kn[1], kn[2] - KNEE_PAD]]
        for u in ((0.25, 0.5, 0.7) if foot_on_ground else (0.25, 0.5, 0.75, 1.0)):
            pts.append([kn[k] + (ft[k] - kn[k]) * u for k in range(3)])
        wf = self._to_world(pose, ft)
        rx, rz = (wf[0], wf[2]) if ref is None else ref
        prof = self.map.side[self.map.side_of(wf[1], pose[1])]
        last = max((p[0] * self.sgn for p in prof.pts), default=None)
        for p in pts:
            w = self._to_world(pose, p)
            e = self._env(w[0], w[1], pose, ahead_extra, dilate=(ref is None) if dilate is None else dilate)
            if (foot_on_ground and last is not None and w[0] * self.sgn > last
                    and (w[0] - rx) * self.sgn > lead_tol):
                e = max(e, rz + self._frontier_rise() + UNEVEN_PAD)
            if w[2] < e + LINK_CLEAR:
                return False
        return True

    def _torque(self, pose, jt, stance, com):
        """stance 발들이 같은 스프링이라고 볼 때 각 발 하중 [g] → femur 토크 [kg·cm] 중 최대와 그 다리."""
        pts = [(self.feet[i][0] - com[0], self.feet[i][1] - com[1]) for i in stance]
        n = len(pts)
        sx = sum(p[0] for p in pts); sy = sum(p[1] for p in pts)
        sxx = sum(p[0] ** 2 for p in pts); syy = sum(p[1] ** 2 for p in pts); sxy = sum(p[0] * p[1] for p in pts)
        # F_i = a + b·x_i + c·y_i,  ΣF = W,  ΣF·x = 0,  ΣF·y = 0
        A = [[n, sx, sy, ROBOT_MASS], [sx, sxx, sxy, 0.0], [sy, sxy, syy, 0.0]]
        for i in range(3):
            piv = max(range(i, 3), key=lambda r: abs(A[r][i]))
            if abs(A[piv][i]) < 1e-9:
                return 1e9, -1
            A[i], A[piv] = A[piv], A[i]
            for r in range(3):
                if r != i:
                    f_ = A[r][i] / A[i][i]
                    A[r] = [A[r][c] - f_ * A[i][c] for c in range(4)]
        a_, b_, c_ = (A[k][3] / A[k][k] for k in range(3))
        worst, wl = 0.0, -1
        for (px, py), i in zip(pts, stance):
            F = a_ + b_ * px + c_ * py
            fa = self._to_world(pose, leg_points(i, jt[i])[0])
            arm = math.hypot(self.feet[i][0] - fa[0], self.feet[i][1] - fa[1])
            t = max(F, 0.0) * arm / 10000.0
            if t > worst:
                worst, wl = t, i
        return worst, wl

    def _com_world(self, pose):
        return self._to_world(pose, list(COM))

    # ── 보내기 ──
    def _send(self, pose, feet, joints):
        if not self.sender.send(joints):
            raise ConnectionError("전송 실패")
        self.pose, self.feet, self.last_joints = list(pose), [list(f) for f in feet], joints
        self.body.pose = list(pose)
        self.body.feet = [list(f) for f in feet]

    def move_body(self, target, sec=None):
        """발 6개는 그대로, 몸만 target 자세로 (경로 전체를 먼저 계산 → 중간에 막히면 아예 안 움직임)."""
        p0 = list(self.pose)
        d = math.hypot(target[0] - p0[0], target[1] - p0[1])
        dz = abs(target[2] - p0[2])
        da = max(abs(target[3] - p0[3]), abs(target[4] - p0[4]), abs(math.degrees(target[5] - p0[5])))
        sp = self.speed
        if sec is None:
            sec = max(d / (BODY_SPEED * sp), dz / (BODY_Z_SPEED * sp), da / (BODY_ROT_SPEED * sp), 0.05)
        n = max(1, round(sec * jw.LOOP_HZ))
        path = []
        prev = self.last_joints
        for k in range(1, n + 1):
            e = 0.5 - 0.5 * math.cos(math.pi * k / n)
            pose = [a + (b - a) * e for a, b in zip(p0, target)]
            jt = jw.solve(self.body, pose, self.feet)
            if jt is None:
                self.last_msg = "몸 옮기는 중간 자세에서 다리가 안 닿음 — " + jw.why_unsolvable(self.body, pose, self.feet)
                return False
            path.append((pose, jt))
            prev = jt
        # 관절 속도 확인 → 너무 빠르면 시간을 늘려서 다시
        worst = max(jw.max_delta(a[1], b[1]) for a, b in zip([(None, self.last_joints)] + path[:-1], path))
        lim = jw.JOINT_SPEED_MAX / jw.LOOP_HZ
        if worst > lim * 1.01 and n < 2000:
            return self.move_body(target, sec * worst / lim * 1.05)
        for pose, jt in path:
            self._send(pose, self.feet, jt)
            time.sleep(1.0 / jw.LOOP_HZ)
        _ = prev
        return True

    def _foot_path(self, l, pts, speed=None, watch=False):
        """다리 l 발을 점들을 따라 직선으로 옮김 (몸·다른 발 그대로). watch=True면 IMU로 걸림 감시.
        'ok' / 'hit' / 'ik'(계산 안 됨, 안 움직임)"""
        speed = (speed or FOOT_SPEED) * self.speed
        cur = list(self.feet[l])
        frames = []
        for q in pts:
            L = math.dist(cur, q)
            n = max(1, round(L / speed * jw.LOOP_HZ))
            for k in range(1, n + 1):
                e = 0.5 - 0.5 * math.cos(math.pi * k / n)
                frames.append([cur[i] + (q[i] - cur[i]) * e for i in range(3)])
            cur = list(q)
        path = []
        feet = [list(f) for f in self.feet]
        for f in frames:
            feet[l] = f
            jt = jw.solve(self.body, self.pose, feet)
            if jt is None:
                self.last_msg = f"다리{l} 공중 경로가 안 닿음 — " + jw.why_unsolvable(self.body, self.pose, feet)
                return "ik"
            path.append(([list(x) for x in feet], jt))
        # 관절 속도 확인
        prev = self.last_joints
        worst = 0.0
        for _, jt in path:
            worst = max(worst, jw.max_delta(jt, prev))
            prev = jt
        lim = jw.JOINT_SPEED_MAX / jw.LOOP_HZ
        if worst > lim * 1.01 and speed > 5.0:
            return self._foot_path(l, pts, speed / self.speed * lim / worst * 0.95, watch)
        base = None
        if watch:
            self.grounder.last_cmd = time.monotonic()
            self.grounder.wait_still(max_sec=0.3, after_cmd=False)
            base = self.link.imu_recent(5)
        for feet_k, jt in path:
            self._send(self.pose, feet_k, jt)
            time.sleep(1.0 / jw.LOOP_HZ)
            if base is not None:
                t = self.link.imu_recent(4)
                if t is not None and math.hypot(t[0] - base[0], t[1] - base[1]) > SWING_HIT_DEG:
                    return "hit"
        self.grounder.last_cmd = time.monotonic()
        return "ok"

    # ── 계획 ──
    def _order_key(self, l, dirb):
        h = self.home_rel[l]
        return -(h[0] * dirb[0] + h[1] * dirb[1])

    def _target_body(self, l, dirb, turn, frac):
        """몸 기준 목표 발 자리 (진행 방향으로 STRIDE/2 × frac 앞, 회전이면 그만큼 돌림)."""
        h = self.home_rel[l]
        a = math.radians(TURN_PER_CYCLE / 2 * turn * frac)
        c, s = math.cos(a), math.sin(a)
        x, y = c * h[0] - s * h[1], s * h[0] + c * h[1]
        return x + dirb[0] * STRIDE / 2 * frac, y + dirb[1] * STRIDE / 2 * frac

    def _foot_rel(self, l, pose):
        """지금 발 위치를 몸 기준으로 (수평만)."""
        f = self.feet[l]
        c, s = math.cos(-pose[5]), math.sin(-pose[5])
        dx, dy = f[0] - pose[0], f[1] - pose[1]
        return c * dx - s * dy, s * dx + c * dy

    def _urgency(self, l, dirb, turn):
        tx, ty = self._target_body(l, dirb, turn, 1.0)
        fx, fy = self._foot_rel(l, self.pose)
        return math.hypot(tx - fx, ty - fy)

    def _posture(self, xb, yb):
        """발 평면에 맞춘 몸 기울기·평면 높이. (평면 높이 at 몸 중심, roll, pitch)"""
        c, a, b_ = self._plane()
        pitch_t = _clamp(-math.degrees(math.atan(a)), -PITCH_MAX, PITCH_MAX)
        roll_t = _clamp(math.degrees(math.atan(b_)), -ROLL_MAX, ROLL_MAX)
        p0 = self.pose
        pitch = p0[4] + _clamp(pitch_t - p0[4], -TILT_STEP, TILT_STEP)
        roll = p0[3] + _clamp(roll_t - p0[3], -TILT_STEP, TILT_STEP)
        return c + a * xb + b_ * yb, roll, pitch

    def _expect(self, l, x, y, pose):
        """다리 l을 (x, y)에 디딜 때: (종류, 후보 높이들, 정보)."""
        prof = self.map.side[self.map.side_of(y, pose[1])]
        return prof.expect(x, self.sgn)

    def _snap(self, l, x, y, pose):
        """목표 자리가 '모서리가 어딘지 모르는 구간'이면 양쪽의 확실한 자리로 바꿔봄. [(x, 종류, 높이)] 선호 순.
        낮은 쪽은 기록보다 RISER_SLOP 뒤 (그 기록이 사실 모서리 위였을 수 있어서)."""
        kind, z, info = self._expect(l, x, y, pose)
        if kind != "riser":
            return [(x, kind, z)]
        lo, hi = info
        up, dn = (hi, lo) if hi[1] > lo[1] else (lo, hi)
        away = 1.0 if dn[0] < up[0] else -1.0             # 낮은 쪽에서 계단 반대 방향 (= 위 칸 안쪽)
        out = []
        if up[2] != "low":                                # 위 칸: 그 기록 자리 ('nose'면 EDGE_MARGIN 안쪽)
            out.append((up[0] + (away * EDGE_MARGIN if up[2] == "nose" else 0.0), "known", up[1]))
        if dn[2] not in ("low", "nose"):                  # 아래 칸: 기록보다 RISER_SLOP 뒤
            out.append((dn[0] - away * RISER_SLOP, "known", dn[1]))
        if self.sgn * (up[0] - dn[0]) < 0:
            out.reverse()
        return out

    def _plan(self, l, dirb, turn):
        """다리 l을 옮기는 계획. 되면 Plan, 안 되면 None (self.last_msg에 이유).
        순서: 몸을 많이 옮기는 것 → 발을 멀리 옮기는 것 → 선호 자세(기울기 그대로, 기본 높이)에 가까운 것."""
        p0 = self.pose
        ya = p0[5]
        c, s = math.cos(ya), math.sin(ya)
        d_o = (c * dirb[0] - s * dirb[1], s * dirb[0] + c * dirb[1])
        mag = math.hypot(*dirb)
        adv = STRIDE / 6 * mag
        dyaw = math.radians(TURN_PER_CYCLE / 6 * turn)
        stance = [i for i in range(NUM_LEGS) if i != l]
        pts5 = [(self.feet[i][0], self.feet[i][1]) for i in stance]
        cx, cy = sum(p[0] for p in pts5) / 5, sum(p[1] for p in pts5) / 5
        why = "후보 없음"
        for adv_f in (1.0, 0.5, 0.0):
            xb = p0[0] + d_o[0] * adv * adv_f
            yb = p0[1] + d_o[1] * adv * adv_f
            yawb = ya + dyaw * adv_f
            poses = []
            # 목표 높이: 보통 H_PREF, 앞쪽(모르는 곳)을 더듬을 다리면 더 높게 (높이 들어야 하고, 무릎 서보가 계단을 넘어야 함)
            fx_, fy_ = self._target_body(l, dirb, turn, 1.0)
            kind0, _, _ = self._expect(l, xb + c * fx_ - s * fy_, yb + s * fx_ + c * fy_, p0)
            h_t = H_PREF if kind0 not in ("explore", "behind") else _clamp(self._frontier_rise() + 15.0, H_PREF, H_MAX)
            h_now = round(self.height())
            heights = sorted({h_t, h_t + 10, h_t - 10, h_t + 20, h_t - 20, h_t + 35, h_t - 35, h_t + 50, h_t - 50,
                              h_t + 70, h_t + 90, h_now}, key=lambda h: (abs(h - h_t), h < h_t))
            for sh in (0.0, 0.35, 0.7, 1.0):                   # 무게중심: 5발 다각형 안쪽으로 (필요하면 옮김)
                xs, ys = xb + (cx - xb) * sh, yb + (cy - yb) * sh
                zp, roll, pitch = self._posture(xs, ys)
                tilts = [(roll * pf, pitch * pf) for pf in (1.0, 0.6, 0.3, 0.0)] + [(p0[3], p0[4])]
                h_clear = []
                for ro_c, pi_c in tilts:                       # 그 기울기에서 몸 바닥 여유를 지키는 최소 높이
                    h_clear.append(H_PREF + self._clear_need([xs, ys, zp + H_PREF, ro_c, pi_c, yawb]))
                for h in heights:                              # 목표 높이에 가까운 것부터 (기울기 변형은 그 안에서)
                    for (ro_c, pi_c), hc in zip(tilts, h_clear):
                        hh = max(h, hc)
                        if not (H_MIN <= hh <= H_MAX) or (hh > h + 1e-6 and h != heights[0]):
                            continue                           # 여유 때문에 높인 건 목표 높이 후보에서만 (중복 방지)
                        pose = [xs, ys, zp + hh, ro_c, pi_c, yawb]
                        com = self._com_world(pose)
                        if support_margin(pts5, com[:2]) < COM_MARGIN:
                            why = f"다리{l}을 들면 무게중심 여유 {COM_MARGIN:.0f}mm 부족"
                            continue
                        jt = self._ik(pose, self.feet)
                        if jt is None:
                            why = "이 몸 자세에서 바닥 발이 안 닿음"
                            continue
                        tq, tl = self._torque(pose, jt, stance, com)
                        if tq > TORQUE_MAX:
                            why = f"다리{l}을 들면 다리{tl} femur 토크 {tq:.1f}kg·cm > {TORQUE_MAX}"
                            continue
                        # 다리 6개 모두 (들 다리도 들기 전까지는 원래 자리에 서 있음) + 몸 옮기는 중간 자세도
                        if not all(self._leg_clear(pose, i, jt[i]) for i in range(NUM_LEGS)):
                            why = "다리 링크(무릎 등)가 계단 모서리에 걸림"
                            continue
                        mid = [(a_ + b_) / 2 for a_, b_ in zip(p0, pose)]
                        jm = self._ik(mid, self.feet)
                        if jm is None or not all(self._leg_clear(mid, i, jm[i]) for i in range(NUM_LEGS)):
                            why = "몸 옮기는 도중에 다리가 안 닿거나 링크가 계단에 걸림"
                            continue
                        poses.append((pose, jt))
                        if len(poses) >= POSE_KEEP:
                            break
                    if len(poses) >= POSE_KEEP:
                        break
                if len(poses) >= POSE_KEEP:
                    break
            for frac in (1.0, 0.75, 0.5, 0.25, -0.25):
                for pose, jt in poses:
                    plan = self._plan_swing(l, pose, dirb, turn, jt, fracs=(frac,))
                    if plan is not None:
                        plan.adv_f = adv_f
                        return plan
                    why = self.last_msg
        self.last_msg = why
        return None

    def _plan_swing(self, l, pose, dirb, turn, jt_stance, fracs=(1.0, 0.75, 0.5, 0.25, -0.25)):
        """몸이 pose일 때 다리 l의 목표 자리·들 높이. 안 되면 None."""
        side = self.map.side_of(self.feet[l][1], pose[1])
        prof = self.map.side[side]
        f0 = self.feet[l]
        c, s = math.cos(pose[5]), math.sin(pose[5])
        hx_, hy_ = self.home_rel[l]
        mx, my = hb.MOUNT[l][0], hb.MOUNT[l][1]
        rl = math.hypot(hx_ - mx, hy_ - my)
        ux, uy = (hx_ - mx) / rl, (hy_ - my) / rl             # hip → 기본 자리 방향 (몸 기준)
        targets = []
        for frac in fracs:
            for rad in RADIAL_TRY:                            # 발을 바깥으로 놓으면 무릎이 발보다 안쪽(뒤)에 옴
                tbx, tby = self._target_body(l, dirb, turn, frac)
                tbx, tby = tbx + ux * rad, tby + uy * rad
                targets.append((frac, pose[0] + c * tbx - s * tby, pose[1] + s * tbx + c * tby))
        for frac, tx, ty in targets:
            for x2, kind, z_exp in self._snap(l, tx, ty, pose):
                y2 = ty
                if math.hypot(x2 - f0[0], y2 - f0[1]) < MIN_MOVE:
                    self.last_msg = f"다리{l}을 옮길 자리가 지금 자리와 거의 같음"
                    continue
                if kind in ("explore", "behind"):
                    z_ref = z_exp if z_exp is not None else f0[2]
                    cands = [z_ref]
                    if self.rise_seen:
                        cands += [z_ref + self.sgn_up * self.rise_seen]
                    top = z_ref + self.rise_max
                    bottom = z_ref - self.rise_max
                    explore = True
                else:
                    z_ref = z_exp
                    cands = [z_ref]
                    top = z_ref + UNEVEN_PAD
                    bottom = z_ref - PROBE_EXTRA
                    explore = False
                if not explore and z_ref < f0[2] - DESCEND_STOP:
                    self.last_msg = f"다리{l} 다음 자리가 {f0[2] - z_ref:.0f}mm 낮음 — 내려가는 계단은 아직 지원 안 함"
                    continue
                env = prof.env_range(f0[0], x2, self.rise_max if explore else 0.0, self.sgn)
                z_lift = max(env if env is not None else f0[2], f0[2], top) + SWING_CLEAR
                # 같은 쪽 이웃 발과 간격
                if any(math.hypot(x2 - self.feet[i][0], y2 - self.feet[i][1]) < MIN_FOOT_GAP
                       for i in range(NUM_LEGS) if i != l):
                    self.last_msg = f"다리{l} 목표 자리가 이웃 발과 너무 가까움"
                    continue
                feet = [list(f) for f in self.feet]

                def reach(px, py, pz):
                    feet[l] = [px, py, pz]
                    return self._ik(pose, feet)

                jt_t = reach(x2, y2, z_ref)                     # 먼저 싼 확인: 디딘 자세가 되나
                if jt_t is None or not self._leg_clear(pose, l, jt_t[l], 0.0, foot_on_ground=True, lead_tol=-2.0):
                    self.last_msg = f"다리{l} 목표 자리에 디딘 자세가 안 됨/걸림"
                    continue
                if reach(x2, y2, z_lift) is None or reach(f0[0], f0[1], z_lift) is None:
                    self.last_msg = f"다리{l}을 {z_lift - f0[2]:.0f}mm 들 수 없음"
                    continue
                # 들기·내리기 경로 전체가 닿아야 함 (발 높이에 따라 '중간만 안 닿는' 구간이 있음:
                #  hip 축보다 조금 높은 곳은 femur가 하한 62°를 넘어야 해서 안 되고, 더 높으면 무릎을 접어서 다시 됨)
                ok = all(reach(f0[0], f0[1], z) is not None for z in _steps(f0[2], z_lift))
                ok = ok and all(reach(f0[0] + (x2 - f0[0]) * u, f0[1] + (y2 - f0[1]) * u, z_lift) is not None
                                for u in (0.25, 0.5, 0.75, 1.0))
                ok = ok and all(reach(x2, y2, z) is not None for z in _steps(z_lift, z_ref - 3.0))
                chk = [(f0[0], f0[1], z_lift, False), ((f0[0] + x2) / 2, (f0[1] + y2) / 2, z_lift, False),
                       (x2, y2, z_lift, False), (x2, y2, z_ref, True)]
                for (px, py, pz, on_ground) in chk:
                    if not ok:
                        break
                    jt = reach(px, py, pz)
                    # 디딘 자세는 '그 높이에 바닥이 있다'고 보고 확인 (모르는 앞쪽 계단까지 가정하면 앞발이 못 나감)
                    # 새로 디디는 자세: 발보다 앞에 나온 링크는 모르는 계단을 엄격히 가정 (lead_tol −2mm)
                    if jt is None or not self._leg_clear(pose, l, jt[l], self.rise_max if explore and not on_ground else 0.0,
                                                         foot_on_ground=on_ground, lead_tol=-2.0):
                        ok = False
                # 들어 올리는 도중·내리는 도중 자세도: 몸이 높고 발이 hip에 가까우면 무릎 서보가 발보다 조금 앞에 옴
                #  → 발 바로 앞에 모르는 계단이 있으면 들면서 그 앞면을 긁음 (시뮬레이션: 140mm 계단 앞에서 10mm 파고듦)
                #  기준 = 들기 전 바닥 / 디딜 자리 바닥
                for z in (_steps(f0[2], z_lift, 16.0)[1:-1] if ok else ()):
                    jt = reach(f0[0], f0[1], z)
                    if jt is None or not self._leg_clear(pose, l, jt[l], 0.0, foot_on_ground=True, lead_tol=0.0,
                                                         ref=(f0[0], f0[2])):
                        ok = False
                        break
                for z in (_steps(z_lift, z_ref, 16.0)[1:-1] if ok else ()):
                    jt = reach(x2, y2, z)
                    if jt is None or not self._leg_clear(pose, l, jt[l], 0.0, foot_on_ground=True, lead_tol=-2.0,
                                                         ref=(x2, z_ref)):
                        ok = False
                        break
                if not ok:
                    self.last_msg = f"다리{l}을 {z_lift - f0[2]:.0f}mm 들어 옮기는 경로가 안 닿음/걸림"
                    continue
                # 더듬을 수 있는 가장 낮은 곳 (예상 바닥 아래로 이어서 닿는 데까지)
                z_low = z_ref - 3.0
                while z_low - 5.0 >= bottom and reach(x2, y2, z_low - 5.0) is not None:
                    z_low -= 5.0
                if z_ref - z_low < PROBE_MIN_BELOW - 1e-6 and bottom < z_ref - PROBE_MIN_BELOW:
                    # 예상보다 조금만 낮아도 '바닥 없음'이 돼버리는 자리 (다리가 거의 다 펴짐) → 다른 자리
                    self.last_msg = f"다리{l} 목표 자리에서 예상 바닥 아래로 {PROBE_MIN_BELOW:.0f}mm를 못 더듬음"
                    continue
                pl = Plan()
                pl.leg, pl.pose, pl.target = l, pose, (x2, y2)
                pl.z_lift, pl.cands, pl.z_low, pl.explore, pl.kind = z_lift, cands, z_low, explore, kind
                pl.frac = frac
                return pl
        return None

    # ── 한 발 ──
    def step(self, fwd, side, turn, speed01=1.0):
        """다리 하나 옮김 (몇 초 걸림). 'ok' / 'skip'(옮길 필요 없음) / 'stuck' / 'hole' / 'blocked' / 'abort'"""
        if not self.active:
            return "abort"
        if self.frozen:
            print("[계단] 얼음 상태 — 빨강을 놓고 C 짧게(발 다시 접지)를 먼저")
            return "abort"
        try:
            return self._step(fwd, side, turn, speed01)
        except Frozen:
            return self._on_frozen()

    def _step(self, fwd, side, turn, speed01):
        self.t_step = time.monotonic()                      # 다리 하나 옮기는 데 걸린 시간 (로그용)
        self.speed = SPEED_SCALE_MIN + (1.0 - SPEED_SCALE_MIN) * _clamp(speed01, 0.0, 1.0)
        mag = math.hypot(fwd, side)
        dirb = (fwd / mag, side / mag) if mag > 1e-6 else (0.0, 0.0)
        if mag < 1e-6 and not turn:
            return "skip"
        if dirb[0] < -0.3:
            self.last_msg = "계단 모드에서는 뒤로 안 감 (내려가기는 아직 지원 안 함) — 옆·회전·앞만"
            print("[계단] " + self.last_msg)
            return "stuck"
        c, s = math.cos(self.pose[5]), math.sin(self.pose[5])
        dox = c * dirb[0] - s * dirb[1]
        self.sgn = 1.0 if dox >= 0 else -1.0                # 지도에서 '앞'
        self.sgn_up = 1.0                                   # 탐색 때 '다음 계단은 위' 쪽을 먼저 의심
        if not self._safety_ok():
            return "abort"
        legs = sorted(range(NUM_LEGS), key=lambda l: (-round(self._urgency(l, dirb, turn) / 10.0),
                                                     self._order_key(l, dirb)))
        if self.last_leg is not None and len(legs) > 1 and legs[0] == self.last_leg:
            legs = legs[1:] + legs[:1]
        plan = None
        reasons = []
        for l in legs:
            if self._urgency(l, dirb, turn) < 8.0:
                continue
            plan = self._plan(l, dirb, turn)
            if plan is not None:
                break
            reasons.append(f"다리{l}({LEG_NAME[l]}): {self.last_msg}")
        if plan is None:
            if not reasons:
                return "skip"
            self.last_msg = " / ".join(reasons[:3])
            print("[계단] 더 못 감 — " + self.last_msg)
            return "stuck"
        if reasons:                                         # 제일 급한 다리를 못 옮기고 다른 다리를 옮김
            print(f"[계단] (먼저 옮겨야 할 {reasons[0]} → 다리{plan.leg}부터)")
        if not self.move_body(plan.pose):
            print("[계단] 몸 옮기기 실패 — " + self.last_msg)
            return "stuck"
        if not self._safety_ok(after_move=True):
            return "abort"
        res = self._swing(plan)
        if res in ("ok", "skip"):
            self.grounder.last_cmd = time.monotonic()
            self.grounder.wait_still(max_sec=0.3, after_cmd=False)
            self._fix_frame()
            self._mark_imu()
        if res == "ok":
            self.steps_done += 1
            self.hole_streak = 0
            self.last_leg = plan.leg
            if mag > 1e-6:                                  # 앞뒤·옆으로 갈 때만 (제자리 회전은 제외)
                self.track.append((self.pose[0], self.pose[1], dirb))
                if len(self.track) >= STALL_STEPS:
                    (x0, y0, d0), (x1, y1, _) = self.track[-STALL_STEPS], self.track[-1]
                    c0, s0 = math.cos(self.pose[5]), math.sin(self.pose[5])
                    dxo, dyo = c0 * d0[0] - s0 * d0[1], s0 * d0[0] + c0 * d0[1]
                    if (x1 - x0) * dxo + (y1 - y0) * dyo < STALL_MM:
                        self.track.clear()
                        self.last_msg = (f"다리를 {STALL_STEPS}번 옮겼는데 몸이 {STALL_MM:.0f}mm도 못 감 — "
                                         "앞발 대비 높이(조이스틱 누름)를 낮추거나 방향을 바꿔볼 것")
                        print("[계단] " + self.last_msg)
                        return "stuck"
            for p in self.map.side:
                p.prune(self.pose[0])
        return res

    def _probe_plan(self, z0, cands, z_low):
        """경과 시간 → 내릴 깊이. 지도상 후보 높이 근처만 천천히."""
        sp = self.speed
        zones = sorted((z0 - z - PROBE_SLOW_BAND, z0 - z + PROBE_SLOW_BAND) for z in cands if z < z0)
        segs, d = [], 0.0
        total = z0 - z_low
        for a, b in zones:
            a, b = max(a, d), min(b, total)
            if b <= a:
                continue
            if a > d:
                segs.append((a - d, PROBE_FAST * sp))
            segs.append((b - a, PROBE_SLOW * sp))
            d = b
        if total > d:
            segs.append((total - d, PROBE_FAST * sp))
        segs.append((1e9, PROBE_FAST * sp))

        def plan(el):
            dd = 0.0
            for length, speed in segs:
                t_seg = length / speed
                if el <= t_seg:
                    return dd + speed * el
                dd += length
                el -= t_seg
            return dd
        return plan

    def _land(self, l, cands, z_low):
        """다리 l을 지금 자리에서 내려서 닿는 곳을 찾음. (상태, 닿은 높이)"""
        z0 = self.feet[l][2]
        start = self.grounder._tilt()
        if start is None:
            return "abort", None
        expect = max(0.0, z0 - max(cands))
        r = self.grounder.probe(l, start, expect=expect, plan=self._probe_plan(z0, cands, z_low),
                                max_down=max(0.0, z0 - z_low))
        st = r["status"]
        if st == "already" and z0 - max(cands) > 5.0:
            # 공중에서 시작했는데 '처음부터 닿아 있음' = 내리기 시작할 때 흔들림을 닿음으로 착각했을 가능성 → 한 번 더
            start = self.grounder._tilt()
            if start is None:
                return "abort", None
            r = self.grounder.probe(l, start, expect=expect, plan=self._probe_plan(z0, cands, z_low),
                                    max_down=max(0.0, z0 - z_low))
            st = r["status"]
        if st == "contact":
            return "contact", self.feet[l][2] + jw.GROUND_PRELOAD_MM
        if st == "already":
            return "contact", z0
        return st, None

    def _swing(self, pl):
        self.swing_ctx = (pl.leg, list(self.feet[pl.leg]))
        r = self._swing_inner(pl)
        self.swing_ctx = None                               # 얼음(Frozen)으로 빠져나가면 남아 있음 → C 짧게에서 되돌림
        return r

    def _swing_inner(self, pl):
        l = pl.leg
        f0 = list(self.feet[l])
        x2, y2 = pl.target
        name = f"다리{l}({LEG_NAME[l]})"
        # 1) 들기
        if self._foot_path(l, [[f0[0], f0[1], pl.z_lift]]) != "ok":
            print(f"[계단] {name} 들기 실패 — {self.last_msg}")
            return "stuck"
        # 2) 옮기기 (걸림 감시) — 걸리면 한 번 더 높이 들어서 다시
        r = self._foot_path(l, [[x2, y2, pl.z_lift]], watch=True)
        if r == "hit":
            higher = pl.z_lift + 25.0
            print(f"[계단] {name} 옮기다 뭔가에 걸림 (기울기 {SWING_HIT_DEG}° 넘게 변함) — {higher - f0[2]:.0f}mm로 더 들어서 다시")
            cur = list(self.feet[l])
            back = self._foot_path(l, [[f0[0], f0[1], cur[2]], [f0[0], f0[1], higher]])
            r = self._foot_path(l, [[x2, y2, higher]], watch=True) if back == "ok" else "ik"
            if r != "ok":
                print(f"[계단] {name} 또 걸림/못 듦 — 원래 자리로 되돌림. 계단이 대비 높이({self.rise_max:.0f}mm)보다 높거나 "
                      "앞이 막혔을 수 있음")
                self._return_foot(l, f0)
                self.last_msg = "앞이 막힘"
                return "blocked"
        elif r != "ok":
            print(f"[계단] {name} 옮기기 실패 — {self.last_msg}")
            self._return_foot(l, f0)
            return "stuck"
        # 3) 내리면서 닿는 곳 찾기
        st, zc = self._land(l, pl.cands, pl.z_low)
        if st != "contact":
            what = {"none": "바닥 없음", "reach": "다리가 더 못 뻗음", "abort": "IMU 끊김/크게 기울어짐"}.get(st, st)
            print(f"[계단] {name} 내렸는데 {what} — 원래 자리로 되돌림")
            prof = self.map.side[self.map.side_of(y2, self.pose[1])]
            if st in ("none", "reach"):
                prof.add(x2, self.feet[l][2] - 1.0, "low")
            self._return_foot(l, f0)
            self.last_msg = what
            if st in ("none", "reach") and pl.kind in ("known", "flat", "riser") and self.hole_streak < 2:
                self.hole_streak += 1                       # 지도가 살짝 어긋났을 수 있음 → 그 자리는 '낮음'으로 기록됐으니 다른 자리로
                return "skip"
            return "hole" if st in ("none", "reach") else "abort"
        # 3-1) 더듬어 봤더니 바닥이 크게 낮음 = 내려가는 계단/턱 → 계단 모드는 아직 내려가기를 안 함 → 되돌리고 멈춤
        if pl.explore and zc < pl.cands[0] - DESCEND_STOP:
            print(f"[계단] {name} 앞 바닥이 {pl.cands[0] - zc:.0f}mm 낮음 (내려가는 계단?) — 계단 모드는 아직 내려가기를 "
                  "안 해서 원래 자리로 되돌리고 멈춤")
            self.map.side[self.map.side_of(y2, self.pose[1])].add(x2, zc, "foot")
            self._return_foot(l, f0)
            self.last_msg = "앞이 낮아짐 (내려가는 계단은 아직 지원 안 함)"
            return "hole"
        # 4) 계단을 처음 밟았으면 모서리 확인
        prof = self.map.side[self.map.side_of(y2, self.pose[1])]
        bp = prof.behind_point(x2, self.sgn)
        stepped_up = bp is not None and zc - bp[1] > FLAT_EPS
        if stepped_up:
            res = self._edge_check(l, x2, y2, zc, bp, prof, f0)
            if res != "ok":
                return res
            zc = self.feet[l][2] + jw.GROUND_PRELOAD_MM
            x2 = self.feet[l][0]
            rise = zc - bp[1]
            # 잰 계단 높이: 지금까지 중 가장 높은 것 (뒤에서 '모르는 계단 앞면' 가정에 씀 → 낮게 잡히면 무릎이 걸림)
            # 작은 턱(울퉁불퉁)은 계단으로 안 셈: max(30mm, 대비 높이의 절반) 이상만
            if rise >= max(30.0, 0.5 * self.rise_max):
                self.rise_seen = max(self.rise_seen or 0.0, rise)
        # 5) 정말 받치나
        if LOAD_CHECK:
            ls, d_up, depth, d = self.grounder.check_leg(l, self.grounder._tilt() or (0.0, 0.0))
            if ls == "lowered":
                zc = self.feet[l][2] + jw.GROUND_PRELOAD_MM
            elif ls == "none":
                print(f"[계단] {name} 받치는 곳을 못 찾음 — 원래 자리로 되돌림")
                self._return_foot(l, f0)
                return "hole"
            elif ls == "abort":
                return "abort"
        if pl.kind in ("known", "flat") and not stepped_up:
            dz = zc - pl.cands[0]
            if abs(dz) <= DRIFT_MAX:
                self._shift_map(DRIFT_GAIN * dz)
                if pl.kind == "known":
                    self.press = _clamp(self.press + PRESS_GAIN * dz, 0.0, PRESS_MAX)
        if self.press > 0.05:                               # 다른 발들만큼 눌러둠 (지도에는 닿은 높이 그대로)
            self.grounder._set_foot(l, self.feet[l][2] - self.press)
        prof.add(self.feet[l][0], zc, "foot")
        what = ""
        if stepped_up:
            what = f" ★ 계단 {zc - bp[1]:.0f}mm 올라감"
        elif pl.kind == "explore" and abs(zc - (pl.cands[0])) > FLAT_EPS:
            what = f" (예상보다 {zc - pl.cands[0]:+.0f}mm)"
        dt = time.monotonic() - getattr(self, "t_step", time.monotonic())
        print(f"[계단] {name} 디딤: x {self.feet[l][0]:+.0f} 높이 {zc:+.0f}mm{what} ({pl.kind}), "
              f"몸 높이 {self.height():.0f}mm 기울기 {-self.pose[4]:+.0f}° | {dt:.1f}초")
        return "ok"

    def _shift_map(self, dz):
        for prof in self.map.side:
            for p in prof.pts:
                p[1] += dz
        self.drift += dz

    def _edge_check(self, l, xc, yc, zc, bp, prof, f0):
        """디딘 곳(xc)이 디딤판 앞 모서리에서 EDGE_MARGIN 이상 떨어졌나: 그만큼 뒤를 살짝 더듬어 봄.
        'ok'(그대로 또는 앞으로 옮겨서) / 'stuck'(못 옮김 → 원래 자리로) / 'abort'"""
        name = f"다리{l}({LEG_NAME[l]})"
        xt = xc - self.sgn * EDGE_MARGIN
        if (xt - bp[0]) * self.sgn <= 0:
            res = "near"                                    # 뒤쪽 기록이 이미 EDGE_MARGIN 안 → 모서리 가까움 확정
        else:
            r = self._foot_path(l, [[xc, yc, zc + EDGE_LIFT], [xt, yc, zc + EDGE_LIFT]])
            if r != "ok":
                res = "near"
            else:
                st, z_t = self._land(l, [zc], zc - EDGE_PROBE)
                if st == "contact" and abs(z_t - zc) <= FLAT_EPS:
                    prof.add(xt, z_t, "nose")               # 디딤판 가장 뒤쪽으로 확인된 곳 (모서리는 이보다 뒤)
                    res = "far"
                elif st in ("none", "reach"):
                    prof.add(xt, bp[1], "low")              # 여기는 아래 칸 → 모서리는 xt와 xc 사이
                    res = "near"
                elif st == "abort":
                    return "abort"
                else:
                    res = "near"
        cur = self.feet[l]
        print(f"[계단] {name} 모서리 확인: {EDGE_MARGIN:.0f}mm 뒤(x {xt:+.0f}) → "
              f"{'같은 높이 (모서리에서 충분히 떨어짐)' if res == 'far' else '바닥 없음 (모서리 가까움)'}")
        if res == "far":
            # 원래 디딘 곳으로 돌아감
            if self._foot_path(l, [[cur[0], cur[1], zc + EDGE_LIFT], [xc, yc, zc + EDGE_LIFT]]) != "ok":
                return "stuck"
            st, z2 = self._land(l, [zc], zc - FLAT_EPS - 5.0)
            return "ok" if st == "contact" else self._fail_return(l, f0, "모서리 확인 뒤 다시 디디기 실패")
        # 모서리 가까움 → 앞으로
        xf = xc + self.sgn * EDGE_FWD
        print(f"[계단] {name} 디딘 곳이 계단 모서리에서 {EDGE_MARGIN:.0f}mm 안 → {EDGE_FWD:.0f}mm 앞으로 옮김")
        feet = [list(f) for f in self.feet]
        feet[l] = [xf, yc, zc]
        if self._ik(self.pose, feet) is not None:
            r = self._foot_path(l, [[cur[0], cur[1], zc + EDGE_LIFT]])
            if r == "ok":
                # 앞으로 옮길 때 걸림 감시: 디딘 곳이 디딤판 위가 아니라 계단 앞면 중간이었으면(발이 앞면에 걸려
                # '닿음'으로 보였으면) 앞으로 가다 앞면을 밀게 됨
                r = self._foot_path(l, [[xf, yc, zc + EDGE_LIFT]], watch=True)
                if r == "hit":
                    return self._fail_return(l, f0, "모서리 앞으로 옮기다 걸림 (디딘 곳이 계단 앞면이었을 수 있음)")
            if r == "ok":
                st, z2 = self._land(l, [zc], zc - FLAT_EPS - 5.0)
                if st == "contact" and abs(z2 - zc) <= FLAT_EPS:
                    prof.add(xc, zc, "nose")                # 처음 디딘 곳 = 모서리 바로 앞 (다른 다리는 여기서 EDGE_MARGIN 안쪽에)
                    return "ok"
        return self._fail_return(l, f0, "모서리 앞으로 못 옮김")

    def _fail_return(self, l, f0, msg):
        print(f"[계단] 다리{l}: {msg} — 원래 자리로 되돌리고 다음에 다시")
        self._return_foot(l, f0)
        self.last_msg = msg
        return "skip"

    def _return_foot(self, l, f0):
        """다리 l을 원래 디뎠던 자리(f0)로 되돌림: 지금 높이와 원래 자리 위 높이 중 높은 쪽으로 올렸다가 옮기고 내림."""
        cur = list(self.feet[l])
        side = self.map.side[self.map.side_of(f0[1], self.pose[1])]
        env = side.env_range(cur[0], f0[0], 0.0, self.sgn) or f0[2]
        z_up = max(cur[2], env + SWING_CLEAR, f0[2] + SWING_CLEAR)
        if self._foot_path(l, [[cur[0], cur[1], z_up], [f0[0], f0[1], z_up]]) != "ok":
            print(f"[계단] 다리{l} 원래 자리로도 못 돌아감 — 그 자리에 내림")
        st, _ = self._land(l, [f0[2]], f0[2] - PROBE_EXTRA)
        if st != "contact":
            print(f"[계단] 다리{l} 되돌려 내렸는데 '{st}' — 멈추고 손으로 확인할 것")

    # ── 안전 ──
    def _safety_ok(self, after_move=False):
        """IMU로 본 몸 기울기 변화가 명령한 변화와 크게 다르면(미끄러짐·넘어지는 중) 멈춤.
        지난 발을 다 옮긴 뒤 값과 비교 (누적 오차 대신 한 발 사이의 변화만 봄)."""
        if not self.link.imu_fresh():
            self.last_msg = "IMU 값이 안 옴"
            print("[계단] IMU 값이 안 옴 — 멈춤")
            return False
        if not after_move or not self.lev.ready or self.imu_prev is None:
            return True
        self.grounder.last_cmd = time.monotonic()
        self.grounder.wait_still(max_sec=0.3, after_cmd=False)
        now = self.link.imu_recent(5)
        if now is None:
            return True
        G = self._G()
        dr, dp = self.pose[3] - self.cmd_prev[0], self.pose[4] - self.cmd_prev[1]
        exp = (self.imu_prev[0] + G[0][0] * dr + G[0][1] * dp, self.imu_prev[1] + G[1][0] * dr + G[1][1] * dp)
        dev = math.hypot(now[0] - exp[0], now[1] - exp[1])
        if dev > SAFE_DEV_DEG:
            self.last_msg = f"몸 기울기가 예상과 {dev:.1f}° 다름 (미끄러졌거나 넘어지는 중)"
            print("[계단] " + self.last_msg + " — 멈춤. 주변 확인 후 C 짧게(다시 접지)")
            return False
        return True

    def _mark_imu(self):
        self.imu_prev = self.link.imu_recent(5)
        self.cmd_prev = (self.pose[3], self.pose[4])

    def _set_frame_ref(self):
        imu = self.link.imu_recent(5)
        self.imu_ref = None if imu is None or not self.lev.ready else (imu, (self.pose[3], self.pose[4]))

    def _frame_error(self):
        """IMU로 본 실제 몸 기울기 − 명령 기울기 (roll, pitch) [도], 계단 모드 들어올 때 기준. 모르면 None.
        IMU → 몸 기울기 변환은 수평 유지 측정표(G)를 쓰되, 배율(서보 처짐 등으로 1보다 작음)은 빼고 방향만 씀
        (IMU는 실제 기울기를 그대로 재니까)."""
        if self.imu_ref is None:
            return None
        now = self.link.imu_recent(5)
        if now is None:
            return None
        G = self._G()
        n0 = math.hypot(G[0][0], G[1][0]) or 1.0
        n1 = math.hypot(G[0][1], G[1][1]) or 1.0
        a, b, c, d = G[0][0] / n0, G[0][1] / n1, G[1][0] / n0, G[1][1] / n1
        det = a * d - b * c
        if abs(det) < 1e-6:
            return None
        (i_r, i_p), (c_r, c_p) = self.imu_ref
        e0, e1 = now[0] - i_r, now[1] - i_p
        real_r, real_p = (d * e0 - b * e1) / det, (-c * e0 + a * e1) / det
        return real_r - (self.pose[3] - c_r), real_p - (self.pose[4] - c_p)

    def _fix_frame(self, gain=None, max_step=None):
        """좌표 기울기 맞추기 (FRAME_GAIN 설명): 지도·발·몸을 몸 중심으로 돌림. 관절 각도는 안 바뀜 (보내는 명령 없음)."""
        gain = FRAME_GAIN if gain is None else gain
        max_step = FRAME_MAX_STEP if max_step is None else max_step
        e = self._frame_error()
        self.frame_err = e
        if e is None or gain <= 0.0:
            return
        dr, dp = (_clamp(gain * v, -max_step, max_step) for v in e)
        if abs(dr) < 0.02 and abs(dp) < 0.02:
            return
        p = list(self.pose)
        R0 = hb._rot(p[3], p[4], p[5])
        R1 = hb._rot(p[3] + dr, p[4] + dp, p[5])

        def tf(w):                                          # w → p + R1·R0ᵀ·(w − p)
            v = hb._mul_t(R0, [w[0] - p[0], w[1] - p[1], w[2] - p[2]])
            u = hb._mul(R1, v)
            return [p[0] + u[0], p[1] + u[1], p[2] + u[2]]
        self.feet = [tf(f) for f in self.feet]
        for si, prof in enumerate(self.map.side):
            ys = [f[1] for f in self.feet if self.map.side_of(f[1], p[1]) == si]
            yv = sum(ys) / len(ys) if ys else p[1] + (120.0 if si == 0 else -120.0)
            for q in prof.pts:
                w = tf([q[0], yv, q[1]])
                q[0], q[1] = w[0], w[2]
            prof.pts.sort(key=lambda q: q[0])
            prof.xs = [q[0] for q in prof.pts]
        self.pose = [p[0], p[1], p[2], p[3] + dr, p[4] + dp, p[5]]
        self.body.pose = list(self.pose)
        self.body.feet = [list(f) for f in self.feet]
        self.frame_fix[0] += dr
        self.frame_fix[1] += dp

    def _G(self):
        inv = self.lev.inv
        det = inv[0][0] * inv[1][1] - inv[0][1] * inv[1][0]
        if abs(det) < 1e-9:
            return [[1.0, 0.0], [0.0, 1.0]]
        return [[inv[1][1] / det, -inv[0][1] / det], [-inv[1][0] / det, inv[0][0] / det]]

    def check_all(self, quiet=False):
        """발 6개 다시 접지 + 하중 확인 (C 짧게). 내린 다리 수 (IMU 문제·얼음이면 None).
        얼음으로 멈췄을 때 공중에 있던 발은 먼저 원래 디뎠던 자리로 되돌림."""
        try:
            if self.swing_ctx is not None:
                l, f0 = self.swing_ctx
                print(f"[계단] 다리{l}({LEG_NAME[l]})이 공중에서 멈췄었음 — 원래 디뎠던 자리로 되돌림")
                self._return_foot(l, f0)
                self.swing_ctx = None
            n = self.grounder.check_loads()
        except Frozen:
            self._on_frozen()
            return None
        if n is None:
            return None
        if self.frozen:
            print("[계단] 얼음 풀림 — 조이스틱으로 이어서")
            self.frozen = False
            self.track.clear()
        if not quiet or n:
            print("[계단] 하중 확인: " + ", ".join(self.grounder.check_row))
        for i, f in enumerate(self.feet):
            self.map.add(f[0], f[1], f[2], self.pose[1])
        self._mark_imu()
        if self.imu_ref is None:
            self._set_frame_ref()
        return n

    def status(self):
        slope, res = self.flatness()
        return (f"[계단] 몸 높이 {self.height():.0f}mm, 기울기 {-self.pose[4]:+.0f}°, "
                f"발 평면 경사 {slope:.0f}°, 앞발 대비 {self.rise_max:.0f}mm, 몸 여유 {self.clear:.0f}mm, "
                f"옮긴 발 {self.steps_done}번, 높이 기준 맞춘 양 누적 {self.drift:+.0f}mm, 새 발 누르기 {self.press:.1f}mm, "
                f"좌표 기울기 맞춘 양 누적 roll {self.frame_fix[0]:+.1f}° pitch {self.frame_fix[1]:+.1f}°"
                + ("" if self.frame_err is None else
                   f" (마지막 어긋남 {self.frame_err[0]:+.2f}°/{self.frame_err[1]:+.2f}°)"))
