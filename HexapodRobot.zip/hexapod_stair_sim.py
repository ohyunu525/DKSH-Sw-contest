"""
계단 시뮬레이터 — 실제 로봇 없이 hexapod_stair.py(계단 모드)를 시험
  python3 hexapod_stair_sim.py                       # 기본: 높이 100mm · 깊이 280mm 계단 3칸 오르기
  python3 hexapod_stair_sim.py --rise 120 --run 260 --steps 3 --uneven 10 --skew 30
  python3 hexapod_stair_sim.py --rise 80 --back      # 꼭대기에서 뒤로 걸어 내려오기
  python3 hexapod_stair_sim.py --sweep               # 계단 높이별로 쭉 돌려서 표로
  ★ hexapod_stair.py의 BODY_BOTTOM·BODY_RADIUS·KNEE_PAD·ROBOT_MASS를 실측값으로 바꾼 뒤 돌리면 그 몸 기준으로 다시 확인됨
  ★ 1회에 1~3분 정도 걸림 (가상 시간 5~10분짜리 등반)

무엇을 흉내 내나 (가정은 전부 아래 숫자로 바꿀 수 있음)
  - 몸통: 단단한 판. 발마다 스프링(K g/mm)으로 바닥을 누름 → 무게(W g)와 힘·모멘트가 맞는 자세를 매 순간 계산
  - 바닥에 닿은 발은 미끄러지지 않음 (닿은 순간 자리를 기억) → 몸이 앞으로 가는 건 발이 바닥을 미는 만큼만
  - 서보: 명령 각도로 SERVO_SPEED °/s까지만 따라감. --quant면 펌웨어처럼 0.55° 칸 + 1칸 데드밴드
  - IMU: 진짜 몸통 기울기를 IMU_DELAY 늦게, 잡음 IMU_NOISE°로, 200Hz
  - 계단: 디딤판 앞쪽 모서리 EDGE_SLIP mm 안에 무게를 EDGE_HOLD초 넘게 받친 발은 '모서리에 걸친 채로 받침'으로 셈
          (실제로는 미끄러질 수 있는 자리 — 시뮬레이션은 미끄러뜨리지 않고 기록만)
          발이 계단 앞면(세로 벽)으로 옆에서 들어가면: 앞면을 긁으며 아래 칸까지 내려감 + '발부딪힘'으로 셈
  - 시간은 가상 시계 (실제로 기다리지 않음) → 10분짜리 등반이 수십 초에 끝남

기록하는 것 (검산용)
  몸 바닥·다리 링크가 계단에 닿은 횟수, 발이 계단 앞면에 부딪힌 횟수, 모서리에 걸친 착지 수와
  '디딘 곳 ~ 모서리' 최소 거리, 넘어짐, femur 최대 토크(kg·cm), 걸린 시간, 끝까지 올라갔나
"""

import argparse
import contextlib
import io
import math
import random
import sys
import time as _real_time

import hexapod_body as hb
import hexapod_sdk as sdk

# ── 시뮬레이션 가정 ──
K = 170.0            # 발 하나 스프링 [g/mm] (예전 시뮬레이션들과 같은 값. 실측 아님)
W = 2000.0           # 로봇 무게 [g] (프로젝트 추정 1.7~1.94kg)
SERVO_SPEED = 300.0  # 서보 최고 속도 [°/s] (MG996R 무부하 약 350~430°/s, 부하로 느려짐)
IMU_DELAY = 0.05     # 명령 → IMU 값이 PC에 도착하기까지 [초]
IMU_NOISE = 0.03     # IMU 잡음 [°]
PHYS_HZ = 200
EDGE_SLIP = 8.0      # 디딤판 앞 모서리에서 이 안쪽에 무게를 받친 발은 '미끄러질 위험' [mm]
EDGE_HOLD = 1.5      # 그 안쪽에서 이만큼[초] 넘게 받치면 '모서리에 걸친 채로 받침'으로 셈 (더듬다 잠깐 닿은 건 제외)
SLIP_MM = 6.0        # 바닥 발 자리와 몸 자세가 이만큼[mm] 넘게 안 맞으면 그 발이 미끄러진 것으로 봄
PEN_HIT = 8.0        # 발이 바닥을 이만큼 넘게 파고들면 '부딪힘'(계단 앞면 등)으로 봄 [mm]
TICK_DEG = 1.0 / (0.8 * 11.111 / 4.889)   # 펌웨어 1칸 = 관절 약 0.55°


class VClock:
    """가상 시계. sleep()하면 그만큼 물리를 진행시키고 시간을 넘김."""

    def __init__(self):
        self.t = 1000.0
        self.world = None

    def monotonic(self):
        self.t += 1e-6           # 실제 시계처럼 부를 때마다 조금씩 흐름 (같은 순간 두 번 보내면 SDK가 안 움직임)
        return self.t

    def time(self):
        return 1.7e9 + self.monotonic()

    def perf_counter(self):
        return self.monotonic()

    def sleep(self, dt):
        end = self.t + max(0.0, dt)
        w = self.world
        if w is not None:
            while w.next_t <= end:
                self.t = w.next_t
                w.step(self.t)
                w.next_t += 1.0 / PHYS_HZ
        self.t = end

    def __getattr__(self, name):
        return getattr(_real_time, name)


class Stairs:
    """계단 (세계 x 방향으로 올라감). 왼쪽(y≥0)·오른쪽(y<0)이 조금씩 다를 수 있음."""

    def __init__(self, x0=330.0, n=3, rise=100.0, run=280.0, uneven=0.0, run_jitter=0.0, skew=0.0,
                 bump=0.0, seed=1):
        rnd = random.Random(seed)
        self.n, self.rise, self.run = n, rise, run
        self.sides = []
        for side in (0, 1):
            xs, hs, x, h = [], [0.0], x0 + (skew / 2 if side == 0 else -skew / 2), 0.0
            for k in range(n):
                xs.append(x)
                h += rise + (rnd.uniform(-uneven, uneven) if uneven else 0.0)
                hs.append(h)
                x += run + (rnd.uniform(-run_jitter, run_jitter) if run_jitter else 0.0)
            self.sides.append((xs, hs))
        self.bump = bump
        self.phase = [rnd.uniform(0, 6.28) for _ in range(2)]
        self.top_x = max(s[0][-1] for s in self.sides)

    def _idx(self, x, side):
        xs = self.sides[side][0]
        k = 0
        while k < len(xs) and x >= xs[k]:
            k += 1
        return k                                   # 디딤판 번호 (0 = 바닥)

    def height(self, x, y):
        side = 0 if y >= 0 else 1
        return self.level_height(x, side, self._idx(x, side))

    def level_height(self, x, side, k):
        """k번 디딤판 높이 (울퉁불퉁 포함)."""
        h = self.sides[side][1][k]
        if self.bump:
            h += self.bump * math.sin(2 * math.pi * x / 70.0 + self.phase[side])
        return h

    def edge_dist(self, x, y, k=None):
        """디딘 곳이 디딤판 앞 모서리(뒤쪽 계단 끝)에서 얼마나 떨어졌나. 바닥(0칸)이면 None.
        k: 받치는 디딤판 번호 (계단 앞면에 붙어서 아래 칸에 선 발이면 그 아래 칸)"""
        side = 0 if y >= 0 else 1
        xs, _ = self.sides[side]
        if k is None:
            k = self._idx(x, side)
        return None if k == 0 else x - xs[k - 1]

    def depth(self, x, y, z):
        """점이 계단 속으로 들어간 깊이 [mm] (밖이면 0 이하 = 디딤판 위 여유의 −).
        계단 덩어리 표면까지 가장 짧은 거리: 위(디딤판 위)로 나가는 거리와 뒤(계단 앞면 밖)로 나가는 거리 중 작은 것.
        (예전처럼 '디딤판 높이 − z'만 쓰면 앞면에 딱 붙은 tibia가 '127mm 파고듦'으로 나옴)"""
        side = 0 if y >= 0 else 1
        xs, _ = self.sides[side]
        k = self._idx(x, side)
        up = self.level_height(x, side, k) - z
        if up <= 0:
            return up
        j = k
        while j > 0 and self.level_height(x, side, j - 1) > z:
            j -= 1
        back = x - xs[j - 1] if j > 0 else float("inf")
        return min(up, back)

    def riser_ahead(self, x, y):
        side = 0 if y >= 0 else 1
        xs, _ = self.sides[side]
        k = self._idx(x, side)
        return xs[k] - x if k < len(xs) else None


def _rot(r, p, y):
    return hb._rot(math.degrees(r), math.degrees(p), math.degrees(y))


def knee_body(l, joints):
    """관절 각도 → 몸 기준 femur 축, 무릎, 발 위치."""
    hip, fem, tib = joints
    psi = math.radians((hip - hb.HIP_CENTER) * hb.HIP_SIGN[l])
    a = math.radians(180 - fem)
    b = math.radians(tib)
    ta = a - math.pi + b
    mx, my, th = hb.MOUNT[l]
    ang = math.radians(th) + psi
    c, s = math.cos(ang), math.sin(ang)
    r0 = hb.COXA_LEN
    r1 = r0 + hb.FEMUR_LEN * math.cos(a)
    z1 = hb.FEMUR_LEN * math.sin(a)
    r2 = r1 + hb.TIBIA_LEN * math.cos(ta)
    z2 = z1 + hb.TIBIA_LEN * math.sin(ta)
    return ([mx + r0 * c, my + r0 * s, 0.0], [mx + r1 * c, my + r1 * s, z1], [mx + r2 * c, my + r2 * s, z2])


class World:
    def __init__(self, stairs, quant=False, body_bottom=30.0, body_radius=125.0, knee_pad=22.0,
                 com=(0.0, 0.0, 0.0), start_x=0.0, seed=1):
        self.st = stairs
        self.quant = quant
        self.rnd = random.Random(seed)
        self.ang = [list(map(float, p)) for p in sdk.BOOT_POSE]
        self.tgt = [list(map(float, p)) for p in sdk.BOOT_POSE]
        self.qofs = [[self.rnd.uniform(-0.5, 0.5) * TICK_DEG for _ in range(3)] for _ in range(6)]
        self.P = [start_x, 0.0, stairs.height(start_x, 0.0) + 60.0, 0.0, 0.0, 0.0]   # 진짜 몸 자세 (x, y, z, roll, pitch, yaw rad)
        self.anchor = [None] * 6
        self.F = [0.0] * 6
        self.link = None
        self.next_t = 0.0
        self.hist = []
        self.body_bottom, self.body_radius, self.knee_pad = body_bottom, body_radius, knee_pad
        self.com = com
        self.bpts = [(0.0, 0.0)] + [(r * math.cos(a), r * math.sin(a))
                                    for r in (body_radius * 0.5, body_radius)
                                    for a in [k * math.pi / 6 for k in range(12)]]
        self.ev = dict(body_hit=0, leg_hit=0, foot_hit=0, edge_land=0, fall=0, slip_mm=0.0,
                       body_clear_min=1e9, edge_min=1e9, torque_max=0.0, force_max=0.0, landings=0)
        self.ev_log = []
        self.leg_hit_parts = {}
        self.torque_ctx = ""
        self.climber = None
        self.contact = [False] * 6
        self.edge_t = [None] * 6
        self.contact_since = [None] * 6
        self.lvl = [None] * 6          # 발이 받쳐지는 디딤판 번호 (계단 앞면에 옆으로 들어간 발은 아래 칸 그대로)
        self.face = [False] * 6        # 계단 앞면에 옆으로 들어간 상태
        self.fallen = False
        self.unsolved_since = None
        self.t = 0.0

    def reset_events(self):
        for k in self.ev:
            self.ev[k] = 1e9 if k in ("body_clear_min", "edge_min") else 0
        self.ev["slip_mm"] = 0.0
        self.ev_log = []
        self.leg_hit_parts = {}
        self.torque_ctx = ""

    def true_height_above_floor(self):
        """몸 중심(hip 축)의 실제 높이 − 그 아래 바닥 높이."""
        return self.P[2] - self.st.height(self.P[0], self.P[1])

    # ── 서보 ──
    def set_joint(self, l, j, deg):
        if self.quant:
            q = round((deg - self.qofs[l][j]) / TICK_DEG) * TICK_DEG + self.qofs[l][j]
            if abs(q - self.tgt[l][j]) < 1.05 * TICK_DEG and abs(q - self.ang[l][j]) < 1.05 * TICK_DEG:
                return                                   # 데드밴드: 1칸짜리 변화는 안 움직일 수 있음
            deg = q
        self.tgt[l][j] = deg

    def _slew(self, dt):
        mx = SERVO_SPEED * dt
        for l in range(6):
            for j in range(3):
                d = self.tgt[l][j] - self.ang[l][j]
                self.ang[l][j] += max(-mx, min(mx, d))

    # ── 기하 ──
    def _R(self, P=None):
        P = P or self.P
        return _rot(P[3], P[4], P[5])

    def _world(self, R, P, v):
        w = hb._mul(R, v)
        return [w[0] + P[0], w[1] + P[1], w[2] + P[2]]

    def _feet_body(self):
        return [hb.leg_fk(l, self.ang[l]) for l in range(6)]

    def _solve_xy(self, fb):
        """닿아 있는 발 자리(기억해 둔 곳)에 맞게 몸 x, y, yaw를 맞춤 (2D 최소제곱)."""
        P = self.P
        R0 = _rot(P[3], P[4], 0.0)
        idx = [i for i in range(6) if self.anchor[i] is not None]
        if not idx:
            return
        q = {i: hb._mul(R0, fb[i])[:2] for i in idx}
        a = {i: self.anchor[i] for i in idx}
        if len(idx) == 1:
            i = idx[0]
            c, s = math.cos(P[5]), math.sin(P[5])
            P[0] = a[i][0] - (c * q[i][0] - s * q[i][1])
            P[1] = a[i][1] - (s * q[i][0] + c * q[i][1])
            return
        qc = [sum(q[i][k] for i in idx) / len(idx) for k in (0, 1)]
        ac = [sum(a[i][k] for i in idx) / len(idx) for k in (0, 1)]
        sxx = sxy = 0.0
        for i in idx:
            qx, qy = q[i][0] - qc[0], q[i][1] - qc[1]
            ax, ay = a[i][0] - ac[0], a[i][1] - ac[1]
            sxx += qx * ax + qy * ay
            sxy += qx * ay - qy * ax
        yaw = math.atan2(sxy, sxx)
        c, s = math.cos(yaw), math.sin(yaw)
        P[5] = yaw
        P[0] = ac[0] - (c * qc[0] - s * qc[1])
        P[1] = ac[1] - (s * qc[0] + c * qc[1])
        # 미끄러짐: 맞춘 자리와 기억한 자리가 다르면 발이 밀린 것
        for i in idx:
            wx = c * q[i][0] - s * q[i][1] + P[0]
            wy = s * q[i][0] + c * q[i][1] + P[1]
            e = math.hypot(wx - a[i][0], wy - a[i][1])
            if e > SLIP_MM:                    # 그보다 작은 어긋남은 다리 휨으로 흡수 (발은 그대로)
                self.ev["slip_mm"] += e
                self.anchor[i] = (wx, wy)

    def _update_levels(self, fb):
        """발이 디딤판 '앞면'(세로 벽)으로 옆에서 들어갔나. 그렇다면 그 발은 아래 칸에서 받침 (앞면을 긁으며 내려감).
        발이 점 하나 + 계단이 계단 모양 높이 함수라서, 이게 없으면 앞면 중간에서 '닿음'이 생김 (실제로는 미끄러져 내려감).
        부딪힌 것은 발부딪힘으로 셈. 앞면에 붙은 상태는 디딤판 위로 올라가거나 앞면에서 3mm 넘게 물러나야 풀림
        (앞면에 딱 붙어 선 발이 경계에서 들락날락하며 '부딪힘'이 수백 번 세어지는 것 방지)."""
        R = self._R()
        for i in range(6):
            w = self._world(R, self.P, fb[i])
            side = 0 if w[1] >= 0 else 1
            xs = self.st.sides[side][0]
            k = self.st._idx(w[0], side)
            hk = self.st.level_height(w[0], side, k)
            lv = self.lvl[i]
            if self.face[i]:
                top = self.st.level_height(w[0], side, lv + 1)      # 붙어 있는 앞면의 위 칸 높이
                if w[2] >= top or w[0] < xs[lv] - 3.0:
                    self.face[i] = False
                    self.lvl[i] = k
                continue
            if lv is None or lv >= k or w[2] >= hk - PEN_HIT:
                self.lvl[i] = k
            else:
                self.face[i] = True
                self.ev["foot_hit"] += 1
                self.ev_log.append((self.t, f"다리{i} 발이 계단 앞면에 부딪힘 (앞면 안쪽 "
                                            f"{w[0] - xs[k - 1]:.0f}mm, 디딤판보다 {hk - w[2]:.0f}mm 아래)"))

    def _support_level(self, i, x, y, z=None):
        """발 i를 받치는 디딤판 (앞면에 붙었거나, 이번 계산 중에 앞면 안으로 들어가는 발이면 아래 칸)."""
        side = 0 if y >= 0 else 1
        k = self.st._idx(x, side)
        lv = self.lvl[i]
        if lv is not None and lv < k and \
                (self.face[i] or (z is not None and z < self.st.level_height(x, side, k) - PEN_HIT)):
            return side, lv
        return side, k

    def _pen(self, P, fb):
        R = self._R(P)
        out = []
        for i in range(6):
            w = self._world(R, P, fb[i])
            side, k = self._support_level(i, w[0], w[1], w[2])
            out.append((self.st.level_height(w[0], side, k) - w[2], w))
        return out

    def _solve_z(self, fb):
        """힘·모멘트가 맞는 높이·roll·pitch (발 스프링). 닿은 발이 3개 미만이 되면 넘어짐."""
        P = self.P
        for _ in range(3):
            base = self._pen(P, fb)
            J = []
            eps = 1e-4
            for k in (2, 3, 4):
                Pk = list(P)
                Pk[k] += eps if k != 2 else 0.01
                d = 0.01 if k == 2 else eps
                pk = self._pen(Pk, fb)
                J.append([(base[i][0] - pk[i][0]) / d for i in range(6)])   # d(높이)/d(변수)
            R = self._R(P)
            cw = self._world(R, P, list(self.com))
            act = [i for i in range(6) if base[i][0] > -1.0]
            sol = None
            for _it in range(10):
                if len(act) < 3:
                    break
                M = [[0.0] * 3 for _ in range(3)]
                rhs = [0.0, 0.0, 0.0]
                for i in act:
                    pen = min(base[i][0], PEN_HIT)
                    v = [1.0, base[i][1][0] - cw[0], base[i][1][1] - cw[1]]
                    for r in range(3):
                        rhs[r] += K * pen * v[r]
                        for c in range(3):
                            M[r][c] += K * v[r] * J[c][i]
                rhs[0] -= W
                try:
                    du = _solve3(M, rhs)
                except ZeroDivisionError:
                    break
                pred = [base[i][0] - sum(J[c][i] * du[c] for c in range(3)) for i in range(6)]
                new = [i for i in range(6) if pred[i] > 0]
                if new == act:
                    sol = du
                    break
                act = new
            if sol is None:
                # 닿은 발이 3개 미만이거나 무게중심이 밖 → 몸이 내려앉으며 다른 발이 닿기를 기다림.
                # 0.5초 넘게 이 상태면 '넘어짐' (처음 내려앉을 때·울퉁불퉁한 바닥에선 잠깐 생길 수 있음)
                P[2] -= 2.0 if all(b[0] <= 0 for b in base) else 0.5
                if self.unsolved_since is None:
                    self.unsolved_since = self.t
                elif self.t - self.unsolved_since > 0.5:
                    self.fallen = True
                    return
                continue
            self.unsolved_since = None
            lim = [3.0, 0.01, 0.01]
            for k, kk in enumerate((2, 3, 4)):
                P[kk] += max(-lim[k], min(lim[k], sol[k]))
        base = self._pen(P, fb)
        self.F = [K * max(0.0, min(b[0], PEN_HIT)) for b in base]
        return base

    # ── 한 스텝 ──
    def step(self, t):
        dt = 1.0 / PHYS_HZ
        self.t = t
        if self.fallen:
            return
        self._slew(dt)
        fb = self._feet_body()
        self._update_levels(fb)
        self._solve_xy(fb)
        base = self._solve_z(fb)
        if self.fallen or base is None:
            if self.fallen and not self.ev["fall"]:
                self.ev["fall"] = 1
                self.ev_log.append((t, "넘어짐 (받치는 발 3개 미만 또는 무게중심이 밖)"))
            return
        R = self._R()
        for i in range(6):
            pen, w = base[i]
            touching = pen > 0
            if touching and not self.contact[i]:
                self.anchor[i] = (w[0], w[1])
                self.ev["landings"] += 1
            k_sup = self._support_level(i, w[0], w[1], w[2])[1]
            d = self.st.edge_dist(w[0], w[1], k_sup) if self.F[i] > 50 else None
            if d is not None and d < EDGE_SLIP:
                if self.edge_t[i] is None:
                    self.edge_t[i] = t
                elif t - self.edge_t[i] > EDGE_HOLD and self.edge_t[i] > 0:
                    self.ev["edge_land"] += 1
                    self.ev_log.append((t, f"다리{i} 모서리에 걸친 채로 받침 (모서리에서 {d:.0f}mm)"))
                    self.edge_t[i] = -1.0                      # 이 자리에선 한 번만 셈
            else:
                self.edge_t[i] = None
            if d is not None and self.F[i] > 50 and self.edge_t[i] is not None and t - abs(self.edge_t[i]) > 1.0:
                self.ev["edge_min"] = min(self.ev["edge_min"], d)
            if touching and self.F[i] > 50:
                dd = self.st.edge_dist(w[0], w[1], k_sup)
                if dd is not None and (self.contact_since[i] is not None and t - self.contact_since[i] > EDGE_HOLD):
                    self.ev["edge_min"] = min(self.ev["edge_min"], dd)
            if touching and self.contact_since[i] is None:
                self.contact_since[i] = t
            if not touching:
                self.anchor[i] = None
                self.contact_since[i] = None
            if pen > PEN_HIT and self.contact[i] is False:
                self.ev["foot_hit"] += 1
                self.ev_log.append((t, f"다리{i} 발이 계단에 부딪힘 (파고든 깊이 {pen:.0f}mm)"))
            self.contact[i] = touching
        # 몸 바닥
        for bx, by in self.bpts:
            w = self._world(R, self.P, [bx, by, -self.body_bottom])
            clr = -self.st.depth(w[0], w[1], w[2])
            self.ev["body_clear_min"] = min(self.ev["body_clear_min"], clr)
            if clr < 0:
                self.ev["body_hit"] += 1
                if self.ev["body_hit"] == 1 or self.ev["body_hit"] % 200 == 0:
                    self.ev_log.append((t, f"몸 바닥이 계단에 닿음 (x {w[0]:.0f}, {clr:.0f}mm)"))
                break
        # 다리 링크 + 토크
        names = ["femur", "무릎", "무릎서보", "tibia1/4", "tibia1/2", "tibia3/4"]
        for l in range(6):
            fa, kn, ft = knee_body(l, self.ang[l])
            pts = [[fa[k] + (kn[k] - fa[k]) * u for k in range(3)] for u in (0.5, 1.0)]
            pts.append([kn[0], kn[1], kn[2] - self.knee_pad])
            pts += [[kn[k] + (ft[k] - kn[k]) * u for k in range(3)] for u in (0.25, 0.5, 0.75)]
            for pi_, p in enumerate(pts):
                w = self._world(R, self.P, p)
                dep = self.st.depth(w[0], w[1], w[2])
                if dep > 1.0:
                    self.ev["leg_hit"] += 1
                    key = (l, names[pi_])
                    self.leg_hit_parts[key] = max(self.leg_hit_parts.get(key, 0.0), dep)
                    if self.ev["leg_hit"] == 1 or self.ev["leg_hit"] % 400 == 0:
                        ra = self.st.riser_ahead(w[0], w[1])
                        self.ev_log.append((t, f"다리{l} {names[pi_]}가 계단에 {dep:.0f}mm 파고듦 "
                                               f"(발 {'바닥' if self.contact[l] else '공중'}, 다음 모서리까지 "
                                               f"{ra if ra is None else round(ra)}mm)"))
                    break
            if self.F[l] > 0:
                wf = self._world(R, self.P, fa)
                wt = self._world(R, self.P, ft)
                arm = math.hypot(wt[0] - wf[0], wt[1] - wf[1])
                tq = self.F[l] * arm / 10000.0
                if tq > self.ev["torque_max"]:
                    self.ev["torque_max"] = tq
                    self.torque_ctx = f"다리{l} 힘 {self.F[l]:.0f}g × 팔 {arm:.0f}mm, 닿은 발 {sum(1 for f in self.F if f > 0)}개"
                self.ev["force_max"] = max(self.ev["force_max"], self.F[l])
        # IMU (지연 + 잡음)
        roll = math.degrees(math.atan2(R[2][1], R[2][2]))
        pitch = -math.degrees(math.asin(max(-1.0, min(1.0, -R[2][0]))))   # + = 앞이 들림 (펌웨어 기준)
        self.hist.append((t, roll, pitch))
        while len(self.hist) > 1 and self.hist[1][0] <= t - IMU_DELAY:
            self.hist.pop(0)
        if self.link is not None and self.hist:
            _, r_, p_ = self.hist[0]
            self.link._on_imu(f"#imu,{int(t * 1000)},{r_ + self.rnd.gauss(0, IMU_NOISE):.2f},"
                              f"{p_ + self.rnd.gauss(0, IMU_NOISE):.2f},3,2", t)

    def feet_world(self):
        R = self._R()
        return [self._world(R, self.P, f) for f in self._feet_body()]


def _solve3(A, b):
    A = [row[:] + [b[i]] for i, row in enumerate(A)]
    for i in range(3):
        piv = max(range(i, 3), key=lambda r: abs(A[r][i]))
        if abs(A[piv][i]) < 1e-9:
            raise ZeroDivisionError
        A[i], A[piv] = A[piv], A[i]
        for r in range(3):
            if r != i:
                f = A[r][i] / A[i][i]
                for c in range(4):
                    A[r][c] -= f * A[i][c]
    return [A[i][3] / A[i][i] for i in range(3)]


class SimLink(sdk.Link):
    def __init__(self, world):
        super().__init__("sim")
        self.world = world
        world.link = self

    @property
    def is_open(self):
        return True

    def send(self, data):
        text = data.decode()
        if not sdk.CMD_RE.match(text):
            return False
        text = text.strip()
        if text.startswith("<"):
            l, j, d = (x.strip() for x in text[1:-1].split(","))
            self.world.set_joint(int(l), int(j), float(d))
        elif text == "z":
            self.log_queue.append("#zero,0.00,0.00")
        return True


def install_clock(clock, *modules):
    for m in modules:
        m.time = clock


def run(rise=100.0, run_=280.0, steps=3, uneven=0.0, run_jitter=0.0, skew=0.0, bump=0.0, quant=False,
        lat_err=0.0, seed=1, max_sec=2400.0, body_bottom=None, verbose=False, start_x=0.0, back=False,
        rise_max=None, x0=330.0):
    import hexapod_joy_walk as jw
    import hexapod_stair as hs
    clock = VClock()
    install_clock(clock, sdk, hb, jw, hs)
    random.seed(seed)
    st = Stairs(x0=x0, n=steps, rise=rise, run=run_, uneven=uneven, run_jitter=run_jitter, skew=skew, bump=bump,
                seed=seed)
    bb = hs.BODY_BOTTOM if body_bottom is None else body_bottom
    w = World(st, quant=quant, body_bottom=bb, body_radius=hs.BODY_RADIUS, knee_pad=hs.KNEE_PAD,
              com=tuple(hs.COM), start_x=start_x, seed=seed)
    clock.world = w
    w.next_t = clock.t
    clock.sleep(0.5)                                 # 부팅 자세로 바닥에 내려앉기
    link = SimLink(w)
    out = io.StringIO()
    t0 = clock.t
    res = dict(ok=False, why="", sec=0.0)
    with contextlib.redirect_stdout(out if not verbose else sys.stdout):
        hx = sdk.Hexapod()
        hx.sync(link)
        body = hb.Body(hx, link)
        body.capture()
        sender = jw.SdkSender(hx, link)
        sender.direct_mode()
        gait = jw.Gait(body, sender)
        gait.settle()
        clock.sleep(0.3)
        jw.measure_latency(gait, link)
        jw.GROUND_LATENCY += lat_err
        lev = jw.Leveler(link)
        gr = jw.Grounder(gait, lev)
        lev.calibrate(gait)
        cl = hs.StairClimber(gait, gr, lev, link)
        cl.rise_max = rise_max if rise_max is not None else max(hs.RISE_MAX, rise + 20.0)
        w.climber = cl
        ok_enter = cl.enter()
        w.reset_events()
        if not ok_enter:
            res["why"] = "계단 모드 못 들어감"
        else:
            t_start = clock.t
            while clock.t - t_start < max_sec:
                r = cl.step(-1.0 if back else 1.0, 0.0, 0.0)
                if w.fallen:
                    res["why"] = "넘어짐"
                    break
                if r not in ("ok", "skip"):
                    res["why"] = f"멈춤: {r} — {cl.last_msg}"
                    break
                fw = w.feet_world()
                if (not back and all(f[0] > st.top_x + 25 for f in fw)) or \
                        (back and all(f[0] < min(sd[0][0] for sd in st.sides) - 25 for f in fw)):
                    res["ok"] = True
                    break
            else:
                res["why"] = "시간 초과"
            res["sec"] = clock.t - t_start
    res.update(w.ev)
    res["events"] = w.ev_log[:12]
    res["leg_parts"] = dict(w.leg_hit_parts)
    res["torque_ctx"] = w.torque_ctx
    res["steps_done"] = getattr(cl, "steps_done", 0) if "cl" in dir() else 0
    res["log"] = out.getvalue()
    res["x"] = w.P[0]
    res["clock"] = clock.t - t0
    return res


def fmt(r):
    s = (f"{'성공' if r['ok'] else '실패'} {r['sec']:6.0f}초 | 몸닿음 {r['body_hit']} 링크닿음 {r['leg_hit']} "
         f"발부딪힘 {r['foot_hit']} 모서리에걸친채받침 {r['edge_land']} (받친 발-모서리 최소 {r['edge_min'] if r['edge_min'] < 1e8 else float('nan'):.0f}mm) "
         f"넘어짐 {r['fall']} 몸여유최소 {r['body_clear_min']:.0f}mm 토크최대 {r['torque_max']:.1f}kg·cm "
         f"미끄러짐 {r['slip_mm']:.0f}mm 몸x {r['x']:.0f}")
    if not r["ok"]:
        s += f" — {r['why']}"
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rise", type=float, default=100.0)
    ap.add_argument("--run", type=float, default=280.0)
    ap.add_argument("--steps", type=int, default=3)
    ap.add_argument("--uneven", type=float, default=0.0, help="디딤판 높이 ±mm 무작위")
    ap.add_argument("--run-jitter", type=float, default=0.0, help="디딤판 깊이 ±mm 무작위")
    ap.add_argument("--skew", type=float, default=0.0, help="왼쪽·오른쪽 계단 모서리 위치 차이 mm")
    ap.add_argument("--bump", type=float, default=0.0, help="디딤판 위 울퉁불퉁 ±mm")
    ap.add_argument("--quant", action="store_true", help="서보 0.55° 칸 + 데드밴드")
    ap.add_argument("--lat-err", type=float, default=0.0, help="지연 추정 오차 [초]")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--body-bottom", type=float, default=None)
    ap.add_argument("--max-sec", type=float, default=2400.0)
    ap.add_argument("--back", action="store_true", help="꼭대기에서 시작해 뒤로 내려오기")
    ap.add_argument("--rise-max", type=float, default=None, help="앞발 대비 높이 (기본: 계단 높이 + 20)")
    ap.add_argument("-v", action="store_true", help="로봇 출력 전부 보기")
    ap.add_argument("--sweep", action="store_true")
    a = ap.parse_args()
    if a.sweep:
        for rise in (40, 60, 80, 100, 120, 140, 160):
            r = run(rise=rise, run_=a.run, steps=a.steps, uneven=a.uneven, skew=a.skew, quant=a.quant,
                    seed=a.seed, max_sec=a.max_sec, body_bottom=a.body_bottom)
            print(f"높이 {rise:3d}mm  " + fmt(r), flush=True)
        return
    start_x = 330.0 + a.steps * a.run + 300.0 if a.back else 0.0
    r = run(rise=a.rise, run_=a.run, steps=a.steps, uneven=a.uneven, run_jitter=a.run_jitter, skew=a.skew,
            bump=a.bump, quant=a.quant, lat_err=a.lat_err, seed=a.seed, max_sec=a.max_sec,
            body_bottom=a.body_bottom, verbose=a.v, back=a.back, start_x=start_x, rise_max=a.rise_max)
    print(fmt(r))
    for t, e in r["events"]:
        print(f"  {t - 1000:7.1f}s {e}")
    if not a.v:
        tail = r["log"].strip().splitlines()[-25:]
        print("--- 로봇 출력 마지막 25줄 ---")
        print("\n".join(tail))


if __name__ == "__main__":
    main()
