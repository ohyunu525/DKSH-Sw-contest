"""
계단 기어오르기 — 2·5번과 나란히 hip 을 맞춘 뒤, 앞 → 중간 → 뒤 다리 순서로 한 계단씩 올라감

  /usr/bin/python3 hexapod_stair_crawl.py --robot 58:2A:BD:7D:4F:0A
  /usr/bin/python3 hexapod_stair_crawl.py --robot /dev/ttyUSB1 --pause     (단계마다 Enter 를 눌러야 다음으로)

순서
  0) 낮게(START_HEIGHT) 선 다음 몸을 BODY_HEIGHT 까지 천천히 올림
  1) 2·5번을 뺀 4개 다리(1·3·4·6)를 하나씩 살짝 들어 hip 을 2·5번과 나란하게 접음
     → 다리 6개가 모두 2·5번 방향(60° / -120°)으로 뻗은 '세 쌍' 모양이 되고, 가는 방향은 그와 수직 (FORWARD_DEG)
        FORWARD_DEG = -30 이면  앞 = 3·4번,  중간 = 2·5번,  뒤 = 1·6번
  그다음 STEPS 번 반복:
  2) 앞 다리 하나: 곧게 들기 → hip 을 정면(가는 방향)으로 돌리기 → 천천히 내리다 접지 버튼이 눌리면 멈춤 (계단 위)
     다른 앞 다리도 똑같이
  3) 끌어오기: 앞 다리로 PULL_MM 당기기 → 앞 다리를 하나씩 다시 앞으로 올려놓기 → 또 당기기 … DRAG_MM 까지
     (중간·뒤 다리는 바닥을 질질 끌려옴) → 중간 다리가 계단 앞면에 확실히 붙음
  4) 중간 다리 하나씩 앞 다리처럼 (들기 → 정면으로 → 내리다 닿으면 멈춤)
  5) 앞·중간 다리로 똑같이 당기고·다시 올려놓기를 반복 → 뒤 다리가 계단 앞면에 닿을 때까지 질질 끌려옴
  6) 뒤 다리 하나씩 앞 다리처럼 올림
  7) 다리 6개가 다 계단 위면 몸을 그 높이만큼 올려 BODY_HEIGHT 로 되돌림

★ 접지 버튼은 위아래로 눌릴 때만 느낌 → '계단 앞면에 붙었다'는 건 못 느끼고 DRAG_MM 만큼 끌어서 붙임.
  계단 앞면에 막힌 다리를 계속 끌면 서보가 힘을 씀 → 처음엔 --pause 로 한 단계씩 보면서 DRAG_MM 을 맞출 것
Ctrl+C = 서기 자세로 돌아간 뒤 힘 빼기
"""

import argparse
import math
import time

from hexapod_body import HIP_CENTER, HIP_SIGN, MOUNT, leg_fk, leg_ik
from hexapod_sdk import JOINT_LIMITS, NUM_JOINTS, NUM_LEGS, STAND_POSE, Hexapod, Link

# ═══════════════════════════ 설정 ═══════════════════════════
ROBOT = "58:2A:BD:7D:4F:0A"

START_HEIGHT = 70.0     # 처음 서는 몸 높이 [mm] (서기 자세 ≈ 66) — 여기서 BODY_HEIGHT 까지 천천히 올림
BODY_HEIGHT = 200.0     # 계단 오를 때 몸 높이: hip 축 ~ 발끝 수직 거리 [mm] (높을수록 계단 턱을 쉽게 넘음, 최대 ≈ 230)
FOOT_REACH = 130.0      # hip 축 ~ 발끝 수평 거리 [mm] (서 있을 때)
PLACE_REACH = 180.0     # 계단 위에 놓을 때 hip 축 ~ 발끝 수평 거리 [mm] — 멀리 놓을수록 한 번에 오래 당김 (안 닿으면 줄여서 놓음)
PARALLEL_LEGS = [1, 4]  # 이 다리들(0부터: 1 = 2번, 4 = 5번)과 나란하게 나머지 hip 을 맞춤
FORWARD_DEG = -30.0     # 가는 방향 [도, 몸 기준 반시계, 0 = 3번 쪽]. 2·5번 방향(60°)에 수직이어야 함
                        #   -30 → 앞 3·4번 / 중간 2·5번 / 뒤 1·6번.   150 → 앞 6·1번 / 중간 5·2번 / 뒤 4·3번
HIP_REACH_MAX = 85.0    # '정면으로' 돌릴 때 hip 이 180 에서 꺾여도 되는 최대 [도] (서보 범위 180 ± 90).
                        #   중간 다리는 정면까지 90° 라 여기서 멈추고, 뒤 다리는 정면까지 못 돌아서 돌 수 있는 데까지만
ALIGN_LIFT = 25.0       # 처음 hip 을 나란하게 맞출 때 드는 높이 [mm]
STEP_LIFT = 110.0*10000       # 계단에 올릴 때 드는 높이 [mm] — 계단 높이 + 여유보다 커야 함 (못 들면 들 수 있는 만큼)
PLACE_FEMUR = 200.0     # 계단에 다리를 걸칠 때(닿는 순간) femur 각도 [도]. 180 = 수평, 작을수록 위로 듦 (200 = 수평보다 20° 아래)
                        #   정하면: 든 채 hip 을 돌린 뒤 femur 를 이 각도로 고정하고 tibia 만 접어 발끝을 위·바깥에서 아래로
                        #   쓸어내리다 버튼이 눌리면 멈춤 → 어느 높이 계단이든 닿을 때 femur 는 이 각도
                        #   ★ 발끝이 내려갈 수 있는 깊이가 femur 로 정해짐. 그보다 낮은 계단은 안 닿음 (시작할 때 출력됨)
                        #     몸 높이 200 일 때: 170 → 바닥 +80mm 까지,  180 → +63,  190 → +46,  200 → +29,  210 → +13
                        #     몸 높이 140 일 때: 160 → +37,  170 → +13
                        #   None = 예전처럼 놓을 자리(PLACE_REACH) 위에서 곧게 내림
PLACE_TIBIA_MAX = 155.0 # 쓸어내릴 때 tibia 를 이보다 펴지 않음 [도] — 거의 다 편 다리(180)로 닿으면 더 못 당기고 몸도 못 올림
LIFT_SPEED = 50.0*3       # 들기 속도 [mm/s]
TURN_SPEED = 60.0       # 든 채 hip 돌리는 속도 [도/s]
DESCEND_SPEED = 20.0    # 내리는 속도 [mm/s] — 버튼이 눌리면 바로 멈출 수 있게 천천히
MAX_DOWN = 15.0         # 바닥(몸 높이)보다 이만큼 더 내려도 안 닿으면 거기서 멈춤 [mm]
RELEASE_TICKS = 5       # 버튼이 이만큼(틱) 연달아 떨어져 있는 걸 본 뒤에야 다음 눌림을 믿음 (접혀서 눌린 버튼 거름)
DRAG_MM = 150.0         # 끌어오는 전체 거리 [mm] — 끌려오는 다리가 계단 앞면에 확실히 붙을 만큼
PULL_MM = 40.0          # 한 번에 당기는 거리 [mm]. 당기고 → 당긴 다리를 하나씩 다시 앞으로 올려놓고 → 또 당기기를 DRAG_MM 까지 반복
FEMUR_LIFT_MIN = 32   # 다리를 들 때 곧게 든 다음 femur 를 이 각도까지 들어 올림 (작을수록 위로) → 그 자세로 hip 을 돌림
                        #   ★ SDK JOINT_LIMITS femur 하한(62)보다 작으면 62 까지만 감 (더 올리려면 hexapod_sdk.py 하한을 낮춰야 함)
DRAG_SPEED = 20.0       # 끌어당기는 몸 속도 [mm/s]
RAISE_SPEED = 15.0      # 몸 올리는 속도 [mm/s] (처음 + 다 올라간 뒤)
STEPS = 3               # 올라갈 계단 수
START_SEC = 2.0         # 처음 서기 자세로 가는 시간 [초]
LOOP_HZ = 50
# ═══════════════════════════════════════════════════════════


def wrap180(a):
    return (a + 180.0) % 360.0 - 180.0


def unit(deg):
    return math.cos(math.radians(deg)), math.sin(math.radians(deg))


class Crawl:
    def __init__(self, link, pause=False):
        self.link = link
        self.hx = Hexapod()
        self.dt = 1.0 / LOOP_HZ
        self.pause = pause
        self.contact_on = True
        self.feet = None
        self.fwd = unit(FORWARD_DEG)
        par = MOUNT[PARALLEL_LEGS[0]][2]                # 2번 방향 (60°)
        side_a, side_b = par, wrap180(par + 180)        # 양쪽 (60° / -120°)
        self.side_dir = []                              # 다리마다 '나란히' 방향
        for mx, my, _ in MOUNT:
            ux, uy = unit(side_a)
            self.side_dir.append(side_a if mx * ux + my * uy >= 0 else side_b)
        if abs(abs(wrap180(FORWARD_DEG - par)) - 90.0) > 1.0:
            print(f"[설정] ★ FORWARD_DEG {FORWARD_DEG:.0f} 이 2·5번 방향({par:.0f}°)과 수직이 아님")
        # 가는 방향으로 앞에 붙은 순서 → 앞 2개 / 중간 2개 / 뒤 2개
        order = sorted(range(NUM_LEGS), key=lambda l: -(MOUNT[l][0] * self.fwd[0] + MOUNT[l][1] * self.fwd[1]))
        self.front, self.middle, self.rear = order[0:2], order[2:4], order[4:6]
        names = lambda ls: "·".join(str(l + 1) for l in ls)
        print(f"[계단] 가는 방향 {FORWARD_DEG:.0f}° → 앞 {names(self.front)} / 중간 {names(self.middle)} / 뒤 {names(self.rear)}")

    # ── 보내기 ──
    def send_joints(self, js):
        self.hx.set_pose(js)
        self.hx.move_update(self.link)
        if not self.hx.state_known:
            why = [m for m in self.link.log_queue if "전송" in m or "수신" in m or "형식" in m or "연결" in m]
            raise ConnectionError("로봇 전송 실패" + (f" — {why[-1]}" if why else ""))

    def send(self, feet):
        js = [leg_ik(l, f) for l, f in enumerate(feet)]
        if any(j is None for j in js):
            return False
        self.send_joints(js)
        self.feet = [list(f) for f in feet]
        return True

    def contact(self, l):
        return self.link.foot_fresh() and bool(self.link.foot[l])

    def wait(self, what):
        while self.link.log_queue:
            print("[로봇]", self.link.log_queue.popleft())
        if self.pause:
            input(f"   ⏸  다음: {what} — Enter ")
        else:
            print(f"[계단] {what}")

    # ── 자리 ──
    def foot_at(self, l, deg, z, reach=FOOT_REACH):
        mx, my, _ = MOUNT[l]
        ux, uy = unit(deg)
        return [mx + reach * ux, my + reach * uy, z]

    def face_dir(self, l):
        """다리 l 이 '정면(가는 방향)' 을 향하는 방향 — hip 이 HIP_REACH_MAX 를 넘으면 거기까지만."""
        off = wrap180(FORWARD_DEG - MOUNT[l][2])
        off = max(-HIP_REACH_MAX, min(HIP_REACH_MAX, off))
        return MOUNT[l][2] + off

    # ── 움직임 ──
    def move_feet(self, targets, speed):
        """targets = {다리: 발 목표} 를 직선·일정 속도로. 못 닿는 데서 멈추고 False."""
        start = {l: list(self.feet[l]) for l in targets}
        dist = max([math.dist(start[l], targets[l]) for l in targets] + [0.0])
        n = max(1, round(dist / speed * LOOP_HZ))
        for k in range(1, n + 1):
            feet = [list(f) for f in self.feet]
            for l in targets:
                feet[l] = [a + (b - a) * k / n for a, b in zip(start[l], targets[l])]
            if not self.send(feet):
                return False
            time.sleep(self.dt)
        return True

    def turn_leg(self, l, target):
        """다리 l 을 관절 공간으로 target 발 위치까지 (든 채 hip 을 돌림 — 직선으로 가면 몸 안쪽을 지나갈 수 있어서)."""
        j1 = leg_ik(l, target)
        if j1 is None:
            return False
        self.turn_joints(l, j1)
        return True

    def turn_joints(self, l, j1, touched=None, foot_speed=None):
        """다리 l 을 관절 공간으로 j1 까지 일정하게. touched 를 주면 닿는 순간 멈추고 True (안 닿으면 False).
        foot_speed 를 주면 발끝 속도가 그보다 안 빠르게."""
        j0 = [a for a in self.hx.cmd[l]]
        t = max(abs(a - b) for a, b in zip(j0, j1)) / TURN_SPEED
        if foot_speed:
            pts = [leg_fk(l, [a + (b - a) * i / 20 for a, b in zip(j0, j1)]) for i in range(21)]
            t = max(t, sum(math.dist(pts[i], pts[i + 1]) for i in range(20)) / foot_speed)
        n = max(1, round(t * LOOP_HZ))
        for k in range(1, n + 1):
            if touched is not None and touched():
                return True
            js = [row[:] for row in self.hx.cmd]
            js[l] = [a + (b - a) * k / n for a, b in zip(j0, j1)]
            self.send_joints(js)
            self.feet[l] = leg_fk(l, js[l])
            time.sleep(self.dt)
        return touched is not None and touched()

    def highest(self, l, xy, z0, want):
        """xy 위에서 z0 + want 까지 중 닿는 가장 높은 z."""
        if leg_ik(l, [xy[0], xy[1], z0 + want]) is not None:
            return z0 + want
        lo, hi = 0.0, want
        for _ in range(20):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if leg_ik(l, [xy[0], xy[1], z0 + mid]) is not None else (lo, mid)
        return z0 + max(lo - 1.0, 0.0)

    def lift_place(self, l, deg, lift):
        """다리 하나: 곧게 들기 → 든 채 hip 을 deg 방향으로 → 천천히 내리다 버튼이 눌리면 멈춤. 닿은 높이(몸 기준 z) 를 돌려줌."""
        f = self.feet[l]
        reach = PLACE_REACH if lift >= STEP_LIFT else FOOT_REACH
        target = self.foot_at(l, deg, f[2] + lift, reach)
        while leg_ik(l, target) is None and reach > 60:  # 든 높이에서 그만큼 안 닿으면 조금씩 줄임
            reach -= 5
            target = self.foot_at(l, deg, f[2] + lift, reach)
        top = self.highest(l, target, f[2], lift)
        here = self.highest(l, f, f[2], top - f[2])     # 지금 자리에서 곧게 들 수 있는 만큼 (몸 쪽으로 당겨진 다리는 덜 들림)
        print(f"[계단] 다리 {l + 1}: {here - f[2]:.0f}mm 들기 → hip {deg:.0f}° 방향으로 {reach:.0f}mm (높이 +{top - f[2]:.0f})"
              " → 내리기")
        state = {"off": 0, "rel": not self.contact_on}

        def touched():                                  # 버튼이 확실히 떨어진 걸 본 뒤 눌리면 '닿음'
            if not self.contact_on:
                return False
            if not state["rel"]:
                state["off"] = 0 if self.contact(l) else state["off"] + 1
                state["rel"] = state["off"] >= RELEASE_TICKS
                return False
            return self.contact(l)

        # 1) 곧게 들기
        self.move_feet({l: [f[0], f[1], here]}, LIFT_SPEED)
        # 2) femur 를 FEMUR_LIFT_MIN 까지 들어 올림 (tibia 는 그대로) — 다리 전체를 위로 젖혀서 발끝을 최대한 높게
        j = self.hx.cmd[l]
        fl = max(FEMUR_LIFT_MIN, JOINT_LIMITS[l][1][0])
        z0 = self.feet[l][2]
        self.turn_joints(l, [j[0], fl, j[2]])
        print(f"[계단] 다리 {l + 1}: femur {fl:.0f} 로 들어 올림 (발끝 {self.feet[l][2] - z0:+.0f}mm)")
        # 3) 든 채 hip 만 돌려 deg 방향으로
        hip = HIP_CENTER + HIP_SIGN[l] * wrap180(deg - MOUNT[l][2])
        lo_h, hi_h = JOINT_LIMITS[l][0]
        self.turn_joints(l, [min(max(hip, lo_h), hi_h), fl, j[2]])
        if PLACE_FEMUR is not None and lift >= STEP_LIFT:
            return self.sweep_down(l, touched)
        # 4) 놓을 자리 위로 (내려가는 동안에도 닿으면 멈춤) → 천천히 곧게 내림
        jt = leg_ik(l, [target[0], target[1], top])
        if jt is not None and self.turn_joints(l, jt, touched, DESCEND_SPEED * 2):
            print(f"[계단] 다리 {l + 1}: 닿음 — 바닥보다 {self.feet[l][2] + BODY_HEIGHT:+.0f}mm")
            return self.feet[l][2]
        floor = -BODY_HEIGHT - MAX_DOWN
        p = list(self.feet[l])
        while True:
            if touched():
                print(f"[계단] 다리 {l + 1}: 닿음 — 바닥보다 {p[2] + BODY_HEIGHT:+.0f}mm")
                return p[2]
            nz = p[2] - DESCEND_SPEED * self.dt
            if nz < floor or leg_ik(l, [p[0], p[1], nz]) is None:
                print(f"[계단] 다리 {l + 1}: 안 닿음 (바닥보다 {p[2] + BODY_HEIGHT:+.0f}mm 에서 멈춤)"
                      + ("" if self.contact_on else " — 접지 신호 없음"))
                return p[2]
            p[2] = nz
            feet = [list(q) for q in self.feet]
            feet[l] = list(p)
            self.send(feet)
            time.sleep(self.dt)

    @staticmethod
    def sweep_range(l, hip):
        """femur = PLACE_FEMUR 일 때 tibia 를 접으며 내려오는 구간: (가장 높은 쪽 tibia, 가장 낮은 쪽 tibia).
        tibia 를 줄이면 발끝이 내려가다가 '가장 낮은 tibia' 아래로는 다시 올라감."""
        lo_t, hi_t = JOINT_LIMITS[l][2]
        hi_t = min(hi_t, PLACE_TIBIA_MAX)
        while hi_t > lo_t and leg_ik(l, leg_fk(l, [hip, PLACE_FEMUR, hi_t])) is None:
            hi_t -= 1.0                                 # 다 펴진 자리는 빼고 (거기서 닿으면 못 당김)
        ts = [lo_t + (hi_t - lo_t) * i / 300 for i in range(301)]
        zs = [leg_fk(l, [hip, PLACE_FEMUR, t])[2] for t in ts]
        t_low = ts[zs.index(min(zs))]
        return hi_t, t_low

    def sweep_down(self, l, touched):
        """femur 를 PLACE_FEMUR 로 두고 tibia 만 접어서 발끝을 쓸어내림 → 버튼이 눌리면 멈춤. 닿은 높이를 돌려줌."""
        hip = self.hx.cmd[l][0]
        t_hi, t_low = self.sweep_range(l, hip)
        z_now = self.feet[l][2]
        # 지금 발 높이보다 안 낮은 데서 시작 (위·바깥에서 내려오게)
        t0 = t_hi
        for i in range(301):
            t = t_hi - (t_hi - t_low) * i / 300
            if leg_fk(l, [hip, PLACE_FEMUR, t])[2] <= z_now:
                break
            t0 = t
        print(f"[계단] 다리 {l + 1}: femur {PLACE_FEMUR:.0f} 로 고정하고 tibia {t0:.0f} → {t_low:.0f} 로 접으며 내림")
        # 든 자리 → 쓸어내리기 시작 자세: 이 사이에도 내려가므로 천천히, 닿으면 멈춤
        if self.turn_joints(l, [hip, PLACE_FEMUR, t0], touched, DESCEND_SPEED * 2):
            z, fm = self.feet[l][2], self.hx.cmd[l][1]
            print(f"[계단] 다리 {l + 1}: 쓸어내리기 전에 닿음 — 바닥보다 {z + BODY_HEIGHT:+.0f}mm (femur {fm:.0f}, 계단이 높음)")
            return z
        t = t0
        while True:
            z = self.feet[l][2]
            if touched():
                print(f"[계단] 다리 {l + 1}: 닿음 — 바닥보다 {z + BODY_HEIGHT:+.0f}mm (femur {PLACE_FEMUR:.0f}, tibia {t:.0f})")
                return z
            if t <= t_low + 1e-6:
                print(f"[계단] 다리 {l + 1}: 안 닿음 — femur {PLACE_FEMUR:.0f} 로는 바닥보다 {z + BODY_HEIGHT:+.0f}mm 까지만 내려감"
                      + ("" if self.contact_on else " (접지 신호 없음)") + " — PLACE_FEMUR 를 키울 것")
                return z
            # 발끝 속도가 DESCEND_SPEED 를 안 넘게 tibia 를 조금씩
            nt = t - 0.5
            while nt > t_low and math.dist(leg_fk(l, [hip, PLACE_FEMUR, nt]), self.feet[l]) < DESCEND_SPEED * self.dt:
                nt -= 0.5
            t = max(nt, t_low)
            js = [row[:] for row in self.hx.cmd]
            js[l] = [hip, PLACE_FEMUR, t]
            self.send_joints(js)
            self.feet[l] = leg_fk(l, js[l])
            time.sleep(self.dt)

    def drag(self, pullers, dist):
        """당기기 → 당긴 다리를 하나씩 다시 앞으로 올려놓기 → 또 당기기 를 dist 까지 반복.
        당길 때 pullers 의 발은 계단 위에 그대로 두고 몸을 가는 방향으로 → 나머지 다리는 몸 따라 질질 끌려옴.
        실제로 간 거리를 돌려줌."""
        gone, rnd = 0.0, 0
        while gone < dist - 0.5:
            rnd += 1
            chunk = self.pull(pullers, min(PULL_MM, dist - gone))
            gone += chunk
            print(f"[계단] {rnd}번째 당기기 {chunk:.0f}mm (모두 {gone:.0f} / {dist:.0f}mm)")
            if gone >= dist - 0.5:
                break
            for l in pullers:                           # 하나씩 다시 앞으로 (나머지 5개가 받침)
                self.wait(f"다리 {l + 1} 을 다시 앞으로 올려놓기")
                self.lift_place(l, self.face_dir(l), STEP_LIFT)
            if chunk < 1.0 and rnd > 1:
                print("[계단] 다시 올려놓아도 못 당김 — 끌기를 멈춤")
                break
        return gone

    def pull(self, pullers, dist):
        """pullers 를 바닥(계단)에 둔 채 몸을 dist 만큼 앞으로. 한 다리라도 더 못 당기면 거기서 멈춤. 간 거리를 돌려줌."""
        step = DRAG_SPEED * self.dt
        gone = 0.0
        while gone < dist - 1e-6:
            s = min(step, dist - gone)
            feet = [list(f) for f in self.feet]
            for l in pullers:
                feet[l] = [feet[l][0] - s * self.fwd[0], feet[l][1] - s * self.fwd[1], feet[l][2]]
            bad = [l + 1 for l in pullers if leg_ik(l, feet[l]) is None]
            if bad:
                print(f"[계단] 다리 {bad} 가 더 못 당김 ({gone:.0f}mm 에서)")
                break
            self.send(feet)
            gone += s
            time.sleep(self.dt)
        return gone

    def raise_body(self):
        """다리 6개가 다 계단 위 → 발 높이 평균이 -BODY_HEIGHT 가 되게 몸을 올림."""
        up = sum(f[2] for f in self.feet) / NUM_LEGS + BODY_HEIGHT
        if up < 2.0:
            return
        print(f"[계단] 몸을 {up:.0f}mm 올림")
        if not self.move_feet({l: [f[0], f[1], f[2] - up] for l, f in enumerate(self.feet)}, RAISE_SPEED):
            print("[계단] 끝까지 못 올림 (다리가 다 펴짐) — BODY_HEIGHT 를 낮출 것")

    # ── 순서 ──
    def start(self):
        if not self.hx.sync(self.link):
            return False
        self.hx.max_speed = [[1e9] * NUM_JOINTS for _ in range(NUM_LEGS)]
        self.hx.timedelay = 0.0
        stand = [self.foot_at(l, MOUNT[l][2], -START_HEIGHT) for l in range(NUM_LEGS)]   # hip 180, 낮게
        high = [[f[0], f[1], -BODY_HEIGHT] for f in stand]
        target = [leg_ik(l, f) for l, f in enumerate(stand)]
        if any(j is None for j in target) or any(leg_ik(l, f) is None for l, f in enumerate(high)):
            print("[계단] START_HEIGHT·BODY_HEIGHT·FOOT_REACH 로 못 섬 — 값을 바꿀 것")
            return False
        start = [row[:] for row in self.hx.cmd]
        n = max(1, round(START_SEC * LOOP_HZ))
        for k in range(1, n + 1):
            self.send_joints([[a + (b - a) * k / n for a, b in zip(s_, t)] for s_, t in zip(start, target)])
            time.sleep(self.dt)
        self.feet = stand
        # 1) 몸 높이부터 올림
        self.wait(f"몸을 {START_HEIGHT:.0f} → {BODY_HEIGHT:.0f}mm 로 올리기")
        self.move_feet({l: f for l, f in enumerate(high)}, RAISE_SPEED)
        time.sleep(0.3)
        if not self.link.foot_fresh():
            print("[접지] 신호 없음 — 버튼을 안 보고 바닥 높이까지 내림 (계단 위에 못 놓음)")
            self.contact_on = False
        if PLACE_FEMUR is not None:
            for l in self.front[:1]:
                _, t_low = self.sweep_range(l, HIP_CENTER)
                low = leg_fk(l, [HIP_CENTER, PLACE_FEMUR, t_low])[2] + BODY_HEIGHT
                print(f"[계단] femur {PLACE_FEMUR:.0f} 로 걸치면 발끝은 바닥보다 {low:+.0f}mm 까지 내려감 → 이보다 높은 계단만 걸침")
        # 2) 2·5번을 뺀 다리를 하나씩 들어 hip 을 2·5번과 나란하게 (접기)
        for l in range(NUM_LEGS):
            if l in PARALLEL_LEGS:
                continue
            self.wait(f"다리 {l + 1} hip 을 2·5번과 나란하게")
            self.lift_place(l, self.side_dir[l], ALIGN_LIFT)
        return True

    def climb_one(self, i):
        names = lambda ls: "·".join(str(l + 1) for l in ls)
        print(f"\n[계단] ── {i + 1} 번째 계단 ──")
        for l in self.front:
            self.wait(f"앞 다리 {l + 1} 을 계단 위로")
            self.lift_place(l, self.face_dir(l), STEP_LIFT)
        self.wait(f"앞 다리({names(self.front)})로 끌어당겨 중간 다리를 계단 앞면에 붙이기")
        self.drag(self.front, DRAG_MM)
        for l in self.middle:
            self.wait(f"중간 다리 {l + 1} 을 계단 위로")
            self.lift_place(l, self.face_dir(l), STEP_LIFT)
        self.wait(f"앞·중간 다리({names(self.front + self.middle)})로 끌어당겨 뒤 다리를 계단 앞면에 붙이기")
        self.drag(self.front + self.middle, DRAG_MM)
        for l in self.rear:
            self.wait(f"뒤 다리 {l + 1} 을 계단 위로")
            self.lift_place(l, self.face_dir(l), STEP_LIFT)
        self.wait("몸 올리기")
        self.raise_body()

    def finish(self):
        print("[계단] 서기 자세로 돌아가는 중")
        start = [row[:] for row in self.hx.cmd]
        n = max(1, round(START_SEC * LOOP_HZ))
        for k in range(1, n + 1):
            self.send_joints([[a + (b - a) * k / n for a, b in zip(s_, t)] for s_, t in zip(start, STAND_POSE)])
            time.sleep(self.dt)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--robot", default=ROBOT, help="로봇 블루투스 주소 또는 포트")
    ap.add_argument("--steps", type=int, default=STEPS, help="올라갈 계단 수")
    ap.add_argument("--pause", action="store_true", help="단계마다 Enter 를 기다림")
    a = ap.parse_args()
    link = Link(a.robot)
    if not link.connect():
        print("\n".join(link.log_queue))
        return
    crawl = Crawl(link, a.pause)
    try:
        if crawl.start():
            for i in range(a.steps):
                crawl.climb_one(i)
            print("[계단] 끝")
    except (KeyboardInterrupt, ConnectionError) as e:
        print("\n중단:", e or "Ctrl+C")
        while link.log_queue:
            print("[로그]", link.log_queue.popleft())
    if crawl.hx.state_known:
        try:
            crawl.finish()
        except (KeyboardInterrupt, ConnectionError):
            pass
    crawl.hx.poweroff(link)
    time.sleep(0.2)
    link.close()


if __name__ == "__main__":
    main()
