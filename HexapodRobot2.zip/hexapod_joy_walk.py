"""
조이스틱으로 걷기 — 연속 삼각 보행 (수정판 hexapod_sdk 용)
오렌지보드(우노) + 조이스틱 쉴드 → 컴퓨터 → 블루투스 → 로봇

필요한 파일 (같은 폴더)
  hexapod_sdk.py   : Link, Hexapod (수정판)
  hexapod_body.py  : Body (역기구학 _solve, capture, home, feet, pose), GROUP_B
  우노에는 joystick_controller.ino (50ms마다 <x,y,버튼,볼륨> 전송)

실행
  /usr/bin/python3 hexapod_joy_walk.py --uno /dev/ttyACM0 --robot AA:BB:CC:DD:EE:FF
  ★ 로봇 전원을 켠 직후(펌웨어 부팅 자세 = 서기 자세)에 실행할 것

걷는 방식
  몸은 멈추지 않고 계속 움직이고, 그동안 두 조가 번갈아 발을 들어 앞으로 옮긴다.
  - 바닥 발: 몸이 움직인 만큼 뒤로 밀림 (바닥에 붙어 있는 것처럼)
  - 공중 발: "착지할 때 몸 기준 어디 있어야 하나"를 매 순간 다시 계산해서 그쪽으로 감
  - 속도는 ACCEL 만큼씩 서서히 바뀜
  - 서보 속도 제한(거버너): 계산된 동작이 JOINT_SPEED_MAX 를 넘으면 그 순간만 시간을 늦춰서
    서보가 따라올 수 있는 만큼만 진행 → 주기를 짧게 잡아도 다리가 꼬이지 않고,
    서보가 낼 수 있는 최대 속도로 걷는다
  - 조이스틱을 놓으면 발을 기본 자리로 다 모은 다음 멈춤

수평 유지 (펌웨어 v2 + BNO086 필요)
  서 있는 동안 몸통이 기울면(한쪽 다리가 턱 위에 있는 등) 발은 그대로 두고 몸통만 돌려서 수평으로 되돌림.
  - 시작할 때 몸통을 ±3°씩 기울여 보고 "명령 1°에 IMU가 몇 도 변하나"를 직접 잼
    → hexapod_body와 펌웨어의 roll/pitch 부호가 달라도 자동으로 맞음
    → 측정이 이상하면(거의 안 변함 / 엉뚱한 축이 변함) 수평 유지를 끄고 이유를 출력
  - 걷는 동안에는 보정을 멈추고 그 기울기를 유지. 멈추면 다시 보정
  - 로봇이 수평이라고 믿는 기준은 펌웨어의 'z' 기준. 평평한 바닥에서 한 번 맞춰둘 것

걸으면서 착지 (WALK_GROUND, IMU 필요)
  발 3개를 '예상 바닥 + LAND_APPROACH mm'까지 내리고 → 몸을 잠깐 멈추고 → 1개씩 천천히 내려서
  IMU 기울기가 변하는 순간(= 무게가 실리기 시작) 멈춤 → 발 6개 기준으로 몸 높이·기울기 되돌림 → 다시 걸음.
  다리마다 '예상과 실제 바닥 차이'를 배워서 다음 걸음에 씀. 5초마다 [통계] 줄로 확인.

조작
  조이스틱        : 기울인 방향으로 걷기 (많이 기울일수록 빠름)
  Left / Right   : 제자리 왼쪽 / 오른쪽 회전 (누르고 있는 동안)
  노랑 / 파랑     : 걷는 중 → 발 드는 높이 올리기 / 내리기 (한 번에 LIFT_STEP mm, 다음에 드는 발부터)
                   서 있을 때 → 몸 높이 올리기 / 내리기 (한 번에 HEIGHT_STEP mm)
                     안 닿으면 폭을 줄여서라도 올림(발을 3개씩 다시 놓음), 내리면 폭을 되돌림
  조이스틱 누름   : 걷는 중 → 발 드는 높이 원래대로 / 서 있을 때 → 몸 높이 원래대로
  빨강           : 접기 / 펴기 (걷는 중이면 먼저 멈춘 다음 접음)
  C 짧게          : 접지+수평 (발 6개 접지 → 발은 그대로 두고 몸통만 수평 → 다리마다 살짝 들어서 정말 받치는지 확인,
                   덜 받치면 받칠 때까지 내림. 멈춰 있을 때만, 보통 5~20초). ★ 이제 '뗄 때' 동작함
                   걷다 멈출 때·서서 몸통을 많이 돌렸을 때는 자동으로 함
  C 길게(1초)     : 계단 모드 들어가기 / 나오기 (hexapod_stair.py — 한 발씩 더듬어 오르기. 조작은 그 파일 맨 위)
                   계단 모드에서 빨강 = 얼음 (누르고 있으면 그 자세로 멈춤, 힘 유지). 다시 가려면 빨강 놓고 C 짧게
  볼륨           : 걸음 빠르기 (한 주기 시간)
  Ctrl+C         : 멈추고 힘 빼기

★ 버튼 색깔 ↔ 글자(A~D)는 쉴드마다 다를 수 있음. 우노 시리얼에 "# 눌림: A" 로 확인해서 표를 고칠 것
"""

import argparse
from collections import deque
import math
import threading
import time

import serial

import hexapod_body as hb
from hexapod_sdk import JOINT_LIMITS, NUM_JOINTS, NUM_LEGS, SIDE, STAND_POSE, Hexapod, Link


# ═══════════════════════════ 하이퍼파라미터 ═══════════════════════════
# 각 항목: 뜻 / 단위 / 키우면 / 줄이면 / 확인 방법

# ── 1. 걸음 빠르기 ─────────────────────────────────────────────
# 최고 몸통 속도 = min(SPEED_MAX, MAX_STRIDE ÷ (DUTY × 주기))
#   예전 설정(보폭 110, DUTY 0.52, 주기 0.225, 거버너 ×4)은 이론상 약 940 mm/s → 서보가 못 따라가서
#   발이 끌리거나 다 내려오기 전에 다음 동작으로 넘어갔음. 지금은 아래 SPEED_MAX가 최종 상한.
# 서보가 못 따라오면 거버너가 자동으로 늦추므로, 실제 속도는 [통계]의 '시간 배율'을 곱한 값.

SPEED_MAX = 50.0
#   몸 최고 속도 [mm/s] — 속도를 줄이고 싶으면 이것만 바꾸면 됨. 볼륨은 이 안에서 주기를 바꿈.
#   키우면: 빨라짐. 줄이면: 느리고 안정적. (예전 설정의 사실상 상한 ≈ 940)
TURN_SPEED_MAX = 15.0
#   제자리 회전 최고 속도 [도/s].

CYCLE_SLOW = 2.4
CYCLE_FAST = 1.0
#   (예전: 1.6 / 0.225)
#   한 주기 [초] = 두 조가 한 번씩 발을 드는 시간. 볼륨 0 → CYCLE_SLOW, 최대 → CYCLE_FAST.
#   줄이면: 빨라짐. 하지만 공중 시간 (1−DUTY)×주기 도 같이 줄어 서보가 못 따라가기 시작하면
#           거버너가 개입해서 실제로는 더 안 빨라짐 ([통계] 거버너 시간 배율 < 1.0 이 그 신호).
#           너무 줄이면 오히려 느려짐 (가짜 기구학 실험: 0.23s가 0.4s보다 느렸음).
#   키우면: 느리고 안정적.
#   맞추는 법: 볼륨을 최대로 두고 CYCLE_FAST를 0.05씩 바꿔가며 [통계] '평균 몸 속도'가 제일 큰 값을 찾을 것.

DUTY = 0.6
#   (예전 0.52) 걸으면서 접지 확인을 하려면 두 조가 같이 바닥에 있는 시간이 넉넉해야 해서 올림.
#   한 주기 중 발이 바닥에 있는 비율 (0.5 < DUTY < 1).
#   0.5 초과분이 '두 조가 동시에 바닥에 있는 시간'. 0.52면 주기의 2%씩 두 번 = 4%.
#   줄이면: 공중 시간 여유 ↑ + 최고 속도 ↑ (최고 속도 = 보폭 ÷ (DUTY × 주기)). 대신 겹침이 짧아 출렁임 ↑.
#   키우면: 덜 출렁이지만 공중 시간이 줄어 서보가 더 빨리 움직여야 함.
#   0.5 이하는 순간적으로 지지 다리가 3개 미만 → 넘어짐 (금지). 권장 0.52 ~ 0.6.

MIN_SWING_SEC = 0.15
#   발이 공중에 있는 최소 시간 [초]. 주기 하한 = MIN_SWING_SEC ÷ (1−DUTY) (0.15/0.48 ≈ 0.31s).
#   서보가 못 따라가는 건 거버너가 막으므로, 이건 '착지 직전 감속 구간이 너무 짧아 쿵 떨어지는 것'만 막는 안전선.

MAX_STRIDE = 60.0
#   (예전 110)
#   최대 보폭 [mm] = 바닥 발이 한 번 디딘 동안 뒤로 밀리는 거리.
#   키우면: 같은 주기에서 빨라짐. 대신 발이 앞뒤 끝까지 가서
#           ① femur 모멘트 암 증가(토크 ↑) ② 지지 삼각형이 찌그러져 안정 여유 ↓
#   시작할 때 '다리가 닿는 범위'와 'MIN_FOOT_GAP'을 만족하는 값으로 자동 축소(5mm씩)되고,
#   무엇 때문에 줄었는지 출력됨 ([걸음] 줄). 계단·험지는 30~40 권장.

TUCK_DEG = 20.0
#   앞·뒤 다리의 기본 자리를 coxa 축 중심으로 옆쪽(가운데 다리 쪽)으로 돌려두는 각도 [도].
#   왜 필요한가: 앞·뒤 다리는 진행 방향과 30°밖에 안 벌어져 있어서, 발을 앞뒤로 움직이면
#       다리가 '펴졌다 접혔다'만 하고(femur·tibia 담당) coxa(hip)는 거의 안 돎.
#       → 무릎 가동범위가 먼저 바닥나서 MAX_STRIDE를 키워도 보폭이 안 늘어남.
#       옆으로 돌려두면 앞뒤 이동이 다리와 직각에 가까워져서 coxa가 일을 맡음 → 보폭이 늘어남.
#   키우면: 보폭·속도 ↑ (가짜 기구학: 0° → 보폭 65mm, 20° → 140mm).
#           대신 ① 같은 쪽 발끼리 가까워짐 (이웃 다리 충돌 위험)
#                ② 지지 다각형이 앞뒤로 짧아져 앞뒤로 기울어지는 데 약해짐.
#   0이면 예전과 같음.

HIP_RADIUS = 80.4
#   몸 중심 → coxa 축 거리 [mm]. ★ hexapod_body.py에 실측 MOUNT(앞뒤 112, 가운데 99)가 있으면 그걸 쓰고
#   이 값은 안 씀. (예전엔 이 값만 써서 발 모으기·폭 줄이기의 회전 중심이 실제와 어긋나 있었음)

MIN_FOOT_GAP = 50.0
#   같은 쪽 이웃 발끝 사이 최소 거리 [mm]. 보폭 양 끝에서 이보다 가까워지면 보폭을 줄임.
#   ★ 발끝 사이만 보는 값이라 다리 몸통(femur·tibia)끼리 부딪히는 건 못 잡음.
#     처음엔 천천히 걸리면서 눈으로 확인하고, 부딪히면 이 값을 키우거나 TUCK_DEG를 줄일 것.

SETTLE_SEC = 0.6
#   시작할 때(또는 펴기 직후) 앞·뒤 다리를 새 기본 자리로 옮기는 시간 [초, 조별].

MAX_TURN_DEG = 12.0
#   제자리 회전 시 바닥 발이 한 번 디딘 동안 도는 최대 각도 [도]. 회전판 MAX_STRIDE.
#   최고 회전 속도 = MAX_TURN_DEG ÷ (DUTY × 주기).

LIFT_MM = 40.0
#   시작할 때 발 드는 높이 [mm]. ★ 걷는 중에 노랑/파랑 버튼으로 LIFT_STEP씩 바꿀 수 있음.
#   키우면: 턱·장애물 넘기 쉬움. 공중에서 움직일 각도가 커져 같은 주기에선 거버너 개입 ↑ (= 느려짐).
#   줄이면: 빨리 걸을 수 있음. 평지는 20~30, 울퉁불퉁한 곳은 40 이상.
LIFT_MIN, LIFT_MAX = 10.0, 80.0
#   버튼으로 바꿀 수 있는 범위 [mm]. 위쪽은 그 높이에서 다리가 실제로 닿는 만큼으로 자동 축소됨.
LIFT_STEP = 10.0
#   버튼 한 번에 바뀌는 양 [mm].

JOINT_SPEED_MAX = 200.0
#   (예전 ×4 = 800 → 사실상 거버너가 꺼져 있었음)
#   거버너 기준 관절 속도 [도/초]. 한 프레임에 이보다 빨리 움직여야 하면 그 프레임의 시간을 늦춤.
#   근거: MG996R 데이터시트 무부하 약 0.17s/60°(4.8V) ≈ 350°/s, 0.14s/60°(6V) ≈ 430°/s.
#         부하가 걸리면 느려지므로 절반 수준으로 잡음 (실측 아님).
#   키우면: 빨라지지만 명령이 실제 서보보다 앞서감 → 착지가 늦고 바닥 발이 끌림.
#   줄이면: 확실히 따라오지만 느림.
#   확인: 각도 피드백이 없어서 직접 못 잼 → 슬로모션 영상으로 발이 바닥에서 끌리는지 볼 것.
#         끌리면 이 값을 20~30씩 낮춘다.

ACCEL = 150.0
#   (예전 300) 몸 가감속 [mm/s²]. 0 → 50mm/s 까지 약 0.3초.
#   키우면: 반응이 즉각적. 급출발·급정지 때 몸이 출렁이고 발이 미끄러질 수 있음.
#   줄이면: 부드럽지만 굼뜸.

YAW_ACCEL = 60.0
#   회전 가감속 [도/s²]. ACCEL의 회전판.

# ── 2. 공중 발 궤적 모양 (0~1 = 공중에 있는 시간 비율) ──────────────
#   거버너를 걸리게 하는 건 거의 항상 '발 들기/내리기의 femur'와 '공중에서 앞으로 가는 tibia'였음
#   (coxa는 한 번도 아님). 그래서 이 세 값이 속도에 직접 영향을 줌.
SWING_FLAT = 0.08
#   공중 시간의 처음·끝 이 비율만큼은 앞뒤로 안 움직이고 위아래로만 움직임 (수직 들기 / 수직 착지).
#   키우면: 발이 바닥을 긁지 않고 수직으로 착지. 대신 가운데 구간에서 더 빨리 앞으로 가야 함 → 거버너 개입 ↑.
#   줄이면: 앞으로 가는 시간이 길어져 서보 부담 ↓. 너무 작으면 들자마자 앞으로 가서 발끝이 바닥에 걸림.
SWING_UP_END = 0.40
#   이 시점까지 최고 높이에 도달. 늦출수록 천천히 들려서 femur 최고 속도 ↓ (대신 높이 확보가 늦어짐).
SWING_DOWN_START = 0.50
#   이 시점부터 내려감. 내려올 때는 닿는 순간 속도가 0이 되도록 감속 (사뿐히 착지).
#   앞당길수록 천천히 내려와서 femur 최고 속도 ↓. 늦추면 높은 상태를 오래 유지(장애물에 유리).
#   (가짜 기구학: DUTY 0.52 + FLAT 0.08 근처 + 0.4/0.5 조합이 기존 대비 약 +14%)

# ── 3. 전송 ──────────────────────────────────────────────────
LOOP_HZ = 50
#   1초에 자세를 몇 번 계산해서 보내나.
#   한 프레임에 바뀐 관절만 보냄(최대 18개 × 약 13바이트) → 50Hz면 최대 약 11.7 kB/s.
#   키우면: 궤적이 매끄럽고 착지 타이밍 정확. 블루투스·ESP32 부담 ↑.
#   줄이면: 부담 ↓. 공중 0.3초 동안 프레임이 LOOP_HZ×0.3 개 → 30Hz면 9개로 다소 각짐.
#   확인: [통계] '루프'가 목표보다 낮거나 '프레임 전송 최대'가 1000/LOOP_HZ ms(50Hz면 20ms)에
#         가까우면 30~40으로 낮출 것.

# ── 4. 높이 ──────────────────────────────────────────────────
HEIGHT_STEP = 10.0                      # 높이 버튼 한 번 [mm]
HEIGHT_MIN, HEIGHT_MAX = 0.0, 150.0     # 몸 높이 범위 [mm] (hexapod_body 좌표, 서기 자세 = 0)
Z_RATE = 60.0                           # 높이 바꾸는 속도 [mm/s]. 키우면 빨리 바뀌지만 출렁임

# ── 4-1. 폭 줄여서 높이 올리기 (서 있을 때만) ────────────────────
#   다리가 옆으로 벌어져 있으면 몸을 높이 들 수 없음 (다리 길이를 옆으로 쓰고 있어서).
#   몸 높이를 올렸는데 닿지 않으면, 발을 coxa 축 쪽으로 당겨서(폭을 줄여서) 다리를 세운 다음 올린다.
#   발은 바닥에 붙어 있어서 미끄러뜨리지 않고, 3개씩 들어서 안쪽에 다시 놓는다.
#   폭 = coxa 축에서 발까지 수평 거리의 배율 (1.0 = 원래 자리, 0.5 = 절반 거리)
#   높이를 다시 내리면 되는 만큼 원래 폭으로 되돌림 (넓을수록 안정적이라서).
SPREAD_MIN = 0.4
#   폭을 최대 어디까지 줄일지. 줄일수록 높이 들 수 있지만 아래 안정 여유가 먼저 막을 수 있음.
SPREAD_STEP = 0.05
#   폭을 몇 단계씩 바꿔볼지. 작을수록 딱 필요한 만큼만 줄이지만 계산이 늘어남.
SPREAD_MIN_MARGIN = 25.0
#   걸을 때 발 3개(삼각형)로 서는 순간, 몸 중심에서 삼각형 변까지 최소 거리 [mm] = 안정 여유.
#   폭을 줄이면 삼각형이 작아져서 이 값이 줄어듦. 이보다 작아지는 폭은 안 씀.
#   키우면: 덜 넘어지지만 높이 한계가 낮아짐. 줄이면: 더 높이 들지만 옆에서 밀거나 경사에서 넘어지기 쉬움.
#   ※ 몸 중심(무게중심)이 몸통 한가운데라는 가정. 라이다·배터리를 한쪽에 달면 실제 여유는 더 작음.
SPREAD_MIN_LIFT = 15.0
#   그 높이·폭에서 발을 최소 이만큼[mm]은 들 수 있어야 함 (못 들면 못 걸으니까).
REPLANT_LIFT = 15.0
#   폭을 바꿀 때 발을 들어 옮기는 높이 [mm].

# ── 5. 조종기 ─────────────────────────────────────────────────
STICK_FWD_SIGN = -1     # 위로 밀었는데 뒤로 가면 +1
STICK_SIDE_SIGN = +1    # 왼쪽으로 밀었는데 오른쪽으로 가면 -1
DEADZONE = 0.15         # 가운데 무시 구간 (0~1). 손 안 대도 기어가면 키울 것
UNO_TIMEOUT = 0.5       # 조종기 신호가 이만큼[초] 없으면 서서히 멈춤

# 버튼 비트 (joystick_controller.ino 기준): A=0, B=1, C=2, D=3, Left=4, Right=5, 조이스틱누름=6
BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT, BTN_RESET, BTN_FOLD = 0, 1, 4, 5, 6, 3
BTN_LEVEL = 2           # 모든 발 접지 → 수평 (비어 있던 C). 1초 길게 누르면 계단 모드
LONG_PRESS_SEC = 1.0    # C를 이만큼[초] 누르고 있으면 '길게' (계단 모드 들어가기/나오기)
STAIR_STICK = 0.3       # 계단 모드에서 조이스틱을 이만큼 넘게 밀어야 한 발 옮김 (살짝 건드려서 움직이는 것 방지)

# ── 6. 접기 / 서기 ────────────────────────────────────────────
FOLD_POSE = [[180 + SIDE[l] * 90, 62, 23] for l in range(NUM_LEGS)]   # SDK folding()과 같은 값
SIT_Z = -40.0            # 접기 전에 몸을 이 높이까지 내려 바닥에 앉힘 [mm]
FOLD_SEC = 1.5           # 관절 자세 바꾸는 시간 [초]
FOLD_BODY_SPEED = 80.0   # 접기 전 몸 내리는 속도 [mm/s]
STAND_SPEED = 60.0       # 처음 일어설 때 관절 속도 [도/s]

# ── 7. 수평 유지 ──────────────────────────────────────────────
LEVEL_ENABLE = True
#   시작할 때 수평 유지를 켤지. IMU가 없거나 측정이 실패하면 자동으로 꺼짐.

LEVEL_GAIN = 1.5
#   보정 세기 [1/초]. 기울기 e°가 남아 있으면 1초에 대략 GAIN × e° 만큼 몸통을 되돌림.
#   = 기울기가 약 1/GAIN 초 만에 63% 줄어듦 (1.5면 약 0.7초).
#   키우면: 빨리 수평이 됨. 너무 크면 블루투스·서보 지연(합쳐서 약 0.1~0.2초 추정) 때문에 왔다 갔다 흔들림.
#   줄이면: 느리지만 안 흔들림.
#   확인: 한쪽 다리 밑에 책을 넣고 [통계]의 '수평' 값이 몇 초 만에 DEADBAND 안으로 들어오는지,
#         넘어갔다 돌아오는(부호가 바뀌는) 일이 있는지 볼 것. 흔들리면 0.5씩 낮춤.

LEVEL_DEADBAND = 0.5
#   이 각도[도] 안이면 보정 안 함. 서보 분해능(관절 약 0.55°)·IMU 잡음(정지 시 약 0.03°) 때문에
#   0으로 두면 계속 미세하게 꿈틀거림. 키우면 덜 움직이지만 남는 기울기가 커짐.

LEVEL_MAX_DEG = 10.0
#   몸통을 최대 몇 도까지 돌려서 보정할지 [도]. 이보다 큰 경사는 다 못 맞춤.
#   키우면: 큰 경사도 맞추지만 다리가 가동범위 끝으로 가서 토크·안정성 ↓.

LEVEL_RATE = 15.0
#   몸통 기울기 최대 변화 속도 [도/초]. 갑자기 확 틀어지지 않게 하는 안전선.

LEVEL_CAL_DEG = 3.0
#   시작할 때 부호·배율 측정용으로 몸통을 기울여볼 각도 [도].
#   키우면 측정이 정확해지지만(잡음 대비 신호 ↑) 크게 움직임.

LEVEL_CAL_MIN_GAIN = 0.3
#   명령 1°에 IMU가 이보다 적게 변하면 측정 실패로 봄 (IMU가 몸통에 헐겁게 붙었거나 서보가 많이 처짐).
LEVEL_CAL_MAX_CROSS = 0.5
#   roll 명령에 pitch가 이 비율보다 크게 변하면 "축이 섞여 있음"으로 알려줌 (실패는 아님, 자동으로 맞춤).
LEVEL_CAL_MIN_SIN = 0.5
#   roll 명령과 pitch 명령에 대한 IMU 반응이 이 정도(sin 30°)도 안 갈라지면 구분 불가로 보고 실패.
LEVEL_BASE_MAX_DEG = 20.0
#   측정 시작 때 IMU가 이보다 크게 기울어 있다고 읽으면 '수평 기준(펌웨어 z)이 안 잡힘'으로 보고 실패.
#   (보드를 세워 달았는데 AX_* 를 안 바꾸면 roll이 90° 근처로 읽힘 → 그대로 보정하면 한계까지 틀어버림)

# ── 8. 접지 (모든 발 땅에 닿게) ─────────────────────────────────
#   다리를 하나씩 일정한 속도로 쭉 내리면서, 몸통 기울기가 변하기 시작하는 순간을 '발이 닿아서 몸을 밀기 시작함'으로 봄.
#   (발에 센서가 없어서 IMU를 접촉 센서 대신 씀. 공중에 뜬 발은 내려도 몸이 안 기울어짐)
#   예전 방식(1.5mm 내리고 → 0.15초 기다리고 → 0.1초 평균내고 반복)보다 기다리는 시간이 없어서 빠름.
GROUND_SPEED_NEAR = 10.0
GROUND_NEAR_MM = 4.0
GROUND_SPEED = 25.0
#   발 내리는 속도 [mm/s]: 처음 GROUND_NEAR_MM까지는 천천히(NEAR), 그 아래는 빠르게.
#   왜 두 단계: 대부분의 다리는 이미 닿아 있거나 몇 mm 안에 바닥이 있음. 감지 지연(GROUND_LATENCY) 동안
#     발이 더 내려가서 그만큼 세게 누르는데(25mm/s × 50ms ≈ 1.3mm), 이미 닿은 다리를 세게 누르면
#     옆 다리가 들려서 '언제 닿았나' 계산이 틀어짐. 가까운 곳은 살살, 깊은 구멍만 빨리 찾음.
#   40mm 구멍을 찾는 데 약 1.8초.
GROUND_LOOP_HZ = 100
#   내리는 동안 1초에 몇 번 명령을 보내고 IMU를 볼지. 서보 신호가 50Hz라 그 이상은 '명령 간격'만 촘촘해짐.
GROUND_LATENCY = 0.05
#   명령을 보낸 뒤 그 움직임이 PC에 도착한 IMU 값에 보이기까지 걸리는 시간 [초] (블루투스 + 서보 + 몸 흔들림).
#   ★ 시작할 때 measure_latency()가 실제로 재서 이 값을 덮어씀. 이건 못 쟀을 때 쓰는 기본값.
#   접촉 시점을 거꾸로 계산할 때 씀: '기울기가 변하기 시작한 시각 − 지연' 때 보낸 깊이가 실제 접촉 깊이.
GROUND_SMOOTH = 4
#   기울기 판단에 최근 IMU 샘플 몇 개를 평균낼지. 200Hz면 4개 = 20ms. 정지 잡음 약 0.03° → 약 0.015°.
GROUND_SETTLE_MAX = 0.3
#   멈춘 뒤 '흔들림이 가라앉을 때까지' 기다리는 최대 시간 [초]. 보통은 이보다 훨씬 빨리 끝남.
GROUND_STILL_WIN = 0.04
GROUND_STILL_TOL = 0.04
#   '가라앉음' 판정: 최근 GROUND_STILL_WIN초를 반으로 나눠서, 앞 절반 평균과 뒤 절반 평균의 차이가
#   GROUND_STILL_TOL[도]보다 작으면 멈춘 것으로 봄. (예전엔 무조건 0.15초씩 기다렸음)
GROUND_AVG = 0.025   # (지금은 measure 외엔 안 씀 — 기준은 최근 샘플 5개 평균)
#   기준 기울기를 몇 초 평균낼지. 200Hz → 0.025초 = 5개 (예전 50Hz에선 0.1초 걸렸음)
GROUND_THRESH_DEG = 0.1
#   기울기가 이만큼[도] 변하면 '닿음'. 평균낸 잡음(약 0.015°)의 약 7배.
#   ★ 이 값은 '확실히 기울었다'가 아니라 '잡음보다 확실히 크다' 수준이어야 함:
#     이미 닿아 있는 다리를 1.5mm 눌렀을 때 몸통은 0.2° 정도밖에 안 기움 (다른 다리 5개가 받쳐서).
#     임계값이 이보다 크면 닿아 있는 다리를 '공중'으로 착각하고 계속 눌러서, 결국 다른 다리가 들림.
#   키우면: 진동·잡음에 의한 잘못 감지 ↓, 대신 위 문제가 생김 + 감지까지 더 깊이 누름.
#   줄이면: 더 살짝 닿아도 감지, 대신 잡음에 걸림.
#   맞추는 법: bno086 테스트의 sdR·sdP(정지 잡음)를 보고, 그 값 ÷ √GROUND_SMOOTH 의 5~10배로.
GROUND_GAP_MIN_MM = 0.6
#   추정한 틈이 이보다 작으면 '원래 닿아 있음'으로 봄 [mm].
#   크면: 살짝 뜬 다리를 닿았다고 착각. 작으면: 닿아 있는 다리를 '내려서 닿음'으로 착각해서 바퀴를 더 돎.
#   쭉 내리는 방식에선 지연 추정 오차 1ms마다 0.02mm씩 흔들림 (20mm/s 기준).
GROUND_PRELOAD_MM = 0.5
#   접촉 시작점을 찾은 뒤 그보다 이만큼[mm] 더 눌러둠 (살짝 하중을 실어서 '닿기만 한' 상태를 피함).
#   키우면: 확실히 하중이 실리지만 다른 다리 하중을 뺏어서 그 다리가 들릴 수 있음.
GROUND_MAX_DOWN = 40.0
#   다리 하나를 최대 몇 mm까지 내려볼지. 이만큼 내려도 안 닿으면 '바닥 없음(구멍)'으로 보고 원래대로 올림.
GROUND_ABORT_DEG = 5.0
#   시작 때보다 이만큼[도] 넘게 기울면 넘어지는 중으로 보고 그 다리를 원래대로 되돌리고 중단.
GROUND_PASSES = 3
#   최대 몇 바퀴 돌지. 한 다리를 누르면 반대쪽 다리가 들릴 수 있어서 한 바퀴로는 부족할 수 있음.
#   한 바퀴 동안 '새로 내린 다리'가 하나도 없으면 다 닿은 것으로 보고 끝냄.
GROUND_ORDER = [0, 3, 2, 5, 1, 4]
#   다리 순서. 좌우를 번갈아 해서 한쪽으로 몰려 기울지 않게 함.
REGROUND_DEG = 0.0
#   서 있는 동안 수평 유지가 몸통을 이만큼[도] 넘게 돌리면, 발이 다 닿았는지 다시 확인. 0이면 끔(기본).

# ── 8-2. 마지막 하중 확인 (C 버튼·걷다 멈출 때 맨 마지막에) ─────────────
#   위의 빠른 접지는 '기울기가 변하기 시작한 순간 − 지연'으로 접촉 깊이를 거꾸로 계산함.
#   그래서 지연을 잘못 재거나, 서보가 칸 단위로 움직이거나, 수평 맞추느라 몸통을 돌리면 발이 살짝 뜬 채로 끝날 수 있음.
#   확인은 지연과 상관없는 '정지 비교'로 함:
#     다리 하나를 CHECK_TICKS칸만큼 살짝 들어봄 → 멈춘 뒤 기울기 비교
#       - 기울기가 CHECK_LOAD_DEG 넘게 변함 = 그 다리가 무게를 받치고 있었음 → 원래대로 내려놓음
#       - 거의 안 변함 = 떠 있었거나 거의 안 받치고 있었음 → 그 칸만큼씩 내리면서 기울기가 변할 때까지 (멈춰서 비교)
#   대가: 다리마다 약 0.3초 → 6개 약 2초 더 걸림.
CHECK_ENABLE = True
SERVO_TICK_DEG = 1.0 / (0.8 * 11.111 / 4.889)
#   서보 신호 1칸(PCA9685 1틱)이 관절 몇 도인지. 펌웨어 ANGLE_GAIN 0.8, TICKS_PER_DEG 11.111/4.889 에서 계산 → 약 0.55°.
#   서기 자세에서 femur 1칸 = 발 높이 약 0.8mm (hexapod_body 치수 기준). 이보다 작은 움직임은 명령해도 반올림돼서 사라짐
#   (GROUND_PRELOAD_MM 0.5mm는 1칸보다 작아서, 반올림에 따라 0칸 또는 1칸이 됨).
CHECK_TICKS = 2
#   확인할 때 들어보는/내리는 크기 [서보 칸]. MG996R 데드밴드(데이터시트 5µs ≈ 1칸) 때문에 1칸 명령은 안 움직일 수 있어서 2칸.
#   키우면: 확실히 움직이지만, 떠 있던 다리를 찾았을 때 그만큼 더 눌러질 수 있음 (최대 2칸 ≈ 1.6mm).
CHECK_LOAD_DEG = 0.05
#   들었을 때 기울기가 이만큼[도] 넘게 변하면 '받치고 있음'. 멈춘 상태 0.06초 평균이라 잡음은 약 0.01°.
#   시뮬레이션 기준: 받치는 다리를 1.6mm 들면 0.1~0.2°, 떠 있는 다리는 0.01° 안팎.
#   맞추는 법: C 누르면 나오는 [확인] 줄에 다리마다 변한 값이 찍힘. 받치는 다리 값들의 절반 정도로.
CHECK_AVG = 0.06
#   정지 상태 기울기를 몇 초 평균낼지 [초]. 200Hz면 12개.
CHECK_ROUNDS = 3
#   확인에서 다리를 내렸으면(하중이 옮겨가서 다른 다리가 뜰 수 있음) 다시 확인. 최대 몇 바퀴.
#   수평 유지는 발을 고정한 채 몸통만 돌리므로 계산상 발이 뜨지 않음 → 기본은 끔.
#   실제로 발이 뜨는 게 보이면(= IK 오차) 임시로 2~3 정도로 켜서 쓸 것.

# ── 8-1. 걸으면서 접지 ──────────────────────────────────────────
WALK_GROUND = True
#   걸을 때 발 3개가 착지할 때마다 몸을 잠깐 멈추고, 착지한 다리를 하나씩 위 방법으로 확인.
#   바닥이 꺼져 있으면 닿을 때까지 내림. 다리마다 '예상과 실제 차이'를 배워서 다음 걸음의 멈출 높이에 씀.
#   대가: 걸음마다 잠깐 멈춤. 끄면 예전처럼 안 멈추고 걸음 (IMU 없어도 됨).
#   착지 방식 ('내려놓으면서 찾기'):
#     1) 공중에서는 빠르게 내려오다가 예상 바닥보다 LAND_APPROACH mm 위에서 멈춤 (3개 동시, 몸도 움직이는 중)
#     2) 몸을 잠깐 멈추고, 그 3개를 하나씩 거기서부터 내려서 닿는 순간 멈춤
#        (동시에 내리면 기울기가 변해도 어느 발이 닿았는지 모름. 몸이 움직이면 걷는 동작 때문에도 기울기가 변함)
#     → 발이 항상 공중에서 내려오니까 '원래 닿아 있나'를 구분할 필요가 없어서 판정이 안정적이고,
#       예상보다 높은 바닥(턱)도 LAND_APPROACH mm까지는 부딪히지 않고 찾음.
LAND_APPROACH = 6.0
#   공중에서 내려올 때 예상 바닥보다 몇 mm 위에서 멈출지.
#   키우면: 더 높은 턱도 부드럽게 찾음. 대신 다리마다 그만큼 더 내려와야 해서 느려짐.
#   줄이면: 빠르지만, 그보다 높은 턱은 공중 단계에서 그냥 부딪힘 (그 다리는 '공중 단계에서 이미 닿음'으로 나옴).
#     시뮬레이션(평지): 6mm → 이미 닿음 0/27, 10.7mm/s / 4mm → 6/33(18%), 12.2mm/s
#   맞추는 법: [통계]의 '공중 단계에서 이미 닿음'이 착지 횟수의 10%를 넘으면 2mm씩 올릴 것.
#   ★ 발마다 찾은 높이는 '그 자리'에만 쓰고, 발을 떼서 새로 디딜 때는 다시 예상 높이에서 시작함.
#   ★ '예상 바닥' = 지금 바닥에 있는 발들의 높이 중앙값 + 그 다리의 착지 보정(배운 값).
#     3발로 서 있을 때 몸은 6발일 때보다 처지고 한쪽으로 기울어서(서보·다리가 휨), 그냥 기준 높이 + 몇 mm로 멈추면
#     실제로는 바닥 안쪽일 수 있음 (시뮬레이션에서 평지인데도 다리별로 +3~+5mm 높게 나왔음).
LAND_SPEED = 40.0
LAND_SPEED_NEAR = 15.0
#   걷다가 착지할 때 내리는 속도 [mm/s] (서서 접지할 때는 GROUND_SPEED / GROUND_SPEED_NEAR 그대로).
#   시뮬레이션(지연 50ms): 느림 10·빠름 25 → 착지당 1.96초 / 15·40 → 1.60초 / 20·40 → 1.46초.
#   빠를수록 감지 전에 더 세게 누름: 더듬는 발 최대 힘 중앙값 약 210g / 250g / 310g (몸무게 2kg 가정).
#   실제 지연이 길면([지연] 줄) 같은 속도에서도 더 세게 누르니까 [지연]이 100ms 넘으면 느림을 10으로 내릴 것.
SAG_LEARN_N = 5
SAG_MAX = 12.0
#   다리별 착지 보정 학습: 다리마다 '예상 바닥과 실제 바닥의 차이'를 최근 SAG_LEARN_N번 중앙값으로 기억.
#   (3발로 설 때 처짐·기울기가 다리마다 다름: 시뮬레이션 평지에서 다리별로 +3~+5mm, 턱 옆을 따라 걸으면 그 다리만 더 큼)
#   - 중앙값이라 한 번짜리 구멍·턱은 무시되고, 같은 게 3번 넘게 이어지면(턱을 따라 걷기) 배움
#   - '공중에서 이미 닿음'은 '바닥이 적어도 이만큼 높다'는 뜻이라 +LAND_APPROACH/2 만 넣음
#   - 범위: 위로는 SAG_MAX까지, 아래로는 −LAND_APPROACH/2까지만.
#     아래로 많이 배우면 멈추는 높이가 바닥보다 낮아져서, 구멍을 벗어난 뒤 그 다리가 공중 단계에서 바닥을 그냥 침.
#     (위로 틀린 건 더 내려와서 찾으면 되니까 느려지기만 함 — 그래서 위아래 한계가 다름)
#   [통계]의 '다리별 보정'으로 확인 → 이게 그대로 '다리별 3발 처짐 실측'이 됨.
RECENTER_OUTLIER_MM = 5.0
#   착지 후 몸 자세 되돌릴 때, 발 평면에서 이만큼[mm] 넘게 튀는 발(구멍·턱 위)은 빼고 평면을 맞춤.
GROUND_SLOW_BEFORE = 2.0
#   예상 바닥보다 이만큼[mm] 위부터 천천히(서서: GROUND_SPEED_NEAR, 걸을 때: LAND_SPEED_NEAR) 내림. 그 위는 빠르게.
WALK_GROUND_ON_STOP = True
#   걷다가 멈추면 6개 다리 전체 접지(C 버튼과 같은 것)를 한 번 함. 다 닿아 있으면 약 3초.
#   필요한 이유: 착지 때 닿았던 발도 다른 발이 움직이며 하중이 옮겨가면 살짝 뜰 수 있음.
LAND_HOLE_STOP = True
#   걷다가 GROUND_MAX_DOWN만큼 내려도 바닥이 없으면(구멍·계단 끝) 멈추고 알려줌.

STATS_SEC = 5.0          # 이 간격[초]마다 통계 출력 (0이면 끔)
# ═════════════════════════════════════════════════════════════════

DIRECT_SPEED = 1e9       # SDK 보간을 끄는 값 (계산한 각도를 그대로 보냄). 건드리지 말 것
assert 0.5 < DUTY < 1.0, "DUTY는 0.5보다 커야 함 (작으면 지지 다리가 3개 미만이 되는 순간이 생김)"


def approach(cur, target, step):
    """cur 를 target 쪽으로 최대 step 만큼만 움직임."""
    if cur < target:
        return min(target, cur + step)
    return max(target, cur - step)


def swing_profile(u):
    """공중 진행도 u(0~1) → (수평 진행 0~1, 높이 비율 0~1)."""
    if u <= SWING_FLAT:
        s = 0.0
    elif u >= 1.0 - SWING_FLAT:
        s = 1.0
    else:
        s = 0.5 - 0.5 * math.cos(math.pi * (u - SWING_FLAT) / (1.0 - 2 * SWING_FLAT))

    if u < SWING_UP_END:
        h = math.sin(0.5 * math.pi * u / SWING_UP_END)
    elif u < SWING_DOWN_START:
        h = 1.0
    else:
        w = (u - SWING_DOWN_START) / (1.0 - SWING_DOWN_START)
        h = (1.0 - w) ** 2
    return s, h


def solve(body, pose, feet):
    """hexapod_body 역기구학 + SDK 가동범위 검사. 둘 중 하나라도 안 되면 None.
    (SDK는 범위 밖 각도를 잘라서 보내므로, 잘리기 전에 여기서 '못 닿음'으로 처리해야 궤적이 안 틀어짐)"""
    joints, _ = body._solve(pose, feet)
    if joints is None:
        return None
    for l in range(NUM_LEGS):
        for j in range(NUM_JOINTS):
            lo, hi = JOINT_LIMITS[l][j]
            if not (lo - 1e-6 <= joints[l][j] <= hi + 1e-6):
                return None
    return joints


def why_unsolvable(body, pose, feet):
    """solve 실패 원인 설명 (시작할 때 진단용)."""
    joints, which = body._solve(pose, feet)
    if joints is None:
        legs = which if isinstance(which, (list, tuple)) else [which]
        where = []
        for l in legs:
            if isinstance(l, int) and 0 <= l < NUM_LEGS:
                f = feet[l]
                where.append(f"다리{l} (발 위치 x {f[0]:.0f}, y {f[1]:.0f}, z {f[2]:.0f}mm)")
        return ("hexapod_body 역기구학 기준으로 " + (", ".join(where) if where else "다리")
                + "가 안 닿음 (다리 길이 밖이거나 hexapod_body 자체 각도 제한)")
    bad = []
    for l in range(NUM_LEGS):
        for j in range(NUM_JOINTS):
            lo, hi = JOINT_LIMITS[l][j]
            a = joints[l][j]
            if not (lo - 1e-6 <= a <= hi + 1e-6):
                bad.append(f"다리{l} 관절{j}={a:.1f}° (SDK 범위 {lo}~{hi})")
    return "SDK 가동범위 밖: " + ", ".join(bad)


def max_delta(a, b):
    return max(abs(a[l][j] - b[l][j]) for l in range(NUM_LEGS) for j in range(NUM_JOINTS))


class SdkSender:
    """수정판 SDK로 관절 각도를 보냄. 바뀐 정수 각도만 보내기·전송 실패 감지는 SDK가 처리."""

    def __init__(self, hx, link):
        self.hx, self.link = hx, link

    def direct_mode(self):
        """SDK 보간을 끄고 계산한 각도를 그대로 보내는 모드."""
        self.hx.max_speed = [[DIRECT_SPEED] * NUM_JOINTS for _ in range(NUM_LEGS)]
        self.hx.timedelay = 0.0

    def send(self, joints) -> bool:
        if not self.hx.state_known:
            return False
        self.hx.set_pose(joints)
        self.hx.move_update(self.link)
        return self.hx.state_known


class Gait:
    """연속 삼각 보행. 몸 좌표계에서 계산하므로 body.pose 의 x, y, yaw 는 항상 0."""

    def __init__(self, body, sender):
        self.body, self.sender = body, sender
        self.offset = [0.5 if l in hb.GROUP_B else 0.0 for l in range(NUM_LEGS)]   # B조는 반 주기 어긋남
        self.min_scale = 1.0            # 통계: 거버너가 늦춘 최소 시간 배율
        self.dist = 0.0                 # 통계: 몸이 실제로 이동한 거리 [mm] (계산값)
        self.reset()

    @staticmethod
    def _tucked(home):
        """앞·뒤 다리 기본 자리를 coxa 축 중심으로 TUCK_DEG 만큼 옆쪽으로 돌림 (가운데 다리는 그대로).
        앞/뒤/가운데는 x 좌표로 판단 (다리 번호 가정 없음)."""
        xmax = max(abs(h[0]) for h in home)
        out = []
        for l, (hx_, hy) in enumerate(home):
            if TUCK_DEG == 0 or abs(hx_) < 0.3 * xmax:
                out.append([hx_, hy])
                continue
            px, py = Gait.hip_xy(l, hx_, hy)                           # coxa 축
            a = math.radians(TUCK_DEG) * (1 if hx_ * hy > 0 else -1)   # 앞다리는 뒤로, 뒷다리는 앞으로
            dx, dy = hx_ - px, hy - py
            out.append([px + dx * math.cos(a) - dy * math.sin(a), py + dx * math.sin(a) + dy * math.cos(a)])
        return out

    @staticmethod
    def hip_xy(l, hx_, hy):
        """다리 l의 coxa(hip) 회전축 위치. hexapod_body.MOUNT(실측)가 있으면 그걸, 없으면 방사형 HIP_RADIUS 가정."""
        mount = getattr(hb, "MOUNT", None)
        if mount is not None:
            return mount[l][0], mount[l][1]
        r = math.hypot(hx_, hy)
        return hx_ / r * HIP_RADIUS, hy / r * HIP_RADIUS

    def reset(self):
        """지금 서 있는 자세를 기준으로 다시 시작 (capture 직후에 부름). 이후 settle() 로 발을 옮겨야 함."""
        b = self.body
        if not hasattr(self, "lift_req"):
            self.lift_req = LIFT_MM                     # 버튼으로 바꾼 발 높이는 펴기·재시작 후에도 유지
        self.pending_land = []                          # 방금 착지해서 접지 확인할 다리들
        self.landed_n = 0                               # 통계: 걸으면서 접지 확인한 다리 수
        self.land_early = 0                             # 통계: 내려오기 전부터 이미 닿아 있던 경우 (= 공중 단계에서 부딪힘)
        self.ref_off = 0.0                              # 바닥에 있는 발들의 높이 중앙값 (기준 대비 mm) = 다음 발판 예상 높이
        self.recentered = 0.0                           # 통계: 착지 후 몸 높이 되돌린 양 누적 [mm]
        if not hasattr(self, "bias_hist"):              # 펴기·재시작해도 유지
            self.bias_hist = [deque(maxlen=SAG_LEARN_N) for _ in range(NUM_LEGS)]
            self.land_bias = [0.0] * NUM_LEGS           # 다리별 착지 보정 [mm] (+ = 바닥이 예상보다 높게 나옴)
        self.land_moved = []                            # 통계: (다리, 더 내린 mm) — 바닥이 예상보다 낮았던 경우
        self.hole_leg = None                            # 바닥을 못 찾은 다리
        self.base_home = self._tucked([[h[0], h[1]] for h in b.home])   # 폭 1.0일 때 기본 자리
        self.hips = [self.hip_xy(l, h[0], h[1]) for l, h in enumerate(b.home)]   # coxa 축 위치
        self.spread = 1.0
        self.home = self._home_at(1.0)
        self.feet = [list(f) for f in b.feet]
        self.ground = [f[2] for f in self.feet]          # 다리별 '지금 디딘 곳'의 바닥 높이 (접지로 바뀜)
        self.base_ground = list(self.ground)             # 평평한 바닥 기준 높이. 새로 디딜 때는 여기서 시작
        self.z_target = b.pose[2]
        self.tilt_target = [b.pose[3], b.pose[4]]   # 서 있을 때 몸통 roll/pitch 목표 (hexapod_body 기준, 도). Leveler가 씀
        self.tilt_blocked = False                   # 목표 기울기에 다리가 안 닿아서 막혔는지
        self.phase = 0.0
        self.walking = False
        self.in_swing = [False] * NUM_LEGS
        self.start = [list(f) for f in self.feet]
        self.v = [0.0, 0.0]             # 몸 속도 [mm/s] (앞, 옆)
        self.w = 0.0                    # 회전 속도 [도/s]

        self.last_joints = solve(b, self._pose(), self.feet)
        if self.last_joints is None:
            raise RuntimeError("기본 자세부터 계산 안 됨 — " + why_unsolvable(b, self._pose(), self.feet))
        home_feet = [[h[0], h[1], g] for h, g in zip(self.home, self.ground)]
        if solve(b, self._pose(), home_feet) is None:
            raise RuntimeError(f"TUCK_DEG {TUCK_DEG}° 기본 자리에 다리가 안 닿음 — "
                               + why_unsolvable(b, self._pose(), home_feet) + " → TUCK_DEG를 줄일 것")
        self._recheck()

    def _recheck(self):
        """지금 높이에서 보폭·발 높이를 다시 정함 (높이가 바뀌면 닿는 범위도 바뀜)."""
        self.stride, self.lift_max, why = self._find_stride_lift()
        self.lift = min(self.lift_req, self.lift_max)
        self.z_checked = self.body.pose[2]
        print(f"[걸음] 보폭 {self.stride:.0f}mm, 발 드는 높이 {self.lift:.0f}mm (이 높이에서 최대 {self.lift_max:.0f}mm)"
              + (f" — 보폭이 줄어든 이유: {why}" if why else ""))

    def set_lift(self, delta):
        """발 드는 높이를 delta[mm]만큼 바꿈 (걷는 중에도 됨 — 다음에 드는 발부터 적용)."""
        want = max(LIFT_MIN, min(LIFT_MAX, self.lift_req + delta))
        self.lift_req = want
        self.lift = min(want, self.lift_max)
        print(f"[걸음] 발 드는 높이 {self.lift:.0f}mm"
              + (f" (요청 {want:.0f}mm는 지금 몸 높이에서 다리가 안 닿아서 최대 {self.lift_max:.0f}mm)"
                 if want > self.lift_max + 1e-9 else ""))

    def _pose(self, z=None):
        p = self.body.pose
        return [0.0, 0.0, p[2] if z is None else z, p[3], p[4], 0.0]

    def _unreachable_reason(self, stride, lift):
        """이 보폭·발 높이가 안 되는 이유. 되면 None."""
        pose = self._pose()
        for l in range(NUM_LEGS):
            for dx, dh in ((0.0, lift), (stride / 2, 0.0), (-stride / 2, 0.0)):
                feet = [list(f) for f in self.feet]
                feet[l] = [self.home[l][0] + dx, self.home[l][1], self.ground[l] + dh]
                if solve(self.body, pose, feet) is None:
                    return f"다리{l} 발을 {'앞' if dx > 0 else '뒤' if dx < 0 else '위'}로 — " \
                           + why_unsolvable(self.body, pose, feet)
        for side in (1, -1):                           # 같은 쪽 이웃 발끝 간격
            legs = sorted([l for l in range(NUM_LEGS) if self.home[l][1] * side > 0],
                          key=lambda l: -self.home[l][0])
            for a, c in zip(legs, legs[1:]):
                gap = math.hypot((self.home[a][0] - stride / 2) - (self.home[c][0] + stride / 2),
                                 self.home[a][1] - self.home[c][1])
                if gap < MIN_FOOT_GAP:
                    return f"다리{a}·다리{c} 발끝 간격 {gap:.0f}mm < MIN_FOOT_GAP {MIN_FOOT_GAP:.0f}mm"
        return None

    def _find_stride_lift(self):
        """기본 자리에서 실제로 되는 보폭과 발 높이를 찾음 (5mm씩 줄여가며). (보폭, 높이, 보폭이 줄어든 이유)"""
        stride, why = MAX_STRIDE, None
        while stride > 10.0:
            reason = self._unreachable_reason(stride, 0.0)
            if reason is None:
                break
            why = why or reason
            stride -= 5.0
        lift = LIFT_MAX                                    # 되는 최대 높이를 찾아둠 (버튼으로 올릴 때 상한)
        while lift > LIFT_MIN and self._unreachable_reason(stride, lift) is not None:
            lift -= 5.0
        return max(stride, 10.0), max(lift, LIFT_MIN), why

    # ── 폭 / 높이 ──
    def _home_at(self, s):
        """폭 배율 s일 때 기본 자리: coxa 축에서 원래 자리까지의 수평 거리를 s배로."""
        return [[px + (hx_ - px) * s, py + (hy - py) * s]
                for (hx_, hy), (px, py) in zip(self.base_home, self.hips)]

    @staticmethod
    def support_margin(pts):
        """몸 중심(0,0)에서 지지 다각형 변까지 최소 거리 [mm]. 중심이 밖이면 음수."""
        c = sorted(pts, key=lambda p: math.atan2(p[1], p[0]))       # 몸 중심 기준 각도 순 = 볼록 다각형 둘레
        m = float("inf")
        for (x1, y1), (x2, y2) in zip(c, c[1:] + c[:1]):
            L = math.hypot(x2 - x1, y2 - y1)
            if L < 1e-9:
                continue
            m = min(m, (x1 * y2 - x2 * y1) / L)                        # 반시계 둘레라 안쪽이 +
        return m

    def tripod_margin(self, home):
        a = [home[l] for l in range(NUM_LEGS) if l not in hb.GROUP_B]
        b_ = [home[l] for l in hb.GROUP_B]
        return min(self.support_margin(a), self.support_margin(b_))

    def _stand_ok(self, s, z):
        home = self._home_at(s)
        feet = [[h[0], h[1], g] for h, g in zip(home, self.ground)]
        return solve(self.body, self._pose(z), feet) is not None

    def _fits(self, s, z):
        """폭 s, 높이 z에서 서 있고 + 발을 하나씩 들 수 있고 + 안정 여유가 충분한가. 되면 None, 안 되면 이유."""
        home = self._home_at(s)
        pose = self._pose(z)
        feet = [[h[0], h[1], g] for h, g in zip(home, self.ground)]
        if solve(self.body, pose, feet) is None:
            return "다리가 안 닿음 — " + why_unsolvable(self.body, pose, feet)
        for l in range(NUM_LEGS):
            up = [list(f) for f in feet]
            up[l][2] += SPREAD_MIN_LIFT
            if solve(self.body, pose, up) is None:
                return f"다리{l}을 {SPREAD_MIN_LIFT:.0f}mm 못 듦"
        m = self.tripod_margin(home)
        if m < SPREAD_MIN_MARGIN:
            return f"3발 지지 안정 여유 {m:.0f}mm < {SPREAD_MIN_MARGIN:.0f}mm"
        return None

    def best_spread(self, z):
        """높이 z에서 쓸 수 있는 가장 넓은 폭. 없으면 None."""
        s = 1.0
        while s >= SPREAD_MIN - 1e-9:
            if self._fits(s, z) is None:
                return round(s, 3)
            s -= SPREAD_STEP
        return None

    def _move_z(self, z):
        """서 있는 채로 몸 높이만 z로 (발은 그대로)."""
        b = self.body
        z0 = b.pose[2]
        n = max(1, round(abs(z - z0) / Z_RATE * LOOP_HZ))
        for k in range(1, n + 1):
            e = 0.5 - 0.5 * math.cos(math.pi * k / n)
            pose = self._pose(z0 + (z - z0) * e)
            joints = solve(b, pose, self.feet)
            if joints is None:
                print("[높이] 중간에 못 닿음 — " + why_unsolvable(b, pose, self.feet))
                return False
            if not self.sender.send(joints):
                raise ConnectionError("전송 실패")
            b.pose, self.last_joints = pose, joints
            time.sleep(1.0 / LOOP_HZ)
        self.z_target = b.pose[2]
        return True

    def _replant(self, s):
        """폭을 s로: 발을 3개씩 들어서 새 기본 자리에 놓음."""
        old_home, old_spread = self.home, self.spread
        self.home, self.spread = self._home_at(s), s
        if self.settle(lift=REPLANT_LIFT):
            return True
        self.home, self.spread = old_home, old_spread                  # 실패하면 원래 폭 기억으로
        return False

    def change_height(self, z_new):
        """서 있을 때 몸 높이를 z_new로. 안 닿으면 폭을 줄여서라도 올리고, 내릴 때는 되는 만큼 폭을 되돌림.
        실제로 간 높이를 돌려줌."""
        z_cur = self.body.pose[2]
        s = self.best_spread(z_new)
        if s is None:
            # 목표까지는 안 됨 → 가장 높이 되는 곳까지만
            z_try = z_new
            while z_try - 5.0 > z_cur and self.best_spread(z_try) is None:
                z_try -= 5.0
            s = self.best_spread(z_try)
            why = self._fits(SPREAD_MIN, z_new)
            if s is None or abs(z_try - z_cur) < 1e-6:
                print(f"[높이] 더 못 올림 — 폭 {SPREAD_MIN:.0%}로 줄여도 {z_new:.0f}mm 안 됨: {why}")
                self.z_target = z_cur
                return z_cur
            print(f"[높이] {z_new:.0f}mm는 안 됨 ({why}) → {z_try:.0f}mm까지만")
            z_new = z_try

        if abs(s - self.spread) < 1e-6:                                  # 폭 그대로
            self._move_z(z_new)
        elif s < self.spread:                                            # 좁혀야 함 (올릴 때)
            if self._stand_ok(s, z_cur):
                ok = self._replant(s) and self._move_z(z_new)
            else:                                                        # 지금 높이에선 좁히면 무릎이 너무 접힘
                z_mid = next((z for z in self._steps(z_cur, z_new)
                              if self._stand_ok(self.spread, z) and self._stand_ok(s, z)), None)
                ok = z_mid is not None and self._move_z(z_mid) and self._replant(s) and self._move_z(z_new)
            if not ok:
                print("[높이] 폭 줄이기 실패 — 지금 자리에서 멈춤")
        else:                                                            # 넓혀도 됨 (내릴 때)
            if self._stand_ok(s, z_cur):
                self._replant(s)
                self._move_z(z_new)
            else:
                self._move_z(z_new)
                if self._stand_ok(s, z_new):
                    self._replant(s)

        self._recheck()
        print(f"[높이] 몸 높이 {self.body.pose[2]:.0f}mm, 폭 {self.spread:.0%}, "
              f"3발 지지 안정 여유 {self.tripod_margin(self.home):.0f}mm")
        return self.body.pose[2]

    @staticmethod
    def _steps(a, b, step=5.0):
        """a에서 b 쪽으로 step씩 (a 제외, b 포함)."""
        out, z = [], a
        while abs(b - z) > step:
            z += step if b > z else -step
            out.append(z)
        out.append(b)
        return out

    def _settle_path(self, group, start, lift, n):
        """group 다리들을 start에서 기본 자리로 옮기는 전체 경로를 미리 계산.
        전부 닿으면 [(feet, joints), ...], 하나라도 안 닿으면 (None, 이유)."""
        b, pose, path = self.body, self._pose(), []
        for k in range(1, n + 1):
            s = k / n
            feet = [list(f) for f in start]
            for l in group:
                tx, ty = self.home[l]
                feet[l] = [start[l][0] + (tx - start[l][0]) * s, start[l][1] + (ty - start[l][1]) * s,
                           self.ground[l] + lift * math.sin(math.pi * s)]
            joints = solve(b, pose, feet)
            if joints is None:
                return None, f"{k}/{n} 지점에서 " + why_unsolvable(b, pose, feet)
            path.append((feet, joints))
        return path, None

    def settle(self, lift=None):
        """발을 지금 자리에서 기본 자리(TUCK·폭 적용)로 옮김. A조 → B조 순서로 3개씩 들어서.
        ★ 움직이기 전에 경로 전체를 먼저 계산함 → 중간에 막혀서 다리가 공중에 뜬 채로 멈추는 일 없음.
           원래 높이로 안 되면 발을 덜 들어서 다시 계산."""
        b = self.body
        lift = self.lift if lift is None else lift
        n = max(1, round(SETTLE_SEC * LOOP_HZ))
        for group in (tuple(l for l in range(NUM_LEGS) if l not in hb.GROUP_B), hb.GROUP_B):
            start = [list(f) for f in self.feet]
            if all(math.hypot(start[l][0] - self.home[l][0], start[l][1] - self.home[l][1]) < 0.5
                   for l in group):
                continue                                   # 이미 제자리
            path, why, used = None, None, None
            for try_lift in sorted({lift, lift * 0.5, 15.0, 8.0}, reverse=True):
                if try_lift > lift + 1e-9:
                    continue
                path, why = self._settle_path(group, start, try_lift, n)
                if path is not None:
                    used = try_lift
                    break
            if path is None:
                print(f"[걸음] 기본 자리로 못 옮김 (다리 {group}, 발을 8mm만 들어도 안 됨) — {why}\n"
                      "       아무것도 안 움직였음. TUCK_DEG를 줄이거나 hexapod_body 각도 제한 확인")
                return False
            if used < lift - 1e-9:
                print(f"[걸음] 다리 {group}: 발을 {lift:.0f}mm 들면 안 닿아서 {used:.0f}mm만 들고 옮김")
            for feet, joints in path:
                if not self.sender.send(joints):
                    return False
                self.feet, self.last_joints = feet, joints
                b.feet = [list(f) for f in feet]
                time.sleep(1.0 / LOOP_HZ)
        return True

    def move_tilt(self, roll, pitch, sec):
        """서 있는 채로 몸통 기울기를 sec초 동안 부드럽게 바꿈 (발은 그대로). 수평 유지 측정용."""
        b = self.body
        r0, p0 = b.pose[3], b.pose[4]
        n = max(1, round(sec * LOOP_HZ))
        for k in range(1, n + 1):
            e = 0.5 - 0.5 * math.cos(math.pi * k / n)
            pose = [0.0, 0.0, b.pose[2], r0 + (roll - r0) * e, p0 + (pitch - p0) * e, 0.0]
            joints = solve(b, pose, self.feet)
            if joints is None:
                print("[수평] 몸통을 그만큼 못 기울임 — " + why_unsolvable(b, pose, self.feet))
                return False
            if not self.sender.send(joints):
                return False
            b.pose, self.last_joints = pose, joints
            time.sleep(1.0 / LOOP_HZ)
        self.tilt_target = [roll, pitch]
        return True

    def _target(self, l, v, w, t_stance):
        """공중 발이 착지할 자리 (몸 기준). 바닥에 있는 동안 뒤로 밀릴 만큼 미리 앞에 놓음."""
        a = math.radians(w * t_stance / 2)
        c, s = math.cos(a), math.sin(a)
        hx, hy = self.home[l]
        return [c * hx - s * hy + v[0] * t_stance / 2,
                s * hx + c * hy + v[1] * t_stance / 2]

    probe_on = False                     # 걸으면서 접지 확인을 하는 중인가 (main이 IMU 상태 보고 정함)

    def land_above(self, l):
        """다리 l을 새로 디딜 때 발을 멈출 높이 (평평한 기준 대비 mm)
        = 지금 받치고 있는 발들의 높이 + 다리 l의 착지 보정(배운 값) + LAND_APPROACH."""
        if not self.probe_on:
            return self.ref_off
        return self.ref_off + self.land_bias[l] + LAND_APPROACH

    def _update_ref(self, swing):
        """지금 바닥에 있는 발들(공중 다리 빼고)의 높이 중앙값 → ref_off (다음 발판 예상 높이).
        바닥 발들은 직접 더듬어서 놓은 높이라 몸 처짐·지형이 이미 들어가 있음."""
        offs = sorted(self.feet[l][2] - self.base_ground[l] for l in range(NUM_LEGS) if not swing[l])
        if not offs:
            return
        n = len(offs)
        self.ref_off = offs[n // 2] if n % 2 else (offs[n // 2 - 1] + offs[n // 2]) / 2

    def _learn_bias(self, l, sample):
        h = self.bias_hist[l]
        h.append(sample)
        v = sorted(h)
        n = len(v)
        m = v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2
        self.land_bias[l] = max(-LAND_APPROACH / 2, min(SAG_MAX, m))

    def land_probe(self, grounder):
        """방금 내려온 다리들(예상 바닥보다 LAND_APPROACH mm 위에 떠 있음)을 하나씩 내려서 닿게 함 (몸은 멈춘 상태).
        'ok' / 'hole' (바닥 없음) / 'abort' (IMU 끊김·넘어짐) 를 돌려줌."""
        legs, self.pending_land = self.pending_land, []
        grounder.wait_still()                            # 내려오던 흔들림이 가라앉을 때까지만
        start_tilt = grounder._tilt()
        if start_tilt is None:
            return "abort"
        status = "ok"
        for l in legs:
            z_start = self.feet[l][2]
            expected = z_start - LAND_APPROACH - self.base_ground[l]   # 예상 바닥 (기준 대비, 처짐 보정 포함)
            r = grounder.probe(l, start_tilt, expect=LAND_APPROACH, fast=LAND_SPEED, slow=LAND_SPEED_NEAR)
            s = r["status"]
            self.ground[l] = self.feet[l][2]             # 이 자리의 바닥 높이 (발을 떼면 잊고, 다음 자리는 기준에서 다시 찾음)
            self.landed_n += 1
            if s in ("contact", "already"):
                if s == "contact":                       # 접촉 높이 = 지금 발 높이 + 살짝 더 누른 양
                    off = self.feet[l][2] + GROUND_PRELOAD_MM - self.base_ground[l]
                else:                                    # 내려오기 전부터 닿아 있었음 → 바닥은 적어도 시작 높이
                    off = z_start - self.base_ground[l]
                    self.land_early += 1
                dev = off - expected                     # 예상과의 차이: + = 높은 바닥(턱), − = 낮은 바닥
                if s == "contact":
                    self._learn_bias(l, self.land_bias[l] + dev)     # 한 번짜리 구멍·턱은 중앙값이 걸러냄
                elif s == "already":
                    self._learn_bias(l, self.land_bias[l] + LAND_APPROACH / 2)
                if abs(dev) >= 1.0:
                    self.land_moved.append((l, dev))
            elif s in ("none", "reach"):
                status = "hole"
                self.hole_leg = l
            elif s == "abort":
                return "abort"
        if status == "ok":
            self._recenter()
        return status

    def _feet_plane(self):
        """발 6개 높이(기준 대비)에 평면 z = c + a·x + b·y 를 맞춤. 구멍·턱 위 발처럼 혼자 튀는 발은 빼고 다시 맞춤.
        (c, a, b) 를 돌려줌."""
        pts = [(self.feet[l][0], self.feet[l][1], self.feet[l][2] - self.base_ground[l]) for l in range(NUM_LEGS)]

        def fit(sel):
            n = len(sel)
            sx = sum(p[0] for p in sel); sy = sum(p[1] for p in sel); sz = sum(p[2] for p in sel)
            sxx = sum(p[0] ** 2 for p in sel); syy = sum(p[1] ** 2 for p in sel); sxy = sum(p[0] * p[1] for p in sel)
            sxz = sum(p[0] * p[2] for p in sel); syz = sum(p[1] * p[2] for p in sel)
            A = [[n, sx, sy, sz], [sx, sxx, sxy, sxz], [sy, sxy, syy, syz]]
            for i in range(3):                                  # 3×3 연립방정식 (가우스 소거)
                piv = max(range(i, 3), key=lambda r: abs(A[r][i]))
                if abs(A[piv][i]) < 1e-9:
                    return None
                A[i], A[piv] = A[piv], A[i]
                for r in range(3):
                    if r != i:
                        f = A[r][i] / A[i][i]
                        A[r] = [A[r][c] - f * A[i][c] for c in range(4)]
            return [A[i][3] / A[i][i] for i in range(3)]

        sol = fit(pts)
        if sol is None:
            return None
        c, a, b_ = sol
        keep = [p for p in pts if abs(p[2] - (c + a * p[0] + b_ * p[1])) < RECENTER_OUTLIER_MM]
        if 4 <= len(keep) < len(pts):
            sol = fit(keep) or sol
        return sol

    def _recenter(self, sec=0.15):
        """발 6개가 다 바닥에 있을 때, 몸 높이와 기울기를 '발들 기준 원래 자세'로 되돌림 (다리 6개를 같이 폄/접음).
        왜 필요: 발을 '막 닿은' 높이에 놓으면, 그때 몸은 다른 3발 위에서 이미 처져 있음 → 그 다리가 무게를 받으면 또 처짐
                → 착지할 때마다 몸이 처짐만큼 계속 내려앉고(시뮬레이션에서 착지마다 약 3.7mm),
                  처지는 양이 다리마다 달라서 앞으로 점점 숙여짐.
        발 6개에 평면을 맞춰서 그 평면만큼(높이 + 기울기) 되돌림. 계단·경사면이면 몸이 그 면과 나란하게 따라감
        (멈추면 접지+수평이 중력 기준으로 다시 맞춤)."""
        b = self.body
        pl = self._feet_plane()
        if pl is None:
            return
        c, a, b_ = pl
        shift = [c + a * f[0] + b_ * f[1] for f in self.feet]
        if max(abs(s) for s in shift) < 0.3:
            return
        start = [list(f) for f in self.feet]
        n = max(1, round(sec * LOOP_HZ))
        for k in range(1, n + 1):
            e = 0.5 - 0.5 * math.cos(math.pi * k / n)
            feet = [[f[0], f[1], f[2] - s * e] for f, s in zip(start, shift)]
            joints = solve(b, b.pose, feet)
            if joints is None:
                return                                  # 못 닿으면 거기서 멈춤 (다음 착지에서 다시)
            if not self.sender.send(joints):
                raise ConnectionError("전송 실패")
            self.feet, self.last_joints = feet, joints
            b.feet = [list(f) for f in feet]
            time.sleep(1.0 / LOOP_HZ)
        self.ground = [g - s for g, s in zip(self.ground, shift)]
        self.recentered += c

    def _build(self, phase, dt, v, w, t_stance, lift_scale, v_tgt=None, w_tgt=None):
        """다음 순간의 발 6개 위치 (아직 확정 안 함).
        v, w: 이번 순간 몸이 실제로 움직이는 속도 (바닥 발을 미는 양)
        v_tgt, w_tgt: 착지 목표 계산용 속도 (안 주면 v, w). 부드럽게 변하는 값을 줘야 공중 발이 안 튐"""
        if v_tgt is None:
            v_tgt, w_tgt = v, w
        a = math.radians(-w * dt)
        c, s = math.cos(a), math.sin(a)
        feet, swing_now, starts = [], [], [list(p) for p in self.start]
        for l in range(NUM_LEGS):
            f = self.feet[l]
            p = (phase - self.offset[l]) % 1.0
            swing = p < (1.0 - DUTY)
            if swing:
                if not self.in_swing[l]:              # 방금 발을 떼는 순간
                    starts[l] = [f[0], f[1]]
                sx, h = swing_profile(p / (1.0 - DUTY))
                tx, ty = self._target(l, v_tgt, w_tgt, t_stance)
                x0, y0 = starts[l]
                # 높이: 떠난 곳(ground) → 새로 디딜 곳(평평한 기준 + 여유)으로 옮겨가면서, 그 위로 발 들기
                #   ★ 예전엔 떠난 곳 높이로 다시 내려놨음 → 구멍에서 한 번 내린 다리가 평지에서도 계속 그만큼 깊이 디딤
                z_from, z_to = self.ground[l], self.base_ground[l] + self.land_above(l)
                feet.append([x0 + (tx - x0) * sx, y0 + (ty - y0) * sx,
                             z_from + (z_to - z_from) * sx + h * self.lift * lift_scale])
            else:
                if self.in_swing[l]:                  # 방금 착지 → 목표 자리에 딱 놓기
                    x, y = self._target(l, v_tgt, w_tgt, t_stance)
                    z = self.base_ground[l] + self.land_above(l)   # 새 자리는 평평한 기준에서 시작 (접지 확인이 고침)
                else:
                    x, y = f[0], f[1]
                    z = f[2]                          # 바닥 발은 자기 높이 유지 (접지 확인으로 바뀐 높이 포함)
                xr, yr = c * x - s * y, s * x + c * y   # 바닥 발: 몸이 움직인 만큼 반대로 밀림
                feet.append([xr - v[0] * dt, yr - v[1] * dt, z])
            swing_now.append(swing)
        return feet, swing_now, starts

    def _budget(self, phase, dt, t_stance):
        """바닥 발이 기본 자리에서 보폭/2 넘게 밀려나지 않도록 이번 순간의 몸 속도 비율(0~1)을 정함.
        출발 직후 첫 걸음처럼 발이 기본 자리에서 시작할 때 자동으로 짧은 걸음이 됨."""
        R = self.stride / 2 + 1.0
        homes = self.home

        def ok(k):
            feet, swing, _ = self._build(phase, dt, [self.v[0] * k, self.v[1] * k], self.w * k, t_stance, 1.0)
            for l in range(NUM_LEGS):
                if swing[l]:
                    continue
                d_new = math.hypot(feet[l][0] - homes[l][0], feet[l][1] - homes[l][1])
                d_old = math.hypot(self.feet[l][0] - homes[l][0], self.feet[l][1] - homes[l][1])
                if d_new > R and d_new > d_old + 1e-9:   # 이미 밖이면 '더 멀어지는 것'만 막음
                    return False
            return True

        if ok(1.0):
            return 1.0
        lo, hi = 0.0, 1.0
        for _ in range(8):
            mid = (lo + hi) / 2
            if ok(mid):
                lo = mid
            else:
                hi = mid
        return lo

    def _step(self, dt, cycle, t_stance):
        """dt 만큼 진행한 자세를 계산. 안 닿으면 발 높이 → 몸 속도 순으로 줄여서 재시도."""
        b = self.body
        z = approach(b.pose[2], self.z_target, Z_RATE * dt)
        new_phase = self.phase + dt / cycle
        k = self._budget(new_phase, dt, t_stance)
        v_eff, w_eff = [self.v[0] * k, self.v[1] * k], self.w * k
        tries = [(v_eff, w_eff, ls, False) for ls in (1.0, 0.7, 0.5, 0.3)]
        tries.append(([0.0, 0.0], 0.0, 0.5, True))    # 마지막 수단: 몸 멈추고 발만
        for z_try in (z, b.pose[2]):
            pose = self._pose(z_try)
            for v, w, ls, stopped in tries:
                vt, wt = (v, w) if stopped else (self.v, self.w)   # 착지 목표는 부드러운 명령 속도로
                feet, swing_now, starts = self._build(new_phase, dt, v, w, t_stance, ls, vt, wt)
                joints = solve(b, pose, feet)
                if joints is not None:
                    return dict(phase=new_phase, feet=feet, swing=swing_now, starts=starts,
                                pose=pose, joints=joints, stopped=stopped, dist=math.hypot(*v) * dt)
        return None

    def tick(self, dt, cmd_fwd, cmd_side, cmd_turn, cycle):
        """한 번 계산하고 보냄. 막혔으면 False."""
        b = self.body
        t_stance = DUTY * cycle
        v_max = min(self.stride / t_stance, SPEED_MAX)        # SPEED_MAX가 최종 상한
        w_max = min(MAX_TURN_DEG / t_stance, TURN_SPEED_MAX)

        self.v[0] = approach(self.v[0], cmd_fwd * v_max, ACCEL * dt)
        self.v[1] = approach(self.v[1], cmd_side * v_max, ACCEL * dt)
        self.w = approach(self.w, cmd_turn * w_max, YAW_ACCEL * dt)

        want_move = bool(cmd_fwd or cmd_side or cmd_turn)
        if not self.walking:
            if want_move:
                if abs(b.pose[2] - self.z_checked) > 1.0:   # 서 있는 동안 높이를 바꿨으면 보폭 다시 계산
                    self._recheck()
                self.walking = True
                self.phase = 0.0                      # A조부터 발 듦
                self.in_swing = [False] * NUM_LEGS
            else:
                # 서 있는 동안: 높이와 몸통 기울기(수평 유지)를 발은 그대로 둔 채 바꿈
                z = approach(b.pose[2], self.z_target, Z_RATE * dt)
                ro = approach(b.pose[3], self.tilt_target[0], LEVEL_RATE * dt)
                pi = approach(b.pose[4], self.tilt_target[1], LEVEL_RATE * dt)
                if z == b.pose[2] and ro == b.pose[3] and pi == b.pose[4]:
                    return True
                pose = [0.0, 0.0, z, ro, pi, 0.0]
                joints = solve(b, pose, self.feet)
                if joints is None:
                    # 못 닿음 → 높이·기울기 둘 다 지금 자리에서 멈춤 (목표를 현재값으로 = 적분 누적 방지)
                    self.tilt_blocked = (ro, pi) != (b.pose[3], b.pose[4])
                    self.z_target = b.pose[2]
                    self.tilt_target = [b.pose[3], b.pose[4]]
                    return False
                self.tilt_blocked = False
                b.pose = pose
                self.last_joints = joints
                return self.sender.send(joints)

        # ── 계산 + 거버너 ──
        self._update_ref(self.in_swing)                # 다음 발판 예상 높이 = 지금 바닥에 있는 발들 높이
        res = self._step(dt, cycle, t_stance)
        scale = 1.0
        if res is not None:
            limit = JOINT_SPEED_MAX * dt
            r = max_delta(res["joints"], self.last_joints) / limit
            for _ in range(3):
                if r <= 1.0:
                    break
                trial_scale = scale / (r * 1.05)
                trial = self._step(dt * trial_scale, cycle, t_stance)
                if trial is None:
                    break
                r_new = max_delta(trial["joints"], self.last_joints) / limit
                if r_new > 0.9 * r:                   # 시간을 늦춰도 안 줄어드는 변화(착지 정렬 등) → 그냥 보냄
                    break
                res, scale, r = trial, trial_scale, r_new
        if res is None:
            self.v, self.w = [0.0, 0.0], 0.0
            self.z_target = b.pose[2]
            return False
        self.min_scale = min(self.min_scale, scale)
        self.dist += res["dist"]
        if res["stopped"]:
            self.v, self.w = [0.0, 0.0], 0.0

        # ── 확정 ──
        landed = [l for l in range(NUM_LEGS) if self.in_swing[l] and not res["swing"][l]]
        self.phase = res["phase"] % 1.0
        self.feet, self.in_swing, self.start = res["feet"], res["swing"], res["starts"]
        for l in landed:
            self.ground[l] = self.feet[l][2]          # 새로 디딘 곳 = 기준 높이 (접지 확인을 하면 거기서 다시 바뀜)
        if self.probe_on and landed:
            # 방금 착지한 다리 → main이 land_probe()로 접지 확인. 그동안은 tick이 안 불려서 몸이 멈춰 있고,
            # 끝나면 멈췄던 그 속도로 이어서 감
            self.pending_land.extend(landed)
        b.feet = [list(f) for f in self.feet]
        b.pose = res["pose"]
        self.last_joints = res["joints"]
        ok = self.sender.send(res["joints"])

        # 멈춤 조건: 명령 없음 + 속도 0 + 발이 전부 기본 자리 바닥에
        if not want_move and abs(self.v[0]) < 0.5 and abs(self.v[1]) < 0.5 and abs(self.w) < 0.5:
            if all(math.hypot(f[0] - h[0], f[1] - h[1]) < 2.0 and f[2] - g < 1.0
                   for f, h, g in zip(self.feet, self.home, self.ground)):
                self.walking = False
        return ok


class Leveler:
    """서 있을 때 몸통 수평 유지. IMU 기울기를 보고 gait.tilt_target(몸통 roll/pitch 목표)을 조금씩 바꾼다.

    IMU 각도(펌웨어 기준)와 몸통 명령 각도(hexapod_body 기준)는 부호·크기가 다를 수 있고,
    IMU 장착 방향 설정(펌웨어 AX_*)이 틀리면 roll과 pitch가 뒤바뀌거나 섞여서 나온다.
    그래서 calibrate()에서 "몸통 roll/pitch 명령 1°당 IMU roll/pitch 변화" 2×2 표를 직접 재고,
    그 표를 거꾸로 풀어서 보정한다 → 부호가 반대여도, 축이 뒤바뀌어도, 비스듬히 달려 있어도 맞음.
    """

    def __init__(self, link):
        self.link = link
        self.on = LEVEL_ENABLE
        self.ready = False          # 측정 성공했나
        # IMU 변화 = G × 몸통 명령 변화.  G = [[roll←roll, roll←pitch], [pitch←roll, pitch←pitch]] [도/도]
        # inv = G의 역행렬 (IMU 기울기 → 그걸 없애는 데 필요한 몸통 명령)
        self.inv = [[1.0, 0.0], [0.0, 1.0]]
        self.err = None             # 마지막 IMU 기울기 (roll, pitch)
        self.saturated = False      # LEVEL_MAX_DEG 한계에 걸려 다 못 맞추는 중
        self.stats_reset()

    def stats_reset(self):
        self.worst = 0.0            # 통계: 보정 중 최대 |기울기|
        self.stale = 0              # 통계: IMU 값이 오래돼서 보정을 건너뛴 횟수

    def reading(self):
        if not self.link.imu_fresh():
            return None
        m = self.link.imu
        return m["roll"], m["pitch"]

    def average(self, sec):
        """sec초 동안 IMU 평균. 새 값이 하나도 없으면 None."""
        rs, ps, last_t = [], [], None
        end = time.monotonic() + sec
        while time.monotonic() < end:
            m = self.link.imu
            if m is not None and m["t"] != last_t and self.link.imu_fresh():
                rs.append(m["roll"]); ps.append(m["pitch"]); last_t = m["t"]
            time.sleep(0.01)
        if len(rs) < 3:
            return None
        return sum(rs) / len(rs), sum(ps) / len(ps)

    def calibrate(self, gait):
        """몸통을 roll·pitch로 LEVEL_CAL_DEG씩 기울여서 IMU 반응을 잼. 성공하면 ready=True.
        로봇이 서 있고 움직이지 않을 때만 부를 것 (약 3초)."""
        self.ready = False
        if self.link.imu_err:
            print("[수평] 로봇 IMU 오류 — 수평 유지 끔")
            return False
        print("[수평] 부호·배율 측정 중 (약 3초, 로봇 건드리지 말 것)…")
        base = self.average(0.4)
        if base is None:
            print("[수평] IMU 값이 안 옴 — 펌웨어 v2인지, 'i' 스트림이 켜졌는지 확인. 수평 유지 끔")
            return False
        if max(abs(base[0]), abs(base[1])) > LEVEL_BASE_MAX_DEG:
            print(f"[수평] 지금 IMU가 roll {base[0]:+.1f}° pitch {base[1]:+.1f}°로 읽힘 — 수평 기준이 안 잡혀 있음.\n"
                  "       평평한 바닥에 세우고 --zero 옵션으로 실행하거나, 펌웨어 AX_* 장착 방향을 맞출 것. 수평 유지 끔")
            return False
        gains = []
        for axis in (0, 1):
            tgt = [gait.tilt_target[0], gait.tilt_target[1]]
            tgt[axis] += LEVEL_CAL_DEG
            back = [gait.tilt_target[0], gait.tilt_target[1]]
            if not gait.move_tilt(tgt[0], tgt[1], 0.5):
                return False
            time.sleep(0.4)                     # 서보가 따라오고 IMU 값이 블루투스로 도착할 시간
            m = self.average(0.4)
            if not gait.move_tilt(back[0], back[1], 0.5):
                return False
            time.sleep(0.3)
            if m is None:
                print("[수평] 측정 중 IMU 값이 끊김 — 수평 유지 끔")
                return False
            gains.append(((m[0] - base[0]) / LEVEL_CAL_DEG, (m[1] - base[1]) / LEVEL_CAL_DEG))

        (rr, rp), (pr, pp) = gains              # rr: roll 명령→IMU roll, rp: roll 명령→IMU pitch ...
        print(f"[수평] 몸통 roll  {LEVEL_CAL_DEG:+.1f}° 명령 → IMU roll {rr*LEVEL_CAL_DEG:+.2f}°, pitch {rp*LEVEL_CAL_DEG:+.2f}°")
        print(f"[수평] 몸통 pitch {LEVEL_CAL_DEG:+.1f}° 명령 → IMU roll {pr*LEVEL_CAL_DEG:+.2f}°, pitch {pp*LEVEL_CAL_DEG:+.2f}°")
        # G = [[rr, pr], [rp, pp]]  (행: IMU roll/pitch, 열: 몸통 roll/pitch 명령)
        resp_r = math.hypot(rr, rp)             # 몸통 roll 명령에 IMU가 반응한 크기
        resp_p = math.hypot(pr, pp)
        if max(resp_r, resp_p) < LEVEL_CAL_MIN_GAIN:
            print(f"[수평] 몸통을 기울여도 IMU가 거의 안 변함 (명령 1°당 {max(resp_r, resp_p):.2f}° < {LEVEL_CAL_MIN_GAIN}) "
                  "— IMU가 몸통에 단단히 고정됐는지 확인. 수평 유지 끔")
            return False
        if min(resp_r, resp_p) < LEVEL_CAL_MIN_GAIN:
            print(f"[수평] 한 방향만 반응이 약함 (roll 명령 {resp_r:.2f}, pitch 명령 {resp_p:.2f} < {LEVEL_CAL_MIN_GAIN}) "
                  "— 그 방향 서보 처짐·발 미끄러짐 확인. 수평 유지 끔")
            return False
        det = rr * pp - pr * rp
        # 두 반응이 거의 같은 방향이면(구분 불가) 역행렬이 폭주함. |det| / (크기1×크기2) = 두 방향 사이각의 sin
        if abs(det) < LEVEL_CAL_MIN_SIN * resp_r * resp_p:
            print("[수평] roll 명령과 pitch 명령에 IMU가 같은 방향으로 반응함 (구분 불가) — IMU 장착 상태 확인. 수평 유지 끔")
            return False
        self.inv = [[pp / det, -pr / det], [-rp / det, rr / det]]
        self.ready = True
        if abs(rp) > abs(rr) and abs(pr) > abs(pp):
            note = "IMU의 roll·pitch가 서로 뒤바뀌어 있음 → 자동으로 맞춤 (펌웨어 AX_* 고치면 로그가 읽기 쉬워짐)"
        elif abs(rp) > LEVEL_CAL_MAX_CROSS * abs(rr) or abs(pr) > LEVEL_CAL_MAX_CROSS * abs(pp):
            note = "IMU가 비스듬히 달려 있음(roll·pitch 섞임) → 자동으로 맞춤"
        else:
            note = "축 정상"
        print(f"[수평] 측정 완료 — 배율 roll {resp_r:.2f}, pitch {resp_p:.2f} "
              f"(1.0보다 작은 만큼 서보 처짐·발 미끄러짐으로 덜 기운 것). {note}")
        return True

    def update(self, dt, gait, active):
        """매 루프 호출. active = 서 있고 움직임 명령이 없을 때만 True."""
        if not (self.on and self.ready):
            gait.tilt_target = [0.0, 0.0]       # 꺼져 있으면 몸통을 원래 각도로
            return
        if not active:
            return                              # 걷는 중 등 → 지금 기울기 유지
        r = self.reading()
        if r is None:
            self.stale += 1                     # 값이 오래됨 → 보정 멈춤 (옛 값으로 계속 밀면 폭주)
            return
        self.err = r
        self.worst = max(self.worst, abs(r[0]), abs(r[1]))
        self.saturated = False
        # 허용 범위 안인 축은 0으로 (그 축은 안 건드림)
        e = [x if abs(x) > LEVEL_DEADBAND else 0.0 for x in r]
        if e[0] == 0.0 and e[1] == 0.0:
            return
        t = gait.tilt_target
        for i in (0, 1):
            # IMU 기울기 e를 없애는 데 필요한 몸통 명령 = -inv × e. 그걸 GAIN 속도로 조금씩
            need = self.inv[i][0] * e[0] + self.inv[i][1] * e[1]
            want = t[i] - LEVEL_GAIN * dt * need
            t[i] = max(-LEVEL_MAX_DEG, min(LEVEL_MAX_DEG, want))
            if t[i] != want:
                self.saturated = True           # LEVEL_MAX_DEG에 걸려서 더는 못 맞춤


class Grounder:
    """모든 발을 땅에 닿게 함. 서 있고 멈춰 있을 때만 쓸 것 (한 번에 수 초~수십 초 걸림).

    원리: 다리 하나를 일정한 속도로 쭉 내림.
      - 발이 공중이면 → 몸통 기울기가 안 변함(잡음뿐) → 계속 내림
      - 발이 닿아서 몸을 밀기 시작하면 → 몸통 기울기가 변하기 시작 → 바로 멈춤
      - '언제부터 변하기 시작했나'를 거꾸로 계산하고, 그때 보낸 깊이(지연만큼 앞)를 접촉 깊이로 봄
      - 접촉 깊이가 거의 0이면 원래부터 닿아 있던 다리 → 원래 높이로 되돌림
        (닿아 있는 다리는 내리자마자 반응하고, 공중 다리는 닿기 전까지 전혀 반응 안 함. 이 차이로 구분)
    다리를 들지는 않으므로 지지 다리가 줄어들 일은 없음.
    """

    def __init__(self, gait, leveler):
        self.gait, self.lev = gait, leveler
        self.last_cmd = 0.0                          # 마지막으로 발 명령을 보낸 시각

    def _set_foot(self, l, z):
        """다리 l의 발 높이만 z로 바꿔서 보냄 (나머지 발·몸통은 그대로). 못 닿으면 False."""
        g, b = self.gait, self.gait.body
        feet = [list(f) for f in g.feet]
        feet[l][2] = z
        joints = solve(b, b.pose, feet)
        if joints is None:
            return False
        if not g.sender.send(joints):
            raise ConnectionError("전송 실패")
        self.last_cmd = time.monotonic()
        g.feet, g.last_joints = feet, joints
        b.feet = [list(f) for f in feet]
        return True

    def _tilt(self):
        """기준 기울기: 최근 받은 샘플 5개 평균. 안 되면(막 연결돼서 샘플이 모자람) 0.1초 기다려 평균."""
        t = self.lev.link.imu_recent(5)
        return t if t is not None else self.lev.average(0.1)

    def wait_still(self, max_sec=GROUND_SETTLE_MAX, after_cmd=True):
        """방금 보낸 명령의 효과가 IMU에 보이고(지연) + 흔들림이 가라앉을 때까지만 기다림.
        예전엔 무조건 0.15초씩 기다렸음. 가라앉으면 True, max_sec 넘으면 False.
        ★ 마지막 명령 후 '지연 × 1.3 + 20ms'가 지나기 전엔 판정하지 않음: 그 전엔 명령 효과가 아직 IMU에 안 왔는데
          '가만히 있다'로 착각할 수 있음 (실제로 시뮬레이션에서 앞 다리를 되돌린 움직임이 다음 다리 기준을 틀어놨음).
        after_cmd=True면 지금 막 (Grounder 밖에서) 명령을 보냈다고 보고 지금부터 셈."""
        link = self.lev.link
        start = time.monotonic() if after_cmd else self.last_cmd
        t_ready = start + GROUND_LATENCY * 1.3 + 0.02
        while time.monotonic() < t_ready:
            time.sleep(0.002)
        t_end = time.monotonic() + max_sec
        while time.monotonic() < t_end:
            pts = link.imu_window(GROUND_STILL_WIN)
            if len(pts) >= 6:
                h = len(pts) // 2
                a, b = pts[:h], pts[h:]
                dr = sum(p[1] for p in b) / len(b) - sum(p[1] for p in a) / len(a)
                dp = sum(p[2] for p in b) / len(b) - sum(p[2] for p in a) / len(a)
                if abs(dr) < GROUND_STILL_TOL and abs(dp) < GROUND_STILL_TOL:
                    return True
            time.sleep(0.005)
        return False

    @staticmethod
    def _depth_plan(expect, fast=None, slow=None):
        """시작 후 경과 시간 → 내릴 깊이. 예상 바닥(expect mm 아래) 근처만 천천히, 나머지는 빠르게.
          [0, expect−GROUND_SLOW_BEFORE)            : 빠르게 (공중일 게 확실한 구간)
          [expect−SLOW_BEFORE, expect+GROUND_NEAR_MM): 천천히 (여기서 닿을 가능성이 큼 → 세게 안 누르게)
          그 아래                                     : 빠르게 (구멍)"""
        fast = fast or GROUND_SPEED
        slow = slow or GROUND_SPEED_NEAR
        a = max(0.0, expect - GROUND_SLOW_BEFORE)
        b = expect + GROUND_NEAR_MM - a
        segs = [(a, fast), (b, slow), (float("inf"), fast)]

        def depth_at_time(el):
            d = 0.0
            for length, speed in segs:
                t_seg = length / speed
                if el <= t_seg:
                    return d + speed * el
                d += length
                el -= t_seg
            return d
        return depth_at_time

    def probe(self, l, start_tilt, expect=0.0, fast=None, slow=None, plan=None, max_down=None):
        """다리 l 하나를 쭉 내려서 바닥을 찾음.
        expect: 지금 발 위치에서 예상 바닥까지 거리 [mm]. 0 = 지금 바닥에 있다고 봄(서서 접지),
                LAND_APPROACH = 걷다가 바닥 몇 mm 위에서 멈춘 발.
        결과 dict status: 'already'(시작할 때 이미 닿아 있음) / 'contact'(내려서 닿음) / 'none'(바닥 없음) /
                          'reach'(관절 한계) / 'abort'"""
        link = self.lev.link
        z0 = self.gait.feet[l][2]
        self.wait_still(max_sec=0.15, after_cmd=False)          # 앞 다리 움직임의 흔들림이 남아 있으면 기준이 틀어짐
        base = self._tilt()
        if base is None:
            return dict(status="abort", why="IMU 값 없음")
        over = 0                                     # 임계값을 연속으로 넘은 샘플 수
        win = deque(maxlen=GROUND_SMOOTH)            # 최근 샘플 몇 개 평균 (잡음 줄이기)
        last_imu_t = time.monotonic()                # 이 시각 이후에 받은 샘플만 씀
        cmds = [(time.monotonic(), 0.0)]             # (보낸 시각, 깊이 mm)
        obs = []                                     # (IMU 받은 시각, 기준 대비 기울기 변화 벡터)
        depth = 0.0
        t0 = time.monotonic()
        period = 1.0 / GROUND_LOOP_HZ
        detected = None
        plan = plan or self._depth_plan(expect, fast, slow)      # plan: 경과 시간 → 내릴 깊이 (계단 모드가 따로 줌)
        if max_down is None:
            max_down = expect + GROUND_MAX_DOWN                   # 예상 바닥보다 GROUND_MAX_DOWN 아래까지
        while True:
            now = time.monotonic()
            want = min(plan(now - t0), max_down)
            if want > depth:
                if not self._set_foot(l, z0 - want):
                    self.wait_still(after_cmd=False)
                    return dict(status="reach", depth=depth)       # 다리가 더 못 뻗음 → 거기서 멈춤
                depth = want
                cmds.append((now, depth))
            if not link.imu_fresh():
                self._set_foot(l, z0)
                return dict(status="abort", why="IMU 값 끊김")
            # 지난번 이후 들어온 IMU 샘플을 '전부' 처리 (최신 값 하나만 보면 200Hz 중 절반을 버리게 됨)
            for ts_, ro_, pi_ in link.imu_window(0.25):
                if last_imu_t is not None and ts_ <= last_imu_t:
                    continue
                last_imu_t = ts_
                win.append((ro_, pi_))
                if len(win) < GROUND_SMOOTH:
                    continue
                t = (sum(w[0] for w in win) / len(win), sum(w[1] for w in win) / len(win))
                if math.hypot(t[0] - start_tilt[0], t[1] - start_tilt[1]) > GROUND_ABORT_DEG:
                    self._set_foot(l, z0)
                    return dict(status="abort", why=f"시작보다 {GROUND_ABORT_DEG}° 넘게 기울어짐")
                v = (t[0] - base[0], t[1] - base[1])
                obs.append((ts_, v))
                over = over + 1 if math.hypot(*v) >= GROUND_THRESH_DEG else 0
                if over >= 2:                        # 2번 연속 넘어야 '닿음' (잡음 한 번으로는 안 걸림)
                    detected = depth
                    break
            if detected is not None:
                break
            if depth >= max_down and now - cmds[-1][0] > GROUND_LATENCY + 0.05:
                break                                              # 끝까지 내렸고 지연만큼 더 지켜봤는데도 없음
            time.sleep(period)

        if detected is None:                                       # 끝까지 내려도 안 닿음 → 원래대로
            self._set_foot(l, z0)
            self.wait_still(after_cmd=False)
            return dict(status="none", depth=0.0)

        # 접촉 깊이 거꾸로 계산 (꺾인 직선 맞추기)
        #   1) IMU 값마다 '그 값을 만든 발 깊이'를 짝지음: 받은 시각 − 지연 − 평균 지연 때 보낸 깊이
        #   2) "깊이 k까지는 평평(0), k부터는 직선으로 올라감" 모양을 k를 0.1mm씩 바꿔가며 대보고
        #      실제 값과 제일 잘 맞는 k = 접촉 깊이. 측정값을 전부 쓰니까 잡음 몇 개에 안 흔들림.
        #      이미 닿아 있던 다리 → 처음부터 올라감 → k ≈ 0 / 공중 다리 → 평평하다 꺾임 → k ≈ 꺾인 깊이
        t_det, v_det = obs[-1]
        d_det = math.hypot(*v_det)
        u = (v_det[0] / d_det, v_det[1] / d_det)                   # 변화 방향으로 투영 (잡음 영향 ↓)
        ts = [p[0] for p in list(link.imu_hist)[-11:]]
        dts = sorted(b_ - a_ for a_, b_ in zip(ts, ts[1:]))
        dt_s = dts[len(dts) // 2] if dts else 0.005
        lag = GROUND_LATENCY + (GROUND_SMOOTH - 1) / 2 * dt_s      # 샘플 n개 평균은 가운데 시각을 대표

        def depth_at(t):                                           # 시각 t에 발이 있던 깊이 (명령 사이는 직선)
            if t <= cmds[0][0]:
                return 0.0
            for (ta, da), (tb, db) in zip(cmds, cmds[1:]):
                if ta <= t < tb:
                    return da + (db - da) * (t - ta) / max(tb - ta, 1e-9)
            return cmds[-1][1]

        pts = [(depth_at(t - lag), v[0] * u[0] + v[1] * u[1]) for t, v in obs]
        # 모양: p = c + s × max(0, 깊이 − k)
        #   c = 평평한 구간의 높이 (기준값 잡음 때문에 정확히 0이 아님 → 이걸 빼먹으면 k=0 쪽으로 쏠림)
        #   s = 닿은 뒤 기울기 변화 속도, k = 접촉 깊이
        # ★ 모든 k를 '같은 측정값 전체'로 비교함 (k마다 다른 부분만 쓰면 평평한 잡음 구간만 본 k가 이겨버림)
        n = len(pts)
        sp = sum(p for _, p in pts)
        spp = sum(p * p for _, p in pts)
        best_k, best_err = 0.0, float("inf")
        k = 0.0
        while k <= detected + 1e-9 and n >= 4:
            sx = sxx = sxp = 0.0
            for dpt, p in pts:
                x = dpt - k
                if x > 0:
                    sx += x
                    sxx += x * x
                    sxp += x * p
            det = n * sxx - sx * sx
            if det > 1e-9:
                s = (n * sxp - sx * sp) / det
                c = (sp - s * sx) / n
                if s > 0:
                    err = spp - c * sp - s * sxp                   # 최소제곱 해에서의 오차 제곱합
                    if err < best_err:
                        best_k, best_err = k, err
            k += 0.1
        contact = best_k
        self.last_fit = dict(pts=pts, contact=contact, detected=detected)   # 진단용
        if contact < GROUND_GAP_MIN_MM:                            # 처음부터 닿아 있던 다리 → 원래 높이로
            self._set_foot(l, z0)
            self.wait_still(after_cmd=False)
            return dict(status="already", depth=0.0, d=d_det, est=contact, pressed=detected)
        final = min(detected, contact + GROUND_PRELOAD_MM)
        self._set_foot(l, z0 - final)
        self.wait_still(after_cmd=False)
        return dict(status="contact", depth=final, d=d_det, pressed=detected)

    def run(self, quiet=False):
        """모든 다리 접지. 성공(구멍 없이 전부 닿음)이면 True.
        결과: self.moved_total (이번에 내린 다리 수), self.holes (바닥 못 찾은 다리 목록)"""
        g = self.gait
        self.moved_total, self.holes = 0, []
        if g.walking:
            print("[접지] 멈춘 다음 할 것")
            return False
        start_tilt = self._tilt()
        if start_tilt is None:
            print("[접지] IMU 값이 안 옴 — 펌웨어 v2·IMU 연결 확인")
            return False
        z_start = [f[2] for f in g.feet]
        t0 = time.monotonic()
        if not quiet:
            print(f"[접지] 시작 (다리마다 최대 {GROUND_MAX_DOWN:.0f}mm, {GROUND_SPEED:.0f}mm/s로 내림, "
                  f"감지 {GROUND_THRESH_DEG}°, 지연 {GROUND_LATENCY * 1000:.0f}ms)")
        done = False
        for p in range(1, GROUND_PASSES + 1):
            moved = 0
            row = []
            for l in GROUND_ORDER:
                if l in self.holes:                    # 이번 접지에서 이미 바닥 없음으로 나온 다리는 다시 안 찾음
                    continue
                r = self.probe(l, start_tilt)
                s = r["status"]
                if s == "abort":
                    print(f"[접지] 다리{l}에서 중단 — {r['why']}")
                    return False
                if s == "contact":
                    moved += 1
                    row.append(f"다리{l} {r['depth']:.1f}mm 내려서 닿음({r['d']:.2f}°)")
                elif s == "already":
                    row.append(f"다리{l} 닿아 있음(틈 {r['est']:.1f}mm)")
                elif s == "none":
                    row.append(f"다리{l} {GROUND_MAX_DOWN:.0f}mm까지 바닥 없음")
                    if l not in self.holes:
                        self.holes.append(l)
                else:
                    row.append(f"다리{l} {r['depth']:.1f}mm에서 관절 한계")
                    if l not in self.holes:
                        self.holes.append(l)
            if not quiet or moved:
                print(f"[접지] {p}바퀴: " + ", ".join(row))
            self.moved_total += moved
            if moved == 0:
                done = True
                break
        g.ground = [f[2] for f in g.feet]          # 지금 디딘 자리의 바닥 높이 (발을 떼면 base_ground로 돌아감)
        if self.moved_total:
            g._recheck()                           # 높이가 바뀌었으니 보폭·발 높이 다시 계산
        change = ", ".join(f"{l}:{g.feet[l][2] - z_start[l]:+.1f}" for l in range(NUM_LEGS))
        if not quiet or self.moved_total:
            print(f"[접지] {'완료' if done else f'{GROUND_PASSES}바퀴 안에 다 안 끝남'} "
                  f"({time.monotonic() - t0:.1f}초) — 다리별 높이 변화 mm  {change}")
        return done and not self.holes

    def _mm_per_tick(self, l):
        """지금 자세에서 다리 l의 서보 1칸이 발 높이 몇 mm인지 (제일 많이 움직이는 관절 기준)."""
        g, b = self.gait, self.gait.body
        j0 = solve(b, b.pose, g.feet)
        feet = [list(f) for f in g.feet]
        feet[l][2] -= 1.0
        j1 = solve(b, b.pose, feet)
        if j0 is None or j1 is None:
            return 0.8
        ticks = max(abs(j1[l][k] - j0[l][k]) for k in range(NUM_JOINTS)) / SERVO_TICK_DEG
        return 1.0 / ticks if ticks > 1e-6 else 0.8

    def _static_tilt(self):
        """마지막 명령의 효과가 다 나타나고 흔들림이 가라앉은 뒤, CHECK_AVG초 평균 기울기. 지연과 상관없음."""
        self.wait_still(after_cmd=False)
        time.sleep(CHECK_AVG)
        pts = self.lev.link.imu_window(CHECK_AVG)
        if len(pts) < 4 or not self.lev.link.imu_fresh():
            return None
        return sum(p[1] for p in pts) / len(pts), sum(p[2] for p in pts) / len(pts)

    def check_leg(self, l, start):
        """다리 l 하나가 정말 무게를 받치나 정지 비교로 확인, 아니면 받칠 때까지 CHECK_TICKS칸씩 내림.
        start: 비교 시작 기울기(넘어짐 판단용). 결과 (상태, 들었을 때 변화°, 내린 mm, 내린 뒤 변화°)
        상태: 'ok' 받침 / 'lowered' 내려서 받침 / 'none' GROUND_MAX_DOWN까지 바닥 없음 / 'abort' IMU 끊김·크게 기울어짐"""
        g = self.gait
        z0 = g.feet[l][2]
        step = CHECK_TICKS * self._mm_per_tick(l)
        base = self._static_tilt()
        if base is None:
            return "abort", float("nan"), 0.0, 0.0
        if self._set_foot(l, z0 + step):                      # 살짝 들어보기
            up = self._static_tilt()
            self._set_foot(l, z0)
            if up is None:
                return "abort", float("nan"), 0.0, 0.0
            d_up = math.hypot(up[0] - base[0], up[1] - base[1])
            if d_up >= CHECK_LOAD_DEG:
                return "ok", d_up, 0.0, 0.0
        else:
            d_up = float("nan")                                # 못 듦(관절 한계) → 바로 내려보기
        depth, d = 0.0, 0.0
        while depth + step <= GROUND_MAX_DOWN + 1e-9:
            depth += step
            if not self._set_foot(l, z0 - depth):
                break                                          # 관절 한계
            v = self._static_tilt()
            if v is None:
                self._set_foot(l, z0)
                return "abort", d_up, 0.0, 0.0
            if math.hypot(v[0] - start[0], v[1] - start[1]) > GROUND_ABORT_DEG:
                self._set_foot(l, z0)
                print(f"[확인] 다리{l}에서 중단 — 시작보다 {GROUND_ABORT_DEG}° 넘게 기울어짐")
                return "abort", d_up, 0.0, 0.0
            d = math.hypot(v[0] - base[0], v[1] - base[1])
            if d >= CHECK_LOAD_DEG:
                return "lowered", d_up, depth, d
        self._set_foot(l, z0)
        return "none", d_up, depth, d

    def check_loads(self):
        """다리마다 '정말 무게를 받치고 있나' 정지 비교로 확인하고, 아니면 받칠 때까지 내림.
        내린 다리 수를 돌려줌 (IMU 끊김·크게 기울어짐이면 None). 결과 줄은 self.check_row."""
        g = self.gait
        start = self._tilt()
        if start is None:
            return None
        lowered, row = 0, []
        for l in GROUND_ORDER:
            if l in self.holes:
                continue
            st, d_up, depth, d = self.check_leg(l, start)
            if st == "abort":
                return None
            if st == "ok":
                row.append(f"{l}:받침({d_up:.2f}°)")
            elif st == "none":
                self.holes.append(l)
                row.append(f"{l}:안 받침({d_up:.2f}°)→{depth:.0f}mm까지 바닥 없음")
            else:
                lowered += 1
                row.append(f"{l}:안 받침({d_up:.2f}°)→{depth:.1f}mm 내려서 받침({d:.2f}°)")
        if lowered:
            g.ground = [f[2] for f in g.feet]
            g._recheck()
        self.check_row = row
        return lowered


def ground_and_level(gait, grounder, leveler, verbose=True):
    """발 6개 접지 + 몸통 수평.
      1) 빠른 접지: 다리를 하나씩 쭉 내려서 기울기가 변하는 순간 멈춤
      2) 수평: 발 6개 위치는 그대로 두고 몸통만 돌림
      3) 하중 확인(CHECK_ENABLE): 다리마다 살짝 들어봐서 정말 받치고 있나 정지 비교로 확인, 아니면 받칠 때까지 내림
         내린 다리가 있으면 (기울기가 허용 범위를 넘었을 때만) 수평 → 다시 확인. 맨 마지막은 항상 확인.
    ★ 3)에서 다리를 내렸다면: 1)이 '닿음'이라고 했는데 실제로는 덜 닿았거나(지연 추정·서보 칸 단위),
      2)에서 몸통을 돌리다 떴다는 뜻(IK 치수가 실제와 다름). 몸통을 거의 안 돌렸는데도 내렸다면 1) 쪽 문제.
    발이 다 받치면(구멍 없이) True."""
    t0 = time.monotonic()
    grounder.run(quiet=not verbose)
    if grounder.holes:
        print(f"[접지+수평] 다리 {grounder.holes} 아래 바닥 없음 — 그 다리는 빼고 진행")
    leveled = leveler.on and leveler.ready
    if leveled:
        level_now(gait, leveler, timeout=4.0, quiet=True)
    elif verbose:
        print("[접지+수평] 수평 측정이 안 돼 있어서 접지만 함")
    tilt_moved = math.hypot(gait.body.pose[3], gait.body.pose[4])
    lowered_total, rounds_left = 0, False
    if CHECK_ENABLE:
        for k in range(CHECK_ROUNDS):
            n = grounder.check_loads()
            if n is None:
                print("[확인] 중단 (IMU 값이 끊기거나 크게 기울어짐) — 발이 다 받치는지 눈으로 확인할 것")
                break
            if verbose or n:
                print(f"[확인] {k + 1}바퀴 (들었을 때 기울기 변화): " + ", ".join(grounder.check_row))
            lowered_total += n
            if n == 0:
                break
            if k == CHECK_ROUNDS - 1:
                rounds_left = True                      # 마지막 바퀴에서도 내렸음 → 발은 받치지만 수평은 덜 맞을 수 있음
            elif leveled:
                level_now(gait, leveler, timeout=2.0, quiet=True)   # 허용 범위 안이면 바로 끝남
    e = leveler.reading() or leveler.err or (float("nan"), float("nan"))
    if lowered_total:
        print(f"[접지+수평] ★ 빠른 접지 뒤에도 덜 받치던 다리를 {lowered_total}번 더 내렸음 "
              f"(그 사이 몸통 수평 보정 {tilt_moved:.1f}°).\n"
              "       몸통을 많이 돌렸다면 IK 치수(다리 길이·서기 자세 발끝 위치)가 실제와 다를 가능성,\n"
              "       거의 안 돌렸다면 [지연] 값이나 서보 칸 단위 움직임 때문에 빠른 접지가 덜 누른 것.")
    if rounds_left:
        print(f"[접지+수평] {CHECK_ROUNDS}바퀴 안에 안정되지 않음 — 발은 다 받치게 하고 끝냄 (수평은 덜 맞을 수 있음)")
    print(f"[접지+수평] 완료 ({time.monotonic() - t0:.1f}초) — 기울기 roll {e[0]:+.2f}° pitch {e[1]:+.2f}°, "
          f"몸통 보정 {gait.body.pose[3]:+.1f}° / {gait.body.pose[4]:+.1f}°")
    return not grounder.holes


def measure_latency(gait, link, n=5, step_deg=1.5, thresh_deg=0.15):
    """'명령을 보낸 순간 → 그 움직임이 PC에 도착한 IMU 값에 보이는 순간'까지 걸리는 시간을 직접 잼.
    방법: 발은 그대로 두고 몸통을 step_deg만큼 한 번에 기울이는 명령을 보내고, IMU가 thresh_deg 변하는 시각을 봄.
    n번 재서 중앙값을 GROUND_LATENCY로 씀 (접지에서 접촉 시점을 거꾸로 계산할 때 필요). 성공하면 지연[초]."""
    global GROUND_LATENCY
    b = gait.body
    lats = []
    for _ in range(n):
        time.sleep(0.25)
        base = link.imu_recent(8)
        if base is None:
            break
        p0 = list(b.pose)
        p1 = list(p0)
        p1[4] += step_deg                                   # pitch 방향으로 한 번에
        joints = solve(b, p1, gait.feet)
        if joints is None:
            break
        t_cmd = time.monotonic()
        if not gait.sender.send(joints):
            raise ConnectionError("전송 실패")
        b.pose = p1
        while time.monotonic() - t_cmd < 0.5:
            m = link.imu
            if m is not None and m["t"] > t_cmd:
                r = link.imu_recent(2)
                if r and math.hypot(r[0] - base[0], r[1] - base[1]) >= thresh_deg:
                    lats.append(m["t"] - t_cmd)
                    break
            time.sleep(0.002)
        back = solve(b, p0, gait.feet)                      # 원래 자세로
        if back is None or not gait.sender.send(back):
            raise ConnectionError("전송 실패")
        b.pose, gait.last_joints = p0, back
    if len(lats) < 3:
        print(f"[지연] 측정 실패 ({len(lats)}/{n}번만 잡힘) — 기본값 {GROUND_LATENCY * 1000:.0f}ms 그대로 씀")
        return None
    lats.sort()
    med = lats[len(lats) // 2]
    GROUND_LATENCY = max(0.01, min(0.3, med))
    print(f"[지연] 명령 → IMU 반응: 중앙값 {med * 1000:.0f}ms (최소 {lats[0] * 1000:.0f}, 최대 {lats[-1] * 1000:.0f}, "
          f"{len(lats)}번) → 접지에 {GROUND_LATENCY * 1000:.0f}ms 사용")
    return med


def set_zero(link, grounder=None):
    """로봇에 '지금 자세 = 수평'을 기억시킴. 펌웨어가 #zero,<roll>,<pitch> 로 답함.
    grounder를 주면 먼저 접지를 해보고, 바닥에 안 닿는 다리가 있으면(들고 있거나 바닥이 고르지 않으면) 거부."""
    time.sleep(0.5)                                    # 일어선 직후 흔들림 가라앉히기
    if grounder is not None:
        print("[수평] 수평 기준 잡기 전에 발 6개가 다 닿았는지 확인…")
        grounder.run()
        if grounder.holes:
            print(f"[수평] 다리 {grounder.holes}가 바닥에 안 닿음 — 로봇을 들고 있거나 바닥이 평평하지 않음.\n"
                  "       수평 기준을 안 바꿈. 평평한 바닥에 내려놓고 다시 할 것")
            return False
    link.imu_zero()
    t0 = time.monotonic()
    while time.monotonic() - t0 < 1.0:
        for msg in list(link.log_queue):
            if msg.startswith("#zero,"):
                _, r, p = msg.split(",")
                print(f"[수평] 수평 기준 저장 (보정값 roll {r}°, pitch {p}°)\n"
                      f"       재부팅해도 유지하려면 펌웨어에 ROLL_OFS = {r}f; PITCH_OFS = {p}f; 로 적을 것")
                return True
        time.sleep(0.05)
    print("[수평] 수평 기준 응답 없음 — 펌웨어 v2·IMU 확인")
    return False


def level_now(gait, leveler, timeout=4.0, quiet=False):
    """지금 바로 수평을 맞춤 (메인 루프 밖에서 쓸 때). 허용 범위 안에 0.5초 머물면 끝."""
    if not (leveler.on and leveler.ready):
        return False
    dt, t0, inside = 1.0 / LOOP_HZ, time.monotonic(), 0.0
    while time.monotonic() - t0 < timeout:
        leveler.update(dt, gait, True)
        gait.tick(dt, 0.0, 0.0, 0.0, CYCLE_SLOW)
        e = leveler.err
        inside = inside + dt if e and max(abs(e[0]), abs(e[1])) <= LEVEL_DEADBAND else 0.0
        if inside >= 0.5:
            if not quiet:
                print(f"[수평] 맞춤 — roll {e[0]:+.2f}° pitch {e[1]:+.2f}° ({time.monotonic() - t0:.1f}초)")
            return True
        time.sleep(dt)
    e = leveler.err or (float("nan"), float("nan"))
    print(f"[수평] {timeout:.0f}초 안에 다 못 맞춤 — roll {e[0]:+.2f}° pitch {e[1]:+.2f}°")
    return False


class Joystick:
    """우노에서 <x,y,버튼,볼륨> 을 계속 읽는 스레드."""

    def __init__(self, port):
        self.ser = serial.Serial(port, 115200, timeout=0.1)
        time.sleep(2)                       # 우노는 포트 열면 리셋됨
        self.x = self.y = self.pot = 512
        self.mask = 0
        self.pressed = 0                    # 새로 눌린 버튼 (읽으면 지워짐)
        self.last = 0.0
        self.lock = threading.Lock()
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        buf = b""
        while True:
            try:
                buf += self.ser.read(128)
            except serial.SerialException as e:
                print("[우노] 끊김:", e)
                time.sleep(1)
                continue
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not (line.startswith(b"<") and line.endswith(b">")):
                    if line:
                        print("[우노]", line.decode(errors="replace"))
                    continue
                try:
                    x, y, m, p = (int(v) for v in line[1:-1].split(b","))
                except ValueError:
                    continue
                with self.lock:
                    self.pressed |= m & ~self.mask
                    self.x, self.y, self.mask, self.pot = x, y, m, p
                    self.last = time.monotonic()

    def alive(self):
        return time.monotonic() - self.last < UNO_TIMEOUT

    def take_pressed(self):
        with self.lock:
            p, self.pressed = self.pressed, 0
        return p

    def held(self, bit):
        return bool(self.mask & (1 << bit))

    def axes(self):
        """(앞뒤, 좌우) -1~1, 가운데 무시 구간 적용."""
        def ax(v, sign):
            a = (v - 512) / 512.0 * sign
            if abs(a) < DEADZONE:
                return 0.0
            return max(-1.0, min(1.0, (a - math.copysign(DEADZONE, a)) / (1 - DEADZONE)))
        return ax(self.y, STICK_FWD_SIGN), ax(self.x, STICK_SIDE_SIGN)

    def speed01(self):
        return self.pot / 1023.0


def play_joints(sender, target, sec):
    """18개 관절을 지금 각도에서 target 으로 부드럽게 (관절 공간, 발 위치 계산 없음)."""
    start = [row[:] for row in sender.hx.cmd]
    n = max(1, round(sec * LOOP_HZ))
    for k in range(1, n + 1):
        e = 0.5 - 0.5 * math.cos(math.pi * k / n)
        pose = [[start[l][j] + (target[l][j] - start[l][j]) * e for j in range(NUM_JOINTS)]
                for l in range(NUM_LEGS)]
        if not sender.send(pose):
            return False
        time.sleep(1.0 / LOOP_HZ)
    return True


def fold(body, sender):
    """서기 → 접기: 몸을 수평으로 하며 내려서 바닥에 앉힌 다음, 다리를 접는다. 실패하면 None."""
    print("[접기] 몸 내리는 중…")
    start = list(body.pose)
    end = [0.0, 0.0, SIT_Z, 0.0, 0.0, 0.0]
    n = max(1, math.ceil(abs(SIT_Z - start[2]) / FOLD_BODY_SPEED * LOOP_HZ))
    for k in range(1, n + 1):
        p = [a + (b - a) * k / n for a, b in zip(start, end)]
        joints = solve(body, p, body.feet)
        if joints is None:
            print("[접기] 끝까지 못 내려감 — 내려간 데까지에서 접음")
            break
        if not sender.send(joints):
            return None
        body.pose = p
        time.sleep(1.0 / LOOP_HZ)
    sit = [row[:] for row in sender.hx.cmd]            # 펼 때 이 자세로 먼저 돌아옴
    print("[접기] 다리 접는 중…")
    if not play_joints(sender, FOLD_POSE, FOLD_SEC):
        return None
    return sit


def unfold(body, sender, sit):
    """접기 → 서기: 앉은 자세로 발을 내린 다음 밀어 올려 일어선다."""
    print("[펴기] 다리 내리는 중…")
    if not play_joints(sender, sit, FOLD_SEC):
        return False
    print("[펴기] 일어나는 중…")
    if not play_joints(sender, STAND_POSE, FOLD_SEC):
        return False
    body.capture()                                     # 일어선 자세를 새 기준으로
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uno", required=True, help="우노 포트 (예: /dev/ttyACM0)")
    ap.add_argument("--robot", required=True, help="로봇 블루투스 주소 또는 포트")
    ap.add_argument("--zero", action="store_true",
                    help="일어선 뒤 지금 자세를 '수평'으로 기억시킴 (평평한 바닥에서만!)")
    a = ap.parse_args()

    joy = Joystick(a.uno)
    link = Link(a.robot)
    if not link.connect():
        print("\n".join(link.log_queue))
        return
    link.imu_stream(True)                              # 펌웨어 v2: #imu 50Hz (재연결 때 자동으로 다시 켬)

    hx = Hexapod()
    if not hx.sync(link):                              # 로봇이 부팅 자세(=서기)라는 전제로 PC와 맞춤
        print("\n".join(link.log_queue))
        return
    hx.max_speed = [[STAND_SPEED] * NUM_JOINTS for _ in range(NUM_LEGS)]
    hx.standing()
    while hx.move_update_available():
        hx.move_update(link)
        if not hx.state_known:
            print("\n".join(link.log_queue))
            return
        time.sleep(0.01)

    body = hb.Body(hx, link)
    body.capture()
    sender = SdkSender(hx, link)
    sender.direct_mode()
    gait = Gait(body, sender)
    if not gait.settle():
        print("\n".join(link.log_queue))
        return
    leveler = Leveler(link)
    grounder = Grounder(gait, leveler)
    time.sleep(0.3)                                    # 발 옮긴 직후 흔들림 가라앉히기
    if link.imu_fresh():
        measure_latency(gait, link)                    # 접지에 쓸 '명령 → IMU 반응' 지연 실측 (약 2초)
    if a.zero:
        set_zero(link, grounder)
    if LEVEL_ENABLE:
        leveler.calibrate(gait)
    print("준비 완료. 조이스틱으로 조종 (Ctrl+C 종료)"
          + (" — 수평 유지 켜짐" if leveler.on and leveler.ready else " — 수평 유지 꺼짐 (C를 누르면 접지 후 다시 측정)"))

    tick = 1.0 / LOOP_HZ
    last_warn = {}
    folded = fold_request = False
    hole_block = False                                 # 걷다가 바닥 없는 곳을 만나 멈춘 상태
    tilt_at_ground = (body.pose[3], body.pose[4])      # 마지막으로 접지+수평 했을 때 몸통 각도
    sit_pose = None
    climber = None                                     # 계단 모드 (C 길게)
    stair_block = False                                # 계단 모드에서 멈춘 뒤엔 조이스틱을 한 번 놓아야 다시 감
    c_down_t, c_long_done = None, False                # C 누른 시각 (짧게/길게 구분)
    last_t = next_t = time.monotonic()
    stat_t, stat_loops, stat_sent0, stat_worst = last_t, 0, hx.stats["sent"], 0.0
    stat_imu0 = link.imu_n

    def warn(key, msg):
        if time.monotonic() - last_warn.get(key, 0.0) > 2:
            print(msg)
            last_warn[key] = time.monotonic()

    try:
        while True:
            now = time.monotonic()
            dt = min(now - last_t, 2.0 / LOOP_HZ)     # 오래 멈췄다 와도 한 번에 크게 안 뛰게
            stat_worst = max(stat_worst, now - last_t)
            last_t = now

            while link.log_queue:                      # SDK 경고(끊김·클램프 등) 출력
                print("[SDK]", link.log_queue.popleft())

            # ---- 로봇 연결 ----
            if not link.is_open or not hx.state_known:
                warn("link", "[연결] 로봇 연결 끊김 — 다시 연결 시도")
                if link.connect() and hx.sync(link):   # 마지막으로 보낸 자세로 다시 맞춤
                    sender.direct_mode()
                    gait.v, gait.w = [0.0, 0.0], 0.0
                    print("[연결] 다시 연결됨")
                else:
                    time.sleep(1.0)
                last_t = next_t = time.monotonic()
                continue

            # ---- 조종기 ----
            alive = joy.alive()
            if not alive:
                warn("joy", "[정지] 조종기 신호 없음 — 서서히 멈춤")
            pressed = joy.take_pressed() if alive else 0
            k = joy.speed01() if alive else 0.0
            cycle = CYCLE_SLOW + (CYCLE_FAST - CYCLE_SLOW) * k
            cycle = max(cycle, MIN_SWING_SEC / (1.0 - DUTY))

            # 걸으면서 접지: IMU 값이 들어올 때만 (없으면 예전처럼 안 멈추고 걸음)
            imu_ok = link.imu_fresh() and not link.imu_err
            gait.probe_on = WALK_GROUND and imu_ok
            if WALK_GROUND and not imu_ok and gait.walking:
                warn("noimu", "[걷기] IMU 값이 없음 — 접지 확인 없이 걷는 중")
            if gait.probe_on:
                # 착지 순간을 놓치지 않으려면 두 조가 같이 바닥에 있는 시간이 루프 2번 이상이어야 함
                cycle = max(cycle, 2.0 / (LOOP_HZ * (DUTY - 0.5)))

            # ---- C 버튼: 짧게/길게 구분 (누른 순간이 아니라 '뗄 때' 또는 '1초 지났을 때' 동작) ----
            if pressed & (1 << BTN_LEVEL):
                c_down_t, c_long_done = now, False
            c_short = c_long = False
            if c_down_t is not None:
                if alive and joy.held(BTN_LEVEL):
                    if not c_long_done and now - c_down_t >= LONG_PRESS_SEC:
                        c_long = c_long_done = True
                else:
                    c_short = not c_long_done
                    c_down_t = None

            # ---- 계단 모드 들어가기 / 나오기 ----
            if c_long and not folded:
                try:
                    if climber is not None and climber.active:
                        if climber.exit():
                            tilt_at_ground = (body.pose[3], body.pose[4])
                            stat_t, stat_loops, stat_sent0, stat_worst = time.monotonic(), 0, hx.stats["sent"], 0.0
                            stat_imu0 = link.imu_n
                    elif gait.walking:
                        print("[계단] 멈춘 다음 C를 길게 눌러줘")
                    else:
                        import hexapod_stair as hs              # 계단 모드는 쓸 때만 불러옴
                        if climber is None:
                            climber = hs.StairClimber(gait, grounder, leveler, link)
                            # 빨강(D, 접기 버튼) 누르고 있으면 얼음: 한 발 옮기는 도중에도 그 자세로 멈춤 (조종기 신호가 끊기면 얼음 아님 —
                            # 지금 옮기는 발까지는 놓고 멈추는 게 공중에 발을 든 채 서 있는 것보다 안전)
                            climber.stop_req = lambda: joy.alive() and joy.held(BTN_FOLD)
                        if climber.enter():
                            print("[계단] ★ Ctrl+C는 힘을 빼서 계단 위에서 주저앉음 — 계단 위에선 빨강(얼음) 또는 조이스틱을 놓아서 멈출 것")
                except ConnectionError:
                    pass
                last_t = next_t = time.monotonic()
                continue

            # ---- 계단 모드: 조이스틱 = 한 발씩, 노랑/파랑 = 몸 여유, 조이스틱 누름 = 대비 높이, C 짧게 = 다시 접지 ----
            if climber is not None and climber.active:
                if pressed & (1 << BTN_FOLD) and not climber.frozen:
                    print("[계단] 빨강 = 얼음 (한 발 옮기는 도중에 누르면 그 자세로 멈춤). "
                          "접기는 C를 1초 눌러 계단 모드를 끝낸 다음 (평평한 곳에서)")
                if pressed & (1 << BTN_UP):
                    climber.clear += 10.0
                    print(f"[계단] 몸 바닥 여유 {climber.clear:.0f}mm (다음 발부터)")
                if pressed & (1 << BTN_DOWN):
                    climber.clear = max(10.0, climber.clear - 10.0)
                    print(f"[계단] 몸 바닥 여유 {climber.clear:.0f}mm (다음 발부터)")
                if pressed & (1 << BTN_RESET):
                    ch = hs.RISE_CHOICES
                    climber.rise_max = next((v for v in ch if v > climber.rise_max + 1e-6), ch[0])
                    print(f"[계단] 앞발 대비 계단 높이 {climber.rise_max:.0f}mm (앞발이 처음 보는 곳에 이만큼 높이 들고 나감)")
                if c_short:
                    try:
                        climber.check_all()
                    except ConnectionError:
                        pass
                    last_t = next_t = time.monotonic()
                    continue
                if alive:
                    fwd, side = joy.axes()
                    turn = (1.0 if joy.held(BTN_LEFT) else 0.0) - (1.0 if joy.held(BTN_RIGHT) else 0.0)
                else:
                    fwd = side = turn = 0.0
                fwd = fwd if abs(fwd) > STAIR_STICK else 0.0
                side = side if abs(side) > STAIR_STICK else 0.0
                go = bool(fwd or side or turn)
                if stair_block:
                    stair_block = go                           # 놓을 때까지 대기
                    go = False
                if go:
                    try:
                        res = climber.step(fwd, side, turn, joy.speed01())
                    except ConnectionError:
                        res = "ok"                             # 아래 연결 처리에서 다시 연결
                    if res in ("stuck", "blocked", "hole", "abort"):
                        if not climber.frozen:
                            print(f"[계단] 멈춤 ({res}) — 조이스틱을 놓았다가 다시 밀 것 "
                                  "(방향을 바꾸거나 노랑/파랑·조이스틱 누름으로 조절)")
                        stair_block = True
                    last_t = next_t = time.monotonic()
                    continue
                if STATS_SEC and now - stat_t >= 3 * STATS_SEC:
                    print(climber.status())
                    stat_t = now
                time.sleep(tick)
                last_t = next_t = time.monotonic()
                continue

            # ---- 접기 / 펴기 ----
            if pressed & (1 << BTN_FOLD):
                if folded:
                    if unfold(body, sender, sit_pose):
                        gait.reset()
                        if gait.settle():
                            folded = False
                            print("[펴기] 완료 — 조종 가능")
                    last_t = next_t = time.monotonic()
                    continue
                fold_request = True
                if gait.walking:
                    print("[접기] 먼저 멈추는 중…")
            if folded:
                time.sleep(0.02)
                last_t = next_t = time.monotonic()
                continue
            if fold_request and not gait.walking:
                if gait.spread < 1.0 or body.pose[2] > 0.0:
                    gait.change_height(0.0)            # 폭을 줄인 채로 앉으면 무릎이 끝까지 접혀서 못 내려감
                sit_pose = fold(body, sender)
                fold_request = False
                folded = sit_pose is not None
                if folded:
                    print("[접기] 완료 — 다시 누르면 일어남")
                last_t = next_t = time.monotonic()
                continue

            # ---- 높이 ----
            # 걷는 중: 노랑/파랑 = 발 드는 높이, 조이스틱 누름 = 발 높이 원래대로
            # 서 있을 때: 몸 높이 (필요하면 폭을 줄여서라도 올림, 발을 다시 놓느라 1~2초 멈춤)
            if gait.walking and pressed & ((1 << BTN_UP) | (1 << BTN_DOWN) | (1 << BTN_RESET)):
                if pressed & (1 << BTN_UP):
                    gait.set_lift(+LIFT_STEP)
                if pressed & (1 << BTN_DOWN):
                    gait.set_lift(-LIFT_STEP)
                if pressed & (1 << BTN_RESET):
                    gait.set_lift(LIFT_MM - gait.lift_req)
            elif pressed & ((1 << BTN_UP) | (1 << BTN_DOWN) | (1 << BTN_RESET)):
                goal = gait.z_target
                if pressed & (1 << BTN_UP):
                    goal += HEIGHT_STEP
                if pressed & (1 << BTN_DOWN):
                    goal -= HEIGHT_STEP
                if pressed & (1 << BTN_RESET):
                    goal = 0.0
                goal = max(HEIGHT_MIN, min(HEIGHT_MAX, goal))
                try:
                    gait.change_height(goal)
                except ConnectionError:
                    pass                               # 아래 연결 처리에서 다시 연결
                last_t = next_t = time.monotonic()
                continue

            # ---- 접지 → 수평 (C 짧게) ----
            if c_short:
                if gait.walking:
                    print("[접지] 멈춘 다음 다시 눌러줘")
                else:
                    try:
                        if not leveler.ready and LEVEL_ENABLE:
                            grounder.run()             # 측정은 발이 다 닿은 상태에서 해야 정확함
                            leveler.on = leveler.calibrate(gait)
                        ground_and_level(gait, grounder, leveler)
                        tilt_at_ground = (body.pose[3], body.pose[4])
                    except ConnectionError:
                        pass                           # 아래 연결 처리에서 다시 연결
                    last_t = next_t = time.monotonic()
                    continue

            # ---- 걷기 ----
            if alive and not fold_request:
                fwd, side = joy.axes()
                turn = (1.0 if joy.held(BTN_LEFT) else 0.0) - (1.0 if joy.held(BTN_RIGHT) else 0.0)
                mag = math.hypot(fwd, side)
                if mag > 1.0:                          # 대각선이 더 빨라지지 않게
                    fwd, side = fwd / mag, side / mag
            else:
                fwd = side = turn = 0.0
            if hole_block:                             # 구멍 앞에서 멈춘 뒤엔 조이스틱을 한 번 놓아야 다시 감
                if not (fwd or side or turn):
                    hole_block = False
                fwd = side = turn = 0.0

            # 수평 유지: 서 있고, 움직임 명령도 없을 때만 보정 (걷는 중엔 그 기울기 유지)
            standing_still = not gait.walking and not (fwd or side or turn) and not fold_request
            leveler.update(dt, gait, standing_still)
            if leveler.saturated:
                e = leveler.err
                warn("tiltmax", f"[수평] 보정 한계 ±{LEVEL_MAX_DEG:.0f}°에 걸림 — 기울기 roll {e[0]:+.1f}° "
                                f"pitch {e[1]:+.1f}° 남음 (경사가 너무 크거나 LEVEL_MAX_DEG를 키워야 함)")

            was_walking = gait.walking
            if not gait.tick(dt, fwd, side, turn, cycle) and link.is_open and hx.state_known:
                if gait.tilt_blocked:
                    warn("tilt", f"[수평] 경사가 너무 커서 다 못 맞춤 — 몸통 {gait.body.pose[3]:+.1f}°, "
                                 f"{gait.body.pose[4]:+.1f}°에서 멈춤")
                else:
                    warn("reach", "[걷기] 다리가 못 닿음 — 높이를 바꾸거나 천천히 조종해볼 것")

            # ---- 걸으면서 접지: 방금 착지한 다리 확인 (몸 멈춘 채로) ----
            if gait.pending_land:
                try:
                    res = gait.land_probe(grounder)
                except ConnectionError:
                    res = "ok"                         # 아래 연결 처리에서 다시 연결
                if res == "hole" and LAND_HOLE_STOP:
                    print(f"[걷기] 다리{gait.hole_leg} 아래 {GROUND_MAX_DOWN:.0f}mm까지 바닥 없음 (구멍·계단 끝?) — 멈춤. "
                          "조이스틱을 놓았다가 다른 방향으로 움직일 것")
                    hole_block = True
                elif res == "abort":
                    print("[걷기] 접지 확인 중단 (IMU 끊김 또는 크게 기울어짐) — 멈춤")
                    hole_block = True
                last_t = next_t = time.monotonic()
                continue

            # ---- 멈춘 순간: 전체 접지 한 번 ----
            # 착지 때 닿았던 발도, 다른 발들이 움직이면서 하중이 옮겨가면 살짝 뜰 수 있음
            # (IMU는 닿았나/안 닿았나만 알고 얼마나 받치는지는 모름) → 멈추면 6개 전부 다시 확인
            if was_walking and not gait.walking and gait.probe_on and WALK_GROUND_ON_STOP:
                try:
                    ground_and_level(gait, grounder, leveler, verbose=False)
                    tilt_at_ground = (body.pose[3], body.pose[4])
                except ConnectionError:
                    pass
                last_t = next_t = time.monotonic()
                continue

            # ---- 서 있는 동안 수평 유지가 몸통을 많이 돌렸으면 → 다시 접지+수평 ----
            if (REGROUND_DEG and standing_still and leveler.on and leveler.ready and imu_ok
                    and math.hypot(body.pose[3] - tilt_at_ground[0], body.pose[4] - tilt_at_ground[1]) > REGROUND_DEG
                    and leveler.err and max(abs(leveler.err[0]), abs(leveler.err[1])) <= LEVEL_DEADBAND):
                print(f"[접지+수평] 몸통이 {REGROUND_DEG}° 넘게 돌아서 발이 다 닿았는지 다시 확인")
                try:
                    ground_and_level(gait, grounder, leveler)
                except ConnectionError:
                    pass
                tilt_at_ground = (body.pose[3], body.pose[4])
                last_t = next_t = time.monotonic()
                continue

            # ---- 통계 (검산용) ----
            stat_loops += 1
            if STATS_SEC and now - stat_t >= STATS_SEC:
                span = now - stat_t
                print(f"[통계] 루프 {stat_loops / span:.1f}Hz (목표 {LOOP_HZ}), "
                      f"최대 간격 {stat_worst * 1000:.0f}ms, "
                      f"전송 {(hx.stats['sent'] - stat_sent0) / span:.0f}개/초, "
                      f"프레임 전송 최대 {hx.stats['frame_max_ms']:.1f}ms, "
                      f"평균 몸 속도 {gait.dist / span:.0f}mm/s (명령 최고 {math.hypot(*gait.v):.0f}), "
                      f"거버너 시간 배율 최소 {gait.min_scale:.2f}, 발 드는 높이 {gait.lift:.0f}mm")
                if gait.landed_n:
                    moved = ", ".join(f"다리{l} {d:+.1f}mm" for l, d in gait.land_moved) or "없음"
                    print(f"[통계] 착지 {gait.landed_n}번 (다리별 보정 {' '.join(f'{b:+.0f}' for b in gait.land_bias)}mm, "
                          f"공중 단계에서 이미 닿음 {gait.land_early}번) — 바닥이 예상과 1mm 넘게 달랐던 경우 "
                          f"(+높음 / −낮음): {moved}")
                    gait.landed_n, gait.land_moved, gait.land_early = 0, [], 0
                if leveler.ready:
                    e = leveler.err or (0.0, 0.0)
                    print(f"[통계] 수평 {'켜짐' if leveler.on else '꺼짐'}: 지금 기울기 roll {e[0]:+.2f}° pitch {e[1]:+.2f}° "
                          f"(최대 {leveler.worst:.2f}°, 허용 {LEVEL_DEADBAND}°), "
                          f"몸통 보정 {gait.body.pose[3]:+.1f}° / {gait.body.pose[4]:+.1f}°, "
                          f"IMU 수신 {(link.imu_n - stat_imu0) / span:.0f}Hz 최대 간격 {link.imu_max_gap * 1000:.0f}ms, "
                          f"오래돼서 건너뜀 {leveler.stale}회")
                stat_t, stat_loops, stat_sent0, stat_worst = now, 0, hx.stats["sent"], 0.0
                stat_imu0 = link.imu_n
                link.imu_max_gap = 0.0
                leveler.stats_reset()
                hx.stats["frame_max_ms"] = 0.0
                gait.min_scale, gait.dist = 1.0, 0.0

            # ---- 일정한 주기 유지 ----
            next_t += tick
            wait = next_t - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            else:
                next_t = time.monotonic()              # 밀렸으면 따라잡지 말고 새로 시작

    except KeyboardInterrupt:
        print("\n종료 — 힘 빼기")
        hx.poweroff(link)
        time.sleep(0.2)


if __name__ == "__main__":
    main()